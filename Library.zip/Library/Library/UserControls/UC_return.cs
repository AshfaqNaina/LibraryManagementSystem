﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Library
{
    public partial class UC_return : UserControl
    {
        public UC_return()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlCommandBuilder builder;
        DataTable dt;

        private void btn_idetails_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select * from Withdraw", con);
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }


        public void clear()
        {
            txt_sid.Clear();
            txt_price.Clear();
            txt_isbn.Clear();
            txt_course.Clear();
            txt_bname.Clear();
            txt_author.Clear();
            txt_name.Clear();
            txt_dept.Clear();
            txt_bookID.Clear();
            txt_bookissue.Clear();
            pb_bar.Image = null;
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            con.Open();
            try
            {
                if (txt_author.Text != "" && txt_bname.Text != "" && txt_name.Text != "" && txt_isbn.Text != "" && txt_price.Text != "" && txt_dept.Text != "" && txt_course.Text != "")
                {
                    if (MessageBox.Show("Do you want to Return the book", "Library Project", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.No)
                    {
                        int rowIndex = dgv.CurrentCell.RowIndex;
                        dgv.Rows.RemoveAt(rowIndex);
                        builder = new SqlCommandBuilder(da);
                        da.Update(dt);
                        //////

                        SqlCommand cmd = new SqlCommand("insert into Logs(User_ID,Name,Course,Dept,Book_ID,Book_Name,Author,ISBN_No,Price,Issued_Date,Returned_Date) values('" + txt_sid.Text + "','" + txt_name.Text + "','" + txt_course.Text + "','" + txt_dept.Text + "','" + txt_bookID.Text + "','" + txt_bname.Text + "','" + txt_author.Text + "','" + txt_isbn.Text + "','" + txt_price.Text + "','" + txt_bookissue.Text+ "','" + dtp_bookreturn.Value.ToString() + "')", con);
                        SqlDataAdapter da1 = new SqlDataAdapter(cmd);
                        cmd.ExecuteNonQuery();
                        lbl_saveinfo.ForeColor = Color.Green;
                        lbl_saveinfo.Text = "Your book is returned Successfully!!!";
                        clear();
                        con.Close(); 
                    }
                    else
                    {
                        lbl_saveinfo.Text = "Library DataBase is not responding";
                        con.Close();
                    }
                }
                else
                {
                    lbl_saveinfo.ForeColor = Color.Red;
                    lbl_saveinfo.Text = "Please select the return book";
                    con.Close();
                }
            }
            catch (SqlException x)
            {
                MessageBox.Show("Error " + x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgv.Rows[e.RowIndex];
                //////////////////////////
                txt_bname.Text = row.Cells["Book_name"].Value.ToString();
                txt_bookID.Text = row.Cells["Book_ID"].Value.ToString();
                txt_author.Text = row.Cells["Author"].Value.ToString();
                txt_course.Text = row.Cells["Course"].Value.ToString();
                txt_bookissue.Text = row.Cells["Issued_Date"].Value.ToString();
                txt_dept.Text = row.Cells["Dept"].Value.ToString();
                txt_sid.Text = row.Cells["User_ID"].Value.ToString();
                txt_isbn.Text = row.Cells["ISBN_No"].Value.ToString();
                txt_name.Text = row.Cells["Name"].Value.ToString();
                txt_price.Text = row.Cells["Price"].Value.ToString();
                txt_barcode.Text = row.Cells["Barcode"].Value.ToString();
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            { 
                con.Open();
                cmd = new SqlCommand("select * from Withdraw where User_ID='" + txt_sid.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txt_name.Text = dr.GetValue(2).ToString();
                    txt_course.Text = dr.GetValue(3).ToString();
                    txt_dept.Text = dr.GetValue(4).ToString();
                    txt_bookID.Text = dr.GetValue(5).ToString();
                    txt_bname.Text = dr.GetValue(6).ToString();
                    txt_author.Text = dr.GetValue(7).ToString();
                    txt_isbn.Text = dr.GetValue(8).ToString();
                    txt_price.Text = dr.GetValue(10).ToString();
                    txt_barcode.Text = dr.GetValue(11).ToString();
                    txt_bookissue.Text = dr.GetValue(12).ToString();
                    dr.Close();
                    da = new SqlDataAdapter(cmd);
                    dt = new DataTable();
                    da.Fill(dt);
                    dgv.DataSource = dt;
                    con.Close();
                }
                else
                {
                    MessageBox.Show("No Record Found in the Library DataBase", "Library Project", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_sid.Focus();
                    con.Close();
                }
            }
            catch (SqlException x)
            {
                MessageBox.Show("Error" + x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void txt_barcode_TextChanged(object sender, EventArgs e)
        {
            if (txt_barcode.Text != "")
            {
                string barCode = txt_barcode.Text;
                try
                {
                    Zen.Barcode.Code128BarcodeDraw brCode = Zen.Barcode.BarcodeDrawFactory.Code128WithChecksum;
                    pb_bar.BackColor = Color.Transparent;
                    pb_bar.Image = brCode.Draw(barCode, 60);
                }
                catch (Exception x)
                {
                    MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                }
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_bname.Clear();
            txt_isbn.Clear();
            txt_price.Clear();
            txt_author.Clear();
            lbl_saveinfo.Text = "";
            txt_barcode.Clear();
            txt_name.Clear();
            txt_barcode.Clear();
            txt_dept.Clear();
            lbl_saveinfo.Text = "";
            txt_course.Clear();
            txt_bookID.Clear();
            txt_bookissue.Clear();
            txt_sid.Clear();
            /////
            con.Open();
            cmd = new SqlCommand("select * from Res_Images where Id=4", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            byte[] image = (byte[])dt.Rows[0][1];
            MemoryStream ms = new MemoryStream(image);
            pb_bar.Image = Image.FromStream(ms);
            con.Close();
        }
    }
}
