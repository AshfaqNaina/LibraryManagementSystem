﻿namespace Library
{
    partial class UC_BookDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.rtxt_remarks = new System.Windows.Forms.RichTextBox();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.txt_quantity = new System.Windows.Forms.TextBox();
            this.txt_isbn = new System.Windows.Forms.TextBox();
            this.txt_bname = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.lbl_quantity = new System.Windows.Forms.Label();
            this.txt_bookID = new System.Windows.Forms.TextBox();
            this.lbl_remarks = new System.Windows.Forms.Label();
            this.lbl_isbn = new System.Windows.Forms.Label();
            this.txt_barcode = new System.Windows.Forms.TextBox();
            this.lbl_bid = new System.Windows.Forms.Label();
            this.lbl_publisher = new System.Windows.Forms.Label();
            this.lbl_category = new System.Windows.Forms.Label();
            this.lbl_price = new System.Windows.Forms.Label();
            this.lbl_author = new System.Windows.Forms.Label();
            this.lbl_bname = new System.Windows.Forms.Label();
            this.lbl_barcode = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btn_view = new System.Windows.Forms.Button();
            this.lbl_saveinfo = new System.Windows.Forms.Label();
            this.txt_author = new System.Windows.Forms.TextBox();
            this.txt_publisher = new System.Windows.Forms.TextBox();
            this.pnl_dgv = new System.Windows.Forms.Panel();
            this.lbl_search = new System.Windows.Forms.Label();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.lbl_head = new System.Windows.Forms.Label();
            this.chb_bar = new System.Windows.Forms.CheckBox();
            this.pb_bar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.pnl_dgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bar)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_clear.BackColor = System.Drawing.Color.Gray;
            this.btn_clear.FlatAppearance.BorderSize = 0;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.White;
            this.btn_clear.Location = new System.Drawing.Point(866, 435);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(100, 35);
            this.btn_clear.TabIndex = 90;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_update
            // 
            this.btn_update.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_update.BackColor = System.Drawing.Color.Orange;
            this.btn_update.FlatAppearance.BorderSize = 0;
            this.btn_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.ForeColor = System.Drawing.Color.White;
            this.btn_update.Location = new System.Drawing.Point(478, 435);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(113, 35);
            this.btn_update.TabIndex = 89;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // rtxt_remarks
            // 
            this.rtxt_remarks.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rtxt_remarks.Location = new System.Drawing.Point(323, 344);
            this.rtxt_remarks.Name = "rtxt_remarks";
            this.rtxt_remarks.Size = new System.Drawing.Size(250, 69);
            this.rtxt_remarks.TabIndex = 86;
            this.rtxt_remarks.Text = "";
            // 
            // cb_category
            // 
            this.cb_category.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Items.AddRange(new object[] {
            "Mathematics",
            "Programming",
            "Tamil",
            "English",
            "Science",
            "Physics",
            "Chemistry",
            "Botany",
            "Zoology",
            "General Knowledge",
            "Other"});
            this.cb_category.Location = new System.Drawing.Point(323, 248);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(250, 33);
            this.cb_category.TabIndex = 84;
            // 
            // btn_delete
            // 
            this.btn_delete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_delete.BackColor = System.Drawing.Color.Red;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Location = new System.Drawing.Point(616, 435);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(100, 35);
            this.btn_delete.TabIndex = 81;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_save
            // 
            this.btn_save.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_save.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Location = new System.Drawing.Point(345, 435);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(100, 35);
            this.btn_save.TabIndex = 79;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // txt_quantity
            // 
            this.txt_quantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_quantity.Location = new System.Drawing.Point(732, 153);
            this.txt_quantity.Name = "txt_quantity";
            this.txt_quantity.Size = new System.Drawing.Size(263, 31);
            this.txt_quantity.TabIndex = 73;
            // 
            // txt_isbn
            // 
            this.txt_isbn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_isbn.Location = new System.Drawing.Point(323, 297);
            this.txt_isbn.Name = "txt_isbn";
            this.txt_isbn.Size = new System.Drawing.Size(250, 31);
            this.txt_isbn.TabIndex = 74;
            // 
            // txt_bname
            // 
            this.txt_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_bname.Location = new System.Drawing.Point(323, 154);
            this.txt_bname.Name = "txt_bname";
            this.txt_bname.Size = new System.Drawing.Size(250, 31);
            this.txt_bname.TabIndex = 75;
            // 
            // txt_price
            // 
            this.txt_price.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_price.Location = new System.Drawing.Point(732, 249);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(263, 31);
            this.txt_price.TabIndex = 76;
            // 
            // lbl_quantity
            // 
            this.lbl_quantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_quantity.AutoSize = true;
            this.lbl_quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_quantity.Location = new System.Drawing.Point(630, 160);
            this.lbl_quantity.Name = "lbl_quantity";
            this.lbl_quantity.Size = new System.Drawing.Size(81, 20);
            this.lbl_quantity.TabIndex = 63;
            this.lbl_quantity.Text = "Quantity:";
            // 
            // txt_bookID
            // 
            this.txt_bookID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_bookID.BackColor = System.Drawing.SystemColors.Window;
            this.txt_bookID.Location = new System.Drawing.Point(323, 107);
            this.txt_bookID.Name = "txt_bookID";
            this.txt_bookID.Size = new System.Drawing.Size(250, 31);
            this.txt_bookID.TabIndex = 77;
            // 
            // lbl_remarks
            // 
            this.lbl_remarks.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_remarks.AutoSize = true;
            this.lbl_remarks.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_remarks.Location = new System.Drawing.Point(215, 351);
            this.lbl_remarks.Name = "lbl_remarks";
            this.lbl_remarks.Size = new System.Drawing.Size(85, 20);
            this.lbl_remarks.TabIndex = 62;
            this.lbl_remarks.Text = "Remarks:";
            // 
            // lbl_isbn
            // 
            this.lbl_isbn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_isbn.AutoSize = true;
            this.lbl_isbn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_isbn.Location = new System.Drawing.Point(217, 304);
            this.lbl_isbn.Name = "lbl_isbn";
            this.lbl_isbn.Size = new System.Drawing.Size(83, 20);
            this.lbl_isbn.TabIndex = 64;
            this.lbl_isbn.Text = "ISBN No:";
            // 
            // txt_barcode
            // 
            this.txt_barcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_barcode.BackColor = System.Drawing.SystemColors.Window;
            this.txt_barcode.Location = new System.Drawing.Point(732, 297);
            this.txt_barcode.Name = "txt_barcode";
            this.txt_barcode.Size = new System.Drawing.Size(232, 31);
            this.txt_barcode.TabIndex = 78;
            // 
            // lbl_bid
            // 
            this.lbl_bid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bid.AutoSize = true;
            this.lbl_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bid.Location = new System.Drawing.Point(221, 114);
            this.lbl_bid.Name = "lbl_bid";
            this.lbl_bid.Size = new System.Drawing.Size(79, 20);
            this.lbl_bid.TabIndex = 65;
            this.lbl_bid.Text = "Book ID:";
            // 
            // lbl_publisher
            // 
            this.lbl_publisher.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_publisher.AutoSize = true;
            this.lbl_publisher.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_publisher.Location = new System.Drawing.Point(212, 208);
            this.lbl_publisher.Name = "lbl_publisher";
            this.lbl_publisher.Size = new System.Drawing.Size(88, 20);
            this.lbl_publisher.TabIndex = 66;
            this.lbl_publisher.Text = "Publisher:";
            // 
            // lbl_category
            // 
            this.lbl_category.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_category.AutoSize = true;
            this.lbl_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_category.Location = new System.Drawing.Point(214, 256);
            this.lbl_category.Name = "lbl_category";
            this.lbl_category.Size = new System.Drawing.Size(86, 20);
            this.lbl_category.TabIndex = 68;
            this.lbl_category.Text = "Category:";
            // 
            // lbl_price
            // 
            this.lbl_price.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_price.AutoSize = true;
            this.lbl_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_price.Location = new System.Drawing.Point(657, 256);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(54, 20);
            this.lbl_price.TabIndex = 67;
            this.lbl_price.Text = "Price:";
            // 
            // lbl_author
            // 
            this.lbl_author.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_author.AutoSize = true;
            this.lbl_author.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_author.Location = new System.Drawing.Point(643, 112);
            this.lbl_author.Name = "lbl_author";
            this.lbl_author.Size = new System.Drawing.Size(68, 20);
            this.lbl_author.TabIndex = 69;
            this.lbl_author.Text = "Author:";
            // 
            // lbl_bname
            // 
            this.lbl_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bname.AutoSize = true;
            this.lbl_bname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bname.Location = new System.Drawing.Point(206, 161);
            this.lbl_bname.Name = "lbl_bname";
            this.lbl_bname.Size = new System.Drawing.Size(94, 20);
            this.lbl_bname.TabIndex = 70;
            this.lbl_bname.Text = "Book Title:";
            // 
            // lbl_barcode
            // 
            this.lbl_barcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_barcode.AutoSize = true;
            this.lbl_barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_barcode.Location = new System.Drawing.Point(622, 304);
            this.lbl_barcode.Name = "lbl_barcode";
            this.lbl_barcode.Size = new System.Drawing.Size(89, 20);
            this.lbl_barcode.TabIndex = 72;
            this.lbl_barcode.Text = "Bar Code:";
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.Location = new System.Drawing.Point(0, 0);
            this.dgv.Margin = new System.Windows.Forms.Padding(4);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.RowHeadersWidth = 51;
            this.dgv.Size = new System.Drawing.Size(1200, 170);
            this.dgv.TabIndex = 91;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // btn_view
            // 
            this.btn_view.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_view.BackColor = System.Drawing.Color.Navy;
            this.btn_view.FlatAppearance.BorderSize = 0;
            this.btn_view.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_view.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_view.ForeColor = System.Drawing.Color.White;
            this.btn_view.Location = new System.Drawing.Point(741, 435);
            this.btn_view.Name = "btn_view";
            this.btn_view.Size = new System.Drawing.Size(100, 35);
            this.btn_view.TabIndex = 93;
            this.btn_view.Text = "View";
            this.btn_view.UseVisualStyleBackColor = false;
            this.btn_view.Click += new System.EventHandler(this.btn_view_Click);
            // 
            // lbl_saveinfo
            // 
            this.lbl_saveinfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_saveinfo.AutoSize = true;
            this.lbl_saveinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saveinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_saveinfo.Location = new System.Drawing.Point(41, 440);
            this.lbl_saveinfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_saveinfo.Name = "lbl_saveinfo";
            this.lbl_saveinfo.Size = new System.Drawing.Size(18, 24);
            this.lbl_saveinfo.TabIndex = 100;
            this.lbl_saveinfo.Text = "*";
            // 
            // txt_author
            // 
            this.txt_author.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_author.BackColor = System.Drawing.SystemColors.Window;
            this.txt_author.Location = new System.Drawing.Point(732, 105);
            this.txt_author.Name = "txt_author";
            this.txt_author.Size = new System.Drawing.Size(263, 31);
            this.txt_author.TabIndex = 101;
            // 
            // txt_publisher
            // 
            this.txt_publisher.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_publisher.Location = new System.Drawing.Point(323, 201);
            this.txt_publisher.Name = "txt_publisher";
            this.txt_publisher.Size = new System.Drawing.Size(672, 31);
            this.txt_publisher.TabIndex = 102;
            // 
            // pnl_dgv
            // 
            this.pnl_dgv.Controls.Add(this.dgv);
            this.pnl_dgv.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_dgv.Location = new System.Drawing.Point(0, 550);
            this.pnl_dgv.Name = "pnl_dgv";
            this.pnl_dgv.Size = new System.Drawing.Size(1200, 170);
            this.pnl_dgv.TabIndex = 103;
            // 
            // lbl_search
            // 
            this.lbl_search.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.Location = new System.Drawing.Point(218, 492);
            this.lbl_search.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(82, 24);
            this.lbl_search.TabIndex = 113;
            this.lbl_search.Text = "Search:";
            // 
            // txt_search
            // 
            this.txt_search.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_search.BackColor = System.Drawing.SystemColors.Window;
            this.txt_search.Location = new System.Drawing.Point(323, 488);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(672, 31);
            this.txt_search.TabIndex = 114;
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(500, 27);
            this.lbl_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(200, 40);
            this.lbl_head.TabIndex = 115;
            this.lbl_head.Text = "Book Details";
            // 
            // chb_bar
            // 
            this.chb_bar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chb_bar.Appearance = System.Windows.Forms.Appearance.Button;
            this.chb_bar.AutoSize = true;
            this.chb_bar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.chb_bar.FlatAppearance.BorderSize = 0;
            this.chb_bar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chb_bar.Image = global::Library.Properties.Resources.Barcode;
            this.chb_bar.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.chb_bar.Location = new System.Drawing.Point(964, 297);
            this.chb_bar.Name = "chb_bar";
            this.chb_bar.Size = new System.Drawing.Size(31, 31);
            this.chb_bar.TabIndex = 88;
            this.chb_bar.UseVisualStyleBackColor = false;
            this.chb_bar.CheckedChanged += new System.EventHandler(this.chb_bar_CheckedChanged);
            // 
            // pb_bar
            // 
            this.pb_bar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_bar.Image = global::Library.Properties.Resources.Barcode_70;
            this.pb_bar.Location = new System.Drawing.Point(732, 345);
            this.pb_bar.Name = "pb_bar";
            this.pb_bar.Size = new System.Drawing.Size(263, 70);
            this.pb_bar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_bar.TabIndex = 87;
            this.pb_bar.TabStop = false;
            // 
            // UC_BookDetails
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.lbl_head);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.pnl_dgv);
            this.Controls.Add(this.txt_publisher);
            this.Controls.Add(this.txt_author);
            this.Controls.Add(this.lbl_saveinfo);
            this.Controls.Add(this.btn_view);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.chb_bar);
            this.Controls.Add(this.pb_bar);
            this.Controls.Add(this.rtxt_remarks);
            this.Controls.Add(this.cb_category);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.txt_quantity);
            this.Controls.Add(this.txt_isbn);
            this.Controls.Add(this.txt_bname);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.lbl_quantity);
            this.Controls.Add(this.txt_bookID);
            this.Controls.Add(this.lbl_remarks);
            this.Controls.Add(this.lbl_isbn);
            this.Controls.Add(this.txt_barcode);
            this.Controls.Add(this.lbl_bid);
            this.Controls.Add(this.lbl_publisher);
            this.Controls.Add(this.lbl_category);
            this.Controls.Add(this.lbl_price);
            this.Controls.Add(this.lbl_author);
            this.Controls.Add(this.lbl_bname);
            this.Controls.Add(this.lbl_barcode);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UC_BookDetails";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_BookDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.pnl_dgv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_bar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.CheckBox chb_bar;
        private System.Windows.Forms.PictureBox pb_bar;
        private System.Windows.Forms.RichTextBox rtxt_remarks;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.TextBox txt_quantity;
        private System.Windows.Forms.TextBox txt_isbn;
        private System.Windows.Forms.TextBox txt_bname;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Label lbl_quantity;
        private System.Windows.Forms.TextBox txt_bookID;
        private System.Windows.Forms.Label lbl_remarks;
        private System.Windows.Forms.Label lbl_isbn;
        private System.Windows.Forms.TextBox txt_barcode;
        private System.Windows.Forms.Label lbl_bid;
        private System.Windows.Forms.Label lbl_publisher;
        private System.Windows.Forms.Label lbl_category;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.Label lbl_author;
        private System.Windows.Forms.Label lbl_bname;
        private System.Windows.Forms.Label lbl_barcode;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btn_view;
        private System.Windows.Forms.Label lbl_saveinfo;
        private System.Windows.Forms.TextBox txt_author;
        private System.Windows.Forms.TextBox txt_publisher;
        private System.Windows.Forms.Panel pnl_dgv;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label lbl_head;
    }
}
