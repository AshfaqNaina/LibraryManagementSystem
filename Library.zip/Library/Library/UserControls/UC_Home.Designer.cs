﻿namespace Library
{
    partial class UC_Home
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_Users = new System.Windows.Forms.Panel();
            this.pnl_books = new System.Windows.Forms.Panel();
            this.pnl_bookIssue = new System.Windows.Forms.Panel();
            this.lbl_totaluser_Head = new System.Windows.Forms.Label();
            this.lbl_totalbook_Head = new System.Windows.Forms.Label();
            this.lbl_totalbook_issue = new System.Windows.Forms.Label();
            this.lbl_totalStudent = new System.Windows.Forms.Label();
            this.lbl_totalBook = new System.Windows.Forms.Label();
            this.lbl_bookIssue = new System.Windows.Forms.Label();
            this.pb_withdraw = new System.Windows.Forms.PictureBox();
            this.pb_book = new System.Windows.Forms.PictureBox();
            this.pb_user = new System.Windows.Forms.PictureBox();
            this.pnl_Users.SuspendLayout();
            this.pnl_books.SuspendLayout();
            this.pnl_bookIssue.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_withdraw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_book)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_user)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label1.Location = new System.Drawing.Point(385, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(430, 40);
            this.label1.TabIndex = 129;
            this.label1.Text = "Library Management System";
            // 
            // pnl_Users
            // 
            this.pnl_Users.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_Users.BackColor = System.Drawing.Color.SeaGreen;
            this.pnl_Users.Controls.Add(this.pb_user);
            this.pnl_Users.Controls.Add(this.lbl_totalStudent);
            this.pnl_Users.Controls.Add(this.lbl_totaluser_Head);
            this.pnl_Users.Location = new System.Drawing.Point(111, 188);
            this.pnl_Users.Name = "pnl_Users";
            this.pnl_Users.Size = new System.Drawing.Size(285, 120);
            this.pnl_Users.TabIndex = 130;
            // 
            // pnl_books
            // 
            this.pnl_books.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_books.BackColor = System.Drawing.Color.DarkOrange;
            this.pnl_books.Controls.Add(this.pb_book);
            this.pnl_books.Controls.Add(this.lbl_totalBook);
            this.pnl_books.Controls.Add(this.lbl_totalbook_Head);
            this.pnl_books.Location = new System.Drawing.Point(457, 188);
            this.pnl_books.Name = "pnl_books";
            this.pnl_books.Size = new System.Drawing.Size(285, 120);
            this.pnl_books.TabIndex = 131;
            // 
            // pnl_bookIssue
            // 
            this.pnl_bookIssue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_bookIssue.BackColor = System.Drawing.Color.Crimson;
            this.pnl_bookIssue.Controls.Add(this.pb_withdraw);
            this.pnl_bookIssue.Controls.Add(this.lbl_bookIssue);
            this.pnl_bookIssue.Controls.Add(this.lbl_totalbook_issue);
            this.pnl_bookIssue.Location = new System.Drawing.Point(803, 188);
            this.pnl_bookIssue.Name = "pnl_bookIssue";
            this.pnl_bookIssue.Size = new System.Drawing.Size(285, 120);
            this.pnl_bookIssue.TabIndex = 132;
            // 
            // lbl_totaluser_Head
            // 
            this.lbl_totaluser_Head.AutoSize = true;
            this.lbl_totaluser_Head.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totaluser_Head.ForeColor = System.Drawing.Color.White;
            this.lbl_totaluser_Head.Location = new System.Drawing.Point(33, 19);
            this.lbl_totaluser_Head.Name = "lbl_totaluser_Head";
            this.lbl_totaluser_Head.Size = new System.Drawing.Size(126, 24);
            this.lbl_totaluser_Head.TabIndex = 133;
            this.lbl_totaluser_Head.Text = "Total User\'s:";
            // 
            // lbl_totalbook_Head
            // 
            this.lbl_totalbook_Head.AutoSize = true;
            this.lbl_totalbook_Head.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalbook_Head.ForeColor = System.Drawing.Color.White;
            this.lbl_totalbook_Head.Location = new System.Drawing.Point(37, 19);
            this.lbl_totalbook_Head.Name = "lbl_totalbook_Head";
            this.lbl_totalbook_Head.Size = new System.Drawing.Size(125, 24);
            this.lbl_totalbook_Head.TabIndex = 134;
            this.lbl_totalbook_Head.Text = "Total Books:";
            // 
            // lbl_totalbook_issue
            // 
            this.lbl_totalbook_issue.AutoSize = true;
            this.lbl_totalbook_issue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalbook_issue.ForeColor = System.Drawing.Color.White;
            this.lbl_totalbook_issue.Location = new System.Drawing.Point(26, 19);
            this.lbl_totalbook_issue.Name = "lbl_totalbook_issue";
            this.lbl_totalbook_issue.Size = new System.Drawing.Size(165, 24);
            this.lbl_totalbook_issue.TabIndex = 134;
            this.lbl_totalbook_issue.Text = "Books Withdraw:";
            // 
            // lbl_totalStudent
            // 
            this.lbl_totalStudent.AutoSize = true;
            this.lbl_totalStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalStudent.ForeColor = System.Drawing.Color.White;
            this.lbl_totalStudent.Location = new System.Drawing.Point(164, 74);
            this.lbl_totalStudent.Name = "lbl_totalStudent";
            this.lbl_totalStudent.Size = new System.Drawing.Size(26, 24);
            this.lbl_totalStudent.TabIndex = 134;
            this.lbl_totalStudent.Text = "**";
            // 
            // lbl_totalBook
            // 
            this.lbl_totalBook.AutoSize = true;
            this.lbl_totalBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalBook.ForeColor = System.Drawing.Color.White;
            this.lbl_totalBook.Location = new System.Drawing.Point(163, 74);
            this.lbl_totalBook.Name = "lbl_totalBook";
            this.lbl_totalBook.Size = new System.Drawing.Size(26, 24);
            this.lbl_totalBook.TabIndex = 135;
            this.lbl_totalBook.Text = "**";
            // 
            // lbl_bookIssue
            // 
            this.lbl_bookIssue.AutoSize = true;
            this.lbl_bookIssue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bookIssue.ForeColor = System.Drawing.Color.White;
            this.lbl_bookIssue.Location = new System.Drawing.Point(166, 74);
            this.lbl_bookIssue.Name = "lbl_bookIssue";
            this.lbl_bookIssue.Size = new System.Drawing.Size(26, 24);
            this.lbl_bookIssue.TabIndex = 135;
            this.lbl_bookIssue.Text = "**";
            // 
            // pb_withdraw
            // 
            this.pb_withdraw.Image = global::Library.Properties.Resources.withdraw45;
            this.pb_withdraw.Location = new System.Drawing.Point(92, 61);
            this.pb_withdraw.Name = "pb_withdraw";
            this.pb_withdraw.Size = new System.Drawing.Size(45, 45);
            this.pb_withdraw.TabIndex = 136;
            this.pb_withdraw.TabStop = false;
            // 
            // pb_book
            // 
            this.pb_book.Image = global::Library.Properties.Resources.books;
            this.pb_book.Location = new System.Drawing.Point(95, 61);
            this.pb_book.Name = "pb_book";
            this.pb_book.Size = new System.Drawing.Size(45, 45);
            this.pb_book.TabIndex = 136;
            this.pb_book.TabStop = false;
            // 
            // pb_user
            // 
            this.pb_user.Image = global::Library.Properties.Resources.customer45;
            this.pb_user.Location = new System.Drawing.Point(94, 61);
            this.pb_user.Name = "pb_user";
            this.pb_user.Size = new System.Drawing.Size(45, 45);
            this.pb_user.TabIndex = 133;
            this.pb_user.TabStop = false;
            // 
            // UC_Home
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnl_bookIssue);
            this.Controls.Add(this.pnl_books);
            this.Controls.Add(this.pnl_Users);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "UC_Home";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_Home_Load);
            this.pnl_Users.ResumeLayout(false);
            this.pnl_Users.PerformLayout();
            this.pnl_books.ResumeLayout(false);
            this.pnl_books.PerformLayout();
            this.pnl_bookIssue.ResumeLayout(false);
            this.pnl_bookIssue.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_withdraw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_book)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_user)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_Users;
        private System.Windows.Forms.Label lbl_totaluser_Head;
        private System.Windows.Forms.Panel pnl_books;
        private System.Windows.Forms.Label lbl_totalbook_Head;
        private System.Windows.Forms.Panel pnl_bookIssue;
        private System.Windows.Forms.Label lbl_totalbook_issue;
        private System.Windows.Forms.Label lbl_totalStudent;
        private System.Windows.Forms.Label lbl_totalBook;
        private System.Windows.Forms.Label lbl_bookIssue;
        private System.Windows.Forms.PictureBox pb_user;
        private System.Windows.Forms.PictureBox pb_book;
        private System.Windows.Forms.PictureBox pb_withdraw;
    }
}
