﻿namespace Library
{
    partial class UC_Home
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Home));
            this.pnl_user = new System.Windows.Forms.Panel();
            this.pb_user = new System.Windows.Forms.PictureBox();
            this.lbl_users = new System.Windows.Forms.Label();
            this.lbl_headUser = new System.Windows.Forms.Label();
            this.lbl_withdrawPB = new System.Windows.Forms.Label();
            this.lbl_returnPB = new System.Windows.Forms.Label();
            this.lbl_Head_returnWithdraw = new System.Windows.Forms.Label();
            this.lbl_yearReport = new System.Windows.Forms.Label();
            this.lbl_return = new System.Windows.Forms.Label();
            this.lbl_withdraw = new System.Windows.Forms.Label();
            this.lbl_headWithdraw = new System.Windows.Forms.Label();
            this.pnl_withdraw = new System.Windows.Forms.Panel();
            this.pb_withdraw = new System.Windows.Forms.PictureBox();
            this.lbl_head = new System.Windows.Forms.Label();
            this.lbl_headReturn = new System.Windows.Forms.Label();
            this.pnl_return = new System.Windows.Forms.Panel();
            this.pb_return = new System.Windows.Forms.PictureBox();
            this.BunifuChart = new Bunifu.DataViz.BunifuDataViz();
            this.bunifuCirclePB_withdraw = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.bunifuCirclePB_return = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.btn_refresh = new System.Windows.Forms.Button();
            this.pnl_user.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_user)).BeginInit();
            this.pnl_withdraw.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_withdraw)).BeginInit();
            this.pnl_return.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_return)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_user
            // 
            this.pnl_user.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_user.BackColor = System.Drawing.Color.Orange;
            this.pnl_user.Controls.Add(this.pb_user);
            this.pnl_user.Controls.Add(this.lbl_users);
            this.pnl_user.Controls.Add(this.lbl_headUser);
            this.pnl_user.Location = new System.Drawing.Point(773, 176);
            this.pnl_user.Name = "pnl_user";
            this.pnl_user.Size = new System.Drawing.Size(269, 105);
            this.pnl_user.TabIndex = 10;
            // 
            // pb_user
            // 
            this.pb_user.Image = global::Library.Properties.Resources.Student_55;
            this.pb_user.Location = new System.Drawing.Point(183, 23);
            this.pb_user.Name = "pb_user";
            this.pb_user.Size = new System.Drawing.Size(57, 59);
            this.pb_user.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_user.TabIndex = 2;
            this.pb_user.TabStop = false;
            // 
            // lbl_users
            // 
            this.lbl_users.AutoSize = true;
            this.lbl_users.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_users.ForeColor = System.Drawing.Color.White;
            this.lbl_users.Location = new System.Drawing.Point(78, 54);
            this.lbl_users.Name = "lbl_users";
            this.lbl_users.Size = new System.Drawing.Size(32, 24);
            this.lbl_users.TabIndex = 0;
            this.lbl_users.Text = "16";
            // 
            // lbl_headUser
            // 
            this.lbl_headUser.AutoSize = true;
            this.lbl_headUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_headUser.ForeColor = System.Drawing.Color.White;
            this.lbl_headUser.Location = new System.Drawing.Point(39, 21);
            this.lbl_headUser.Name = "lbl_headUser";
            this.lbl_headUser.Size = new System.Drawing.Size(121, 20);
            this.lbl_headUser.TabIndex = 0;
            this.lbl_headUser.Text = "User/Student:";
            // 
            // lbl_withdrawPB
            // 
            this.lbl_withdrawPB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_withdrawPB.AutoSize = true;
            this.lbl_withdrawPB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_withdrawPB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.lbl_withdrawPB.Location = new System.Drawing.Point(930, 563);
            this.lbl_withdrawPB.Name = "lbl_withdrawPB";
            this.lbl_withdrawPB.Size = new System.Drawing.Size(83, 20);
            this.lbl_withdrawPB.TabIndex = 5;
            this.lbl_withdrawPB.Text = "Withdraw";
            // 
            // lbl_returnPB
            // 
            this.lbl_returnPB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_returnPB.AutoSize = true;
            this.lbl_returnPB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_returnPB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.lbl_returnPB.Location = new System.Drawing.Point(769, 563);
            this.lbl_returnPB.Name = "lbl_returnPB";
            this.lbl_returnPB.Size = new System.Drawing.Size(64, 20);
            this.lbl_returnPB.TabIndex = 6;
            this.lbl_returnPB.Text = "Return";
            // 
            // lbl_Head_returnWithdraw
            // 
            this.lbl_Head_returnWithdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_Head_returnWithdraw.AutoSize = true;
            this.lbl_Head_returnWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Head_returnWithdraw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.lbl_Head_returnWithdraw.Location = new System.Drawing.Point(725, 334);
            this.lbl_Head_returnWithdraw.Name = "lbl_Head_returnWithdraw";
            this.lbl_Head_returnWithdraw.Size = new System.Drawing.Size(258, 20);
            this.lbl_Head_returnWithdraw.TabIndex = 7;
            this.lbl_Head_returnWithdraw.Text = "% Book Recived and Withdraw:";
            // 
            // lbl_yearReport
            // 
            this.lbl_yearReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_yearReport.AutoSize = true;
            this.lbl_yearReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_yearReport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.lbl_yearReport.Location = new System.Drawing.Point(151, 334);
            this.lbl_yearReport.Name = "lbl_yearReport";
            this.lbl_yearReport.Size = new System.Drawing.Size(124, 20);
            this.lbl_yearReport.TabIndex = 8;
            this.lbl_yearReport.Text = "Yearly Report:";
            // 
            // lbl_return
            // 
            this.lbl_return.AutoSize = true;
            this.lbl_return.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_return.ForeColor = System.Drawing.Color.White;
            this.lbl_return.Location = new System.Drawing.Point(82, 56);
            this.lbl_return.Name = "lbl_return";
            this.lbl_return.Size = new System.Drawing.Size(32, 24);
            this.lbl_return.TabIndex = 0;
            this.lbl_return.Text = "11";
            // 
            // lbl_withdraw
            // 
            this.lbl_withdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_withdraw.AutoSize = true;
            this.lbl_withdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_withdraw.ForeColor = System.Drawing.Color.White;
            this.lbl_withdraw.Location = new System.Drawing.Point(53, 54);
            this.lbl_withdraw.Name = "lbl_withdraw";
            this.lbl_withdraw.Size = new System.Drawing.Size(21, 24);
            this.lbl_withdraw.TabIndex = 0;
            this.lbl_withdraw.Text = "5";
            // 
            // lbl_headWithdraw
            // 
            this.lbl_headWithdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_headWithdraw.AutoSize = true;
            this.lbl_headWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_headWithdraw.ForeColor = System.Drawing.Color.White;
            this.lbl_headWithdraw.Location = new System.Drawing.Point(23, 21);
            this.lbl_headWithdraw.Name = "lbl_headWithdraw";
            this.lbl_headWithdraw.Size = new System.Drawing.Size(134, 20);
            this.lbl_headWithdraw.TabIndex = 0;
            this.lbl_headWithdraw.Text = "Book Withdraw:";
            // 
            // pnl_withdraw
            // 
            this.pnl_withdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_withdraw.BackColor = System.Drawing.Color.SeaGreen;
            this.pnl_withdraw.Controls.Add(this.pb_withdraw);
            this.pnl_withdraw.Controls.Add(this.lbl_withdraw);
            this.pnl_withdraw.Controls.Add(this.lbl_headWithdraw);
            this.pnl_withdraw.Location = new System.Drawing.Point(155, 176);
            this.pnl_withdraw.Name = "pnl_withdraw";
            this.pnl_withdraw.Size = new System.Drawing.Size(275, 105);
            this.pnl_withdraw.TabIndex = 11;
            // 
            // pb_withdraw
            // 
            this.pb_withdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_withdraw.Image = global::Library.Properties.Resources.Book_withdraw_55;
            this.pb_withdraw.Location = new System.Drawing.Point(187, 25);
            this.pb_withdraw.Name = "pb_withdraw";
            this.pb_withdraw.Size = new System.Drawing.Size(55, 55);
            this.pb_withdraw.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_withdraw.TabIndex = 2;
            this.pb_withdraw.TabStop = false;
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.lbl_head.Location = new System.Drawing.Point(317, 80);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(595, 31);
            this.lbl_head.TabIndex = 9;
            this.lbl_head.Text = "Books Withdraw and Books Return Overview";
            // 
            // lbl_headReturn
            // 
            this.lbl_headReturn.AutoSize = true;
            this.lbl_headReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_headReturn.ForeColor = System.Drawing.Color.White;
            this.lbl_headReturn.Location = new System.Drawing.Point(36, 21);
            this.lbl_headReturn.Name = "lbl_headReturn";
            this.lbl_headReturn.Size = new System.Drawing.Size(124, 20);
            this.lbl_headReturn.TabIndex = 0;
            this.lbl_headReturn.Text = "Return Books:";
            // 
            // pnl_return
            // 
            this.pnl_return.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_return.BackColor = System.Drawing.Color.Crimson;
            this.pnl_return.Controls.Add(this.pb_return);
            this.pnl_return.Controls.Add(this.lbl_return);
            this.pnl_return.Controls.Add(this.lbl_headReturn);
            this.pnl_return.Location = new System.Drawing.Point(460, 176);
            this.pnl_return.Name = "pnl_return";
            this.pnl_return.Size = new System.Drawing.Size(283, 105);
            this.pnl_return.TabIndex = 12;
            // 
            // pb_return
            // 
            this.pb_return.Image = global::Library.Properties.Resources.Book_Return_55;
            this.pb_return.Location = new System.Drawing.Point(208, 23);
            this.pb_return.Name = "pb_return";
            this.pb_return.Size = new System.Drawing.Size(57, 59);
            this.pb_return.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_return.TabIndex = 2;
            this.pb_return.TabStop = false;
            // 
            // BunifuChart
            // 
            this.BunifuChart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BunifuChart.animationEnabled = false;
            this.BunifuChart.AxisLineColor = System.Drawing.Color.LightGray;
            this.BunifuChart.AxisXFontColor = System.Drawing.Color.Gray;
            this.BunifuChart.AxisXGridColor = System.Drawing.Color.Gray;
            this.BunifuChart.AxisXGridThickness = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BunifuChart.AxisYFontColor = System.Drawing.Color.Gray;
            this.BunifuChart.AxisYGridColor = System.Drawing.Color.Gray;
            this.BunifuChart.AxisYGridThickness = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BunifuChart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BunifuChart.Location = new System.Drawing.Point(155, 359);
            this.BunifuChart.Margin = new System.Windows.Forms.Padding(5);
            this.BunifuChart.Name = "BunifuChart";
            this.BunifuChart.Size = new System.Drawing.Size(481, 269);
            this.BunifuChart.TabIndex = 13;
            this.BunifuChart.Theme = Bunifu.DataViz.BunifuDataViz._theme.theme1;
            this.BunifuChart.Title = "";
            // 
            // bunifuCirclePB_withdraw
            // 
            this.bunifuCirclePB_withdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCirclePB_withdraw.animated = true;
            this.bunifuCirclePB_withdraw.animationIterval = 5;
            this.bunifuCirclePB_withdraw.animationSpeed = 50;
            this.bunifuCirclePB_withdraw.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuCirclePB_withdraw.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCirclePB_withdraw.BackgroundImage")));
            this.bunifuCirclePB_withdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCirclePB_withdraw.ForeColor = System.Drawing.Color.Crimson;
            this.bunifuCirclePB_withdraw.LabelVisible = true;
            this.bunifuCirclePB_withdraw.LineProgressThickness = 8;
            this.bunifuCirclePB_withdraw.LineThickness = 5;
            this.bunifuCirclePB_withdraw.Location = new System.Drawing.Point(896, 398);
            this.bunifuCirclePB_withdraw.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCirclePB_withdraw.MaxValue = 100;
            this.bunifuCirclePB_withdraw.Name = "bunifuCirclePB_withdraw";
            this.bunifuCirclePB_withdraw.ProgressBackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCirclePB_withdraw.ProgressColor = System.Drawing.Color.Crimson;
            this.bunifuCirclePB_withdraw.Size = new System.Drawing.Size(147, 147);
            this.bunifuCirclePB_withdraw.TabIndex = 15;
            this.bunifuCirclePB_withdraw.Value = 26;
            // 
            // bunifuCirclePB_return
            // 
            this.bunifuCirclePB_return.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCirclePB_return.animated = true;
            this.bunifuCirclePB_return.animationIterval = 5;
            this.bunifuCirclePB_return.animationSpeed = 50;
            this.bunifuCirclePB_return.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuCirclePB_return.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCirclePB_return.BackgroundImage")));
            this.bunifuCirclePB_return.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCirclePB_return.ForeColor = System.Drawing.Color.Indigo;
            this.bunifuCirclePB_return.LabelVisible = true;
            this.bunifuCirclePB_return.LineProgressThickness = 8;
            this.bunifuCirclePB_return.LineThickness = 5;
            this.bunifuCirclePB_return.Location = new System.Drawing.Point(729, 398);
            this.bunifuCirclePB_return.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCirclePB_return.MaxValue = 100;
            this.bunifuCirclePB_return.Name = "bunifuCirclePB_return";
            this.bunifuCirclePB_return.ProgressBackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCirclePB_return.ProgressColor = System.Drawing.Color.DarkViolet;
            this.bunifuCirclePB_return.Size = new System.Drawing.Size(147, 147);
            this.bunifuCirclePB_return.TabIndex = 16;
            this.bunifuCirclePB_return.Value = 11;
            // 
            // btn_refresh
            // 
            this.btn_refresh.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_refresh.Image = global::Library.Properties.Resources.Refresh;
            this.btn_refresh.Location = new System.Drawing.Point(640, 359);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(33, 33);
            this.btn_refresh.TabIndex = 14;
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // UC_Home
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.bunifuCirclePB_withdraw);
            this.Controls.Add(this.bunifuCirclePB_return);
            this.Controls.Add(this.btn_refresh);
            this.Controls.Add(this.BunifuChart);
            this.Controls.Add(this.lbl_withdrawPB);
            this.Controls.Add(this.lbl_returnPB);
            this.Controls.Add(this.lbl_Head_returnWithdraw);
            this.Controls.Add(this.lbl_yearReport);
            this.Controls.Add(this.pnl_user);
            this.Controls.Add(this.pnl_withdraw);
            this.Controls.Add(this.lbl_head);
            this.Controls.Add(this.pnl_return);
            this.Name = "UC_Home";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_Home_Load);
            this.pnl_user.ResumeLayout(false);
            this.pnl_user.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_user)).EndInit();
            this.pnl_withdraw.ResumeLayout(false);
            this.pnl_withdraw.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_withdraw)).EndInit();
            this.pnl_return.ResumeLayout(false);
            this.pnl_return.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_return)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCirclePB_withdraw;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCirclePB_return;
        private System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.Panel pnl_user;
        private System.Windows.Forms.PictureBox pb_user;
        private System.Windows.Forms.Label lbl_users;
        private System.Windows.Forms.Label lbl_headUser;
        private System.Windows.Forms.Label lbl_withdrawPB;
        private System.Windows.Forms.Label lbl_returnPB;
        private System.Windows.Forms.Label lbl_Head_returnWithdraw;
        private System.Windows.Forms.Label lbl_yearReport;
        private System.Windows.Forms.Label lbl_return;
        private System.Windows.Forms.PictureBox pb_return;
        private System.Windows.Forms.PictureBox pb_withdraw;
        private System.Windows.Forms.Label lbl_withdraw;
        private System.Windows.Forms.Label lbl_headWithdraw;
        private System.Windows.Forms.Panel pnl_withdraw;
        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.Label lbl_headReturn;
        private System.Windows.Forms.Panel pnl_return;
        private Bunifu.DataViz.BunifuDataViz BunifuChart;
    }
}
