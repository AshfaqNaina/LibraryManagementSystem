﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using AForge.Video;
using AForge.Video.DirectShow;

namespace Library
{
    public partial class UC_Student : UserControl
    {
        public UC_Student()
        {
            InitializeComponent();
        }
        string img_file;
        SqlConnection con=new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;
        DataTable dt;
        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_mobile.Text != "" && txt_email.Text != "" && txt_name.Text != "" && rtxt_address.Text != "" && cb_course.SelectedIndex != -1 && cb_age.SelectedIndex != -1 && cb_role.Text!="")
                {

                    if (img_file != null)
                    {
                        if (MessageBox.Show("Do you want to save the student details", "Library Project", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.No)
                        {
                            con.Open();
                            FileStream fs = new FileStream(img_file, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                            byte[] image = new byte[fs.Length];
                            fs.Read(image, 0, Convert.ToInt32(fs.Length));
                            fs.Close();
                            ///////
                            cmd = new SqlCommand("insert into Users(User_ID,Name,Address,Course,Dept,Age,Email,Mobile,Role,Qrcode,Image) values('"+txt_UserID.Text+"','" + txt_name.Text + "','" + rtxt_address.Text + "','" + cb_course.Text + "','" + cb_dept.Text + "','" + cb_age.Text + "','" + txt_email.Text + "','" + txt_mobile.Text + "','"+cb_role.Text+"','"+txt_qrcode.Text+"',@pic)", con);
                            SqlParameter prm = new SqlParameter("@pic", SqlDbType.VarBinary, image.Length, ParameterDirection.Input, false, 0, 0, null, DataRowVersion.Current, image);
                            cmd.Parameters.Add(prm);
                            da = new SqlDataAdapter(cmd);
                            cmd.ExecuteNonQuery();
                            lbl_saveinfo.Text = "You added a new User!!!";
                            lbl_saveinfo.ForeColor = Color.Green;
                            con.Close();
                        }

                    }
                    else
                    {
                        lbl_saveinfo.Text = "Please Upload Image";
                        lbl_saveinfo.ForeColor = Color.Red;
                    }
                }
                else
                {
                    lbl_saveinfo.Text = "Please fill all The datas";
                    lbl_saveinfo.ForeColor = Color.Red;
                }
            }
            catch (SqlException x)
            {
                MessageBox.Show(x.Message+"Invalid mobile number please check", "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_browse_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog o = new OpenFileDialog();
                if (o.ShowDialog() != DialogResult.Cancel)
                {
                    img_file = o.FileName;
                    pb_student.Image = Image.FromFile(o.FileName);
                }
            }
            catch (Exception x)
            {
                MessageBox.Show("Error " + x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
            lbl_saveinfo.Text = "";
        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select User_ID,Name,Address,Course,Dept,Age,Email,Mobile,Role,Qrcode from Users", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
            lbl_saveinfo.Text = ""; ;
        }
        private void btn_update_Click(object sender, EventArgs e)
        {

            try
            {
                if (MessageBox.Show("Do you want to update the User details", "Library Project", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.No)
                {
                    con.Open();
                    FileStream fs = new FileStream(img_file, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                    byte[] image = new byte[fs.Length];
                    fs.Read(image, 0, Convert.ToInt32(fs.Length));
                    fs.Close();
                    ////
                    cmd = new SqlCommand("update Users Set Name='" + txt_name.Text + "',Address='" + rtxt_address.Text + "',Course='" + cb_course.Text + "',Dept='" + cb_dept.Text + "',Age='" + cb_age.Text + "',Email='" + txt_email.Text + "',Mobile='" + txt_mobile.Text + "',Role='" + cb_role.Text + "',Qrcode='" + txt_qrcode.Text + "',Image=@pic where User_ID='" + txt_UserID.Text + "'", con);
                    SqlParameter prm = new SqlParameter("@pic", SqlDbType.VarBinary, image.Length, ParameterDirection.Input, false, 0, 0, null, DataRowVersion.Current, image);
                    cmd.Parameters.Add(prm);
                    dr = cmd.ExecuteReader();
                    lbl_saveinfo.Text = "Update Successfully";
                    con.Close();
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do you want to delete the User details", "Library Project", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.No)
                {
                    con.Open();
                    cmd = new SqlCommand("delete from Users where User_ID='" + txt_UserID.Text + "'", con);
                    dr = cmd.ExecuteReader();
                    lbl_saveinfo.Text = "Delete Successfully";
                    con.Close();
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            lbl_saveinfo.Text = "";
            if (e.RowIndex >= 0)
            {
                con.Open();
                DataGridViewRow row = this.dgv.Rows[e.RowIndex];
                txt_UserID.Text = row.Cells["User_ID"].Value.ToString();
                txt_name.Text = row.Cells["Name"].Value.ToString();
                rtxt_address.Text = row.Cells["Address"].Value.ToString();
                cb_course.Text = row.Cells["Course"].Value.ToString();
                cb_dept.Text = row.Cells["Dept"].Value.ToString();
                cb_age.Text = row.Cells["Age"].Value.ToString();
                txt_email.Text = row.Cells["Email"].Value.ToString();
                txt_mobile.Text = row.Cells["Mobile"].Value.ToString();
                cb_role.Text = row.Cells["Role"].Value.ToString();
                txt_qrcode.Text= row.Cells["Qrcode"].Value.ToString();
                if (txt_UserID.Text!="")
                {
                    cmd = new SqlCommand("select * from Users where User_ID='"+txt_UserID.Text+"'", con);
                    da = new SqlDataAdapter(cmd);
                    dt = new DataTable();
                    da.Fill(dt);
                    byte[] image = (byte[])dt.Rows[0][11];
                    MemoryStream ms = new MemoryStream(image);
                    pb_student.Image = Image.FromStream(ms);
                    con.Close();

                    try
                    {
                        if (txt_name.Text != "" && txt_mobile.Text != "" && txt_UserID.Text != "" && txt_email.Text != "" && rtxt_address.Text != "" && cb_age.Text != "" && cb_course.Text != "" && cb_role.Text != "")
                        {
                            Zen.Barcode.CodeQrBarcodeDraw qrCode = Zen.Barcode.BarcodeDrawFactory.CodeQr;
                            pb_qrcode.BackColor = Color.Transparent;
                            pb_qrcode.Image = qrCode.Draw(txt_qrcode.Text, 60);
                            lbl_qr.ForeColor = Color.Black;
                            con.Close();
                        }
                    }
                    catch (Exception x)
                    {
                        MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        con.Close();
                    }
                }
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select User_Id,Name,Address,Course,Dept,Age,Email,Mobile,Role from Users where User_ID like '%" + txt_search.Text + "%' or Name like '%" + txt_search.Text + "%' or Address like '%" + txt_search.Text + "%' or Course like '%" + txt_search.Text + "%' or Dept like '%" + txt_search.Text + "%' or Age like '%" + txt_search.Text + "%' or Email like '%" + txt_search.Text + "%' or Mobile like  '%" + txt_search.Text + "%' or Role like  '%" + txt_search.Text + "%'", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
                lbl_saveinfo.Text = "";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_qrcode_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_name.Text!="" && txt_mobile.Text!=""&&txt_UserID.Text!=""&&txt_email.Text!=""&&rtxt_address.Text!=""&&cb_age.Text!=""&&cb_course.Text!=""&&cb_role.Text!="")
                {
                    txt_qrcode.Text = "User Id=" + txt_UserID.Text + "%" + txt_name.Text + "%" + rtxt_address.Text + "%" + txt_mobile.Text + "%" + txt_email.Text + "";
                    Zen.Barcode.CodeQrBarcodeDraw qrCode = Zen.Barcode.BarcodeDrawFactory.CodeQr;
                    pb_qrcode.BackColor = Color.Transparent;
                    pb_qrcode.Image = qrCode.Draw(txt_qrcode.Text, 60);
                    lbl_qr.ForeColor = Color.Black;
                    lbl_saveinfo.Text = "";
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_email.Clear();
            txt_mobile.Clear();
            txt_name.Clear();
            txt_qrcode.Clear();
            txt_search.Clear();
            txt_UserID.Clear();
            rtxt_address.Clear();
            cb_age.SelectedIndex = -1;
            cb_course.SelectedIndex = -1;
            cb_dept.SelectedIndex = -1;
            cb_role.SelectedIndex = -1;
            User_ID();
            lbl_saveinfo.Text= "";
            ////
            con.Open();
            cmd = new SqlCommand("select * from Res_Images", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            byte[] image = (byte[])dt.Rows[0][1];
            MemoryStream ms = new MemoryStream(image);
            pb_student.Image = Image.FromStream(ms);

            SqlCommand cmd1 = new SqlCommand("select * from Res_Images", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            byte[] image1 = (byte[])dt1.Rows[1][1];
            MemoryStream ms1 = new MemoryStream(image1);
            pb_qrcode.Image = Image.FromStream(ms1);
            pb_qrcode.BackColor = Color.Crimson;
            con.Close();
        }

        private void UC_Student_Load(object sender, EventArgs e)
        {
            User_ID();
            lbl_saveinfo.Text = "";
        }

        string User_ID()
        {
            con.Open();
            cmd = new SqlCommand("select count(*) from Users", con);
            int a = 101 + (Int32)cmd.ExecuteScalar();
            string reg = "A" + a.ToString();
            txt_UserID.Text = reg;
            con.Close();
            return (reg);
        }

        private void btn_cam_Click(object sender, EventArgs e)
        {
            WindowsForms.WebCam w = new WindowsForms.WebCam();
            w.ShowDialog();
        }

        private void txt_UserID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt_name.Focus();
            }
        }

        private void txt_name_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                rtxt_address.Focus();
            }
        }

        private void rtxt_address_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                cb_age.Focus();
            }
        }

        private void cb_age_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                cb_course.Focus();
            }
        }

        private void cb_course_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                cb_dept.Focus();
            }
        }

        private void cb_dept_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt_email.Focus();
            }
        }

        private void txt_email_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt_mobile.Focus();
            }
        }

        private void txt_mobile_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                cb_role.Focus();
            }
        }

        private void cb_role_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btn_qrcode.Focus();
            }
        }

        private void btn_qrcode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btn_save.Focus();
            }
        }
    }
}
