﻿namespace Library
{
    partial class UC_Reports
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crpt_viewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.btn_student = new System.Windows.Forms.Button();
            this.btn_Book = new System.Windows.Forms.Button();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // crpt_viewer
            // 
            this.crpt_viewer.ActiveViewIndex = -1;
            this.crpt_viewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crpt_viewer.Cursor = System.Windows.Forms.Cursors.Default;
            this.crpt_viewer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crpt_viewer.Location = new System.Drawing.Point(0, 0);
            this.crpt_viewer.Margin = new System.Windows.Forms.Padding(6);
            this.crpt_viewer.Name = "crpt_viewer";
            this.crpt_viewer.Size = new System.Drawing.Size(1200, 720);
            this.crpt_viewer.TabIndex = 0;
            this.crpt_viewer.ToolPanelWidth = 220;
            // 
            // btn_student
            // 
            this.btn_student.BackColor = System.Drawing.Color.DimGray;
            this.btn_student.FlatAppearance.BorderSize = 0;
            this.btn_student.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_student.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_student.ForeColor = System.Drawing.Color.White;
            this.btn_student.Location = new System.Drawing.Point(0, 31);
            this.btn_student.Name = "btn_student";
            this.btn_student.Size = new System.Drawing.Size(220, 30);
            this.btn_student.TabIndex = 1;
            this.btn_student.Text = "Student Details";
            this.btn_student.UseVisualStyleBackColor = false;
            this.btn_student.Click += new System.EventHandler(this.btn_student_Click);
            // 
            // btn_Book
            // 
            this.btn_Book.BackColor = System.Drawing.Color.Gray;
            this.btn_Book.FlatAppearance.BorderSize = 0;
            this.btn_Book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Book.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Book.ForeColor = System.Drawing.Color.White;
            this.btn_Book.Location = new System.Drawing.Point(0, 63);
            this.btn_Book.Name = "btn_Book";
            this.btn_Book.Size = new System.Drawing.Size(220, 30);
            this.btn_Book.TabIndex = 2;
            this.btn_Book.Text = "Book Details";
            this.btn_Book.UseVisualStyleBackColor = false;
            this.btn_Book.Click += new System.EventHandler(this.btn_Book_Click);
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.BackColor = System.Drawing.Color.DimGray;
            this.btn_withdraw.FlatAppearance.BorderSize = 0;
            this.btn_withdraw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_withdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_withdraw.ForeColor = System.Drawing.Color.White;
            this.btn_withdraw.Location = new System.Drawing.Point(0, 95);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(220, 30);
            this.btn_withdraw.TabIndex = 3;
            this.btn_withdraw.Text = "Book Withdraw Details";
            this.btn_withdraw.UseVisualStyleBackColor = false;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // UC_Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btn_withdraw);
            this.Controls.Add(this.btn_Book);
            this.Controls.Add(this.btn_student);
            this.Controls.Add(this.crpt_viewer);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "UC_Reports";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_Reports_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer crpt_viewer;
        private System.Windows.Forms.Button btn_student;
        private System.Windows.Forms.Button btn_Book;
        private System.Windows.Forms.Button btn_withdraw;
    }
}
