﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library.UserControls
{
    public partial class UC_about : UserControl
    {
        public UC_about()
        {
            InitializeComponent();
        }

        private void linklbl_insta_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/ashfaq_naina/");
        }

        private void linklbl_facebook_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/ashfaq.naina.463");
        }

        private void linklbl_twitter_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://twitter.com/ashfaq_463");
        }

        private void linkLbl_facebookSuhaif_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/mohammed.suhaif.1");
        }

        private void UC_about_Load(object sender, EventArgs e)
        {

        }
    }
}
