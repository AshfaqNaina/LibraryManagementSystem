﻿namespace Library.UserControls
{
    partial class UC_about
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_about));
            this.lbl_head = new System.Windows.Forms.Label();
            this.pnl_Student = new System.Windows.Forms.Panel();
            this.pb_student = new System.Windows.Forms.PictureBox();
            this.linkLbl_facebookSuhaif = new System.Windows.Forms.LinkLabel();
            this.pb_face = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.linklbl_twitter = new System.Windows.Forms.LinkLabel();
            this.pb_twitter = new System.Windows.Forms.PictureBox();
            this.linklbl_whastapp = new System.Windows.Forms.LinkLabel();
            this.pb_whatsapp = new System.Windows.Forms.PictureBox();
            this.linklbl_insta = new System.Windows.Forms.LinkLabel();
            this.pb_insta = new System.Windows.Forms.PictureBox();
            this.linklbl_facebook = new System.Windows.Forms.LinkLabel();
            this.pb_facebook = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_description = new System.Windows.Forms.Label();
            this.pnl_StudentTop = new System.Windows.Forms.Panel();
            this.pnl_StudentBottom = new System.Windows.Forms.Panel();
            this.pnl_StudentRight = new System.Windows.Forms.Panel();
            this.pnl_StudentLeft = new System.Windows.Forms.Panel();
            this.pb_logo = new System.Windows.Forms.PictureBox();
            this.pnl_Student.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_face)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_twitter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_whatsapp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_insta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_facebook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(489, 48);
            this.lbl_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(285, 40);
            this.lbl_head.TabIndex = 136;
            this.lbl_head.Text = "About Library Soft";
            // 
            // pnl_Student
            // 
            this.pnl_Student.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_Student.Controls.Add(this.pb_student);
            this.pnl_Student.Controls.Add(this.linkLbl_facebookSuhaif);
            this.pnl_Student.Controls.Add(this.pb_face);
            this.pnl_Student.Controls.Add(this.label7);
            this.pnl_Student.Controls.Add(this.linklbl_twitter);
            this.pnl_Student.Controls.Add(this.pb_twitter);
            this.pnl_Student.Controls.Add(this.linklbl_whastapp);
            this.pnl_Student.Controls.Add(this.pb_whatsapp);
            this.pnl_Student.Controls.Add(this.linklbl_insta);
            this.pnl_Student.Controls.Add(this.pb_insta);
            this.pnl_Student.Controls.Add(this.linklbl_facebook);
            this.pnl_Student.Controls.Add(this.pb_facebook);
            this.pnl_Student.Controls.Add(this.label6);
            this.pnl_Student.Controls.Add(this.label5);
            this.pnl_Student.Controls.Add(this.label4);
            this.pnl_Student.Controls.Add(this.label3);
            this.pnl_Student.Controls.Add(this.label2);
            this.pnl_Student.Controls.Add(this.label1);
            this.pnl_Student.Controls.Add(this.lbl_description);
            this.pnl_Student.Controls.Add(this.pnl_StudentTop);
            this.pnl_Student.Controls.Add(this.pnl_StudentBottom);
            this.pnl_Student.Controls.Add(this.pnl_StudentRight);
            this.pnl_Student.Controls.Add(this.pnl_StudentLeft);
            this.pnl_Student.Location = new System.Drawing.Point(25, 120);
            this.pnl_Student.Name = "pnl_Student";
            this.pnl_Student.Size = new System.Drawing.Size(1151, 582);
            this.pnl_Student.TabIndex = 137;
            // 
            // pb_student
            // 
            this.pb_student.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_student.Image = global::Library.Properties.Resources.Ashfaq_01;
            this.pb_student.Location = new System.Drawing.Point(886, 102);
            this.pb_student.Name = "pb_student";
            this.pb_student.Size = new System.Drawing.Size(150, 180);
            this.pb_student.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_student.TabIndex = 144;
            this.pb_student.TabStop = false;
            // 
            // linkLbl_facebookSuhaif
            // 
            this.linkLbl_facebookSuhaif.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linkLbl_facebookSuhaif.AutoSize = true;
            this.linkLbl_facebookSuhaif.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_facebookSuhaif.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linkLbl_facebookSuhaif.Location = new System.Drawing.Point(435, 236);
            this.linkLbl_facebookSuhaif.Name = "linkLbl_facebookSuhaif";
            this.linkLbl_facebookSuhaif.Size = new System.Drawing.Size(120, 18);
            this.linkLbl_facebookSuhaif.TabIndex = 154;
            this.linkLbl_facebookSuhaif.TabStop = true;
            this.linkLbl_facebookSuhaif.Text = "Mohamed Suhaif";
            this.linkLbl_facebookSuhaif.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_facebookSuhaif_LinkClicked);
            // 
            // pb_face
            // 
            this.pb_face.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_face.Image = global::Library.Properties.Resources.Facebook_20;
            this.pb_face.Location = new System.Drawing.Point(412, 234);
            this.pb_face.Name = "pb_face";
            this.pb_face.Size = new System.Drawing.Size(20, 20);
            this.pb_face.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_face.TabIndex = 153;
            this.pb_face.TabStop = false;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(124, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(571, 48);
            this.label7.TabIndex = 152;
            this.label7.Text = "*Mohamed Suhaif,He is a back-end developer(MS-SQL) and\r\n server maintainance..\r\n";
            // 
            // linklbl_twitter
            // 
            this.linklbl_twitter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linklbl_twitter.AutoSize = true;
            this.linklbl_twitter.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklbl_twitter.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linklbl_twitter.Location = new System.Drawing.Point(516, 164);
            this.linklbl_twitter.Name = "linklbl_twitter";
            this.linklbl_twitter.Size = new System.Drawing.Size(99, 18);
            this.linklbl_twitter.TabIndex = 151;
            this.linklbl_twitter.TabStop = true;
            this.linklbl_twitter.Text = "@ashfaq_463";
            this.linklbl_twitter.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklbl_twitter_LinkClicked);
            // 
            // pb_twitter
            // 
            this.pb_twitter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_twitter.Image = global::Library.Properties.Resources.twitter_20;
            this.pb_twitter.Location = new System.Drawing.Point(493, 164);
            this.pb_twitter.Name = "pb_twitter";
            this.pb_twitter.Size = new System.Drawing.Size(20, 20);
            this.pb_twitter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_twitter.TabIndex = 150;
            this.pb_twitter.TabStop = false;
            // 
            // linklbl_whastapp
            // 
            this.linklbl_whastapp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linklbl_whastapp.AutoSize = true;
            this.linklbl_whastapp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklbl_whastapp.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linklbl_whastapp.Location = new System.Drawing.Point(653, 164);
            this.linklbl_whastapp.Name = "linklbl_whastapp";
            this.linklbl_whastapp.Size = new System.Drawing.Size(113, 18);
            this.linklbl_whastapp.TabIndex = 149;
            this.linklbl_whastapp.TabStop = true;
            this.linklbl_whastapp.Text = "+917339114440";
            // 
            // pb_whatsapp
            // 
            this.pb_whatsapp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_whatsapp.Image = global::Library.Properties.Resources.Whatsapp_20;
            this.pb_whatsapp.Location = new System.Drawing.Point(632, 163);
            this.pb_whatsapp.Name = "pb_whatsapp";
            this.pb_whatsapp.Size = new System.Drawing.Size(20, 20);
            this.pb_whatsapp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_whatsapp.TabIndex = 148;
            this.pb_whatsapp.TabStop = false;
            // 
            // linklbl_insta
            // 
            this.linklbl_insta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linklbl_insta.AutoSize = true;
            this.linklbl_insta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklbl_insta.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linklbl_insta.Location = new System.Drawing.Point(379, 164);
            this.linklbl_insta.Name = "linklbl_insta";
            this.linklbl_insta.Size = new System.Drawing.Size(102, 18);
            this.linklbl_insta.TabIndex = 147;
            this.linklbl_insta.TabStop = true;
            this.linklbl_insta.Text = "@ashfaqnaina";
            this.linklbl_insta.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklbl_insta_LinkClicked);
            // 
            // pb_insta
            // 
            this.pb_insta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_insta.Image = global::Library.Properties.Resources.Insta_small;
            this.pb_insta.Location = new System.Drawing.Point(355, 163);
            this.pb_insta.Name = "pb_insta";
            this.pb_insta.Size = new System.Drawing.Size(20, 20);
            this.pb_insta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_insta.TabIndex = 146;
            this.pb_insta.TabStop = false;
            // 
            // linklbl_facebook
            // 
            this.linklbl_facebook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linklbl_facebook.AutoSize = true;
            this.linklbl_facebook.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklbl_facebook.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linklbl_facebook.Location = new System.Drawing.Point(247, 165);
            this.linklbl_facebook.Name = "linklbl_facebook";
            this.linklbl_facebook.Size = new System.Drawing.Size(95, 18);
            this.linklbl_facebook.TabIndex = 145;
            this.linklbl_facebook.TabStop = true;
            this.linklbl_facebook.Text = "Ashfaq Naina";
            this.linklbl_facebook.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklbl_facebook_LinkClicked);
            // 
            // pb_facebook
            // 
            this.pb_facebook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_facebook.Image = global::Library.Properties.Resources.Facebook_20;
            this.pb_facebook.Location = new System.Drawing.Point(226, 163);
            this.pb_facebook.Name = "pb_facebook";
            this.pb_facebook.Size = new System.Drawing.Size(20, 20);
            this.pb_facebook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_facebook.TabIndex = 144;
            this.pb_facebook.TabStop = false;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(456, 553);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(238, 16);
            this.label6.TabIndex = 143;
            this.label6.Text = "CopyRight © 2020 All Rights Reserved.";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(124, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(619, 72);
            this.label5.TabIndex = 141;
            this.label5.Text = "*Ashfaq Naina,He is expert in developing windows applications.\r\n He is studying f" +
    "inal year BCA @ Jamal Mohamed College-Trichy \r\n\r\n";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label4.Location = new System.Drawing.Point(102, 274);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 32);
            this.label4.TabIndex = 140;
            this.label4.Text = "About Soft";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(124, 312);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(741, 48);
            this.label3.TabIndex = 139;
            this.label3.Text = "Library Soft was Developed by ASHFAQ NAINA to use C#.Net (Front end) and \r\nMS-SQL" +
    " Server (back end) in Visual Studio 2017 Enterprise.....";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label2.Location = new System.Drawing.Point(102, 65);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(214, 32);
            this.label2.TabIndex = 138;
            this.label2.Text = "About Developers";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label1.Location = new System.Drawing.Point(102, 383);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 32);
            this.label1.TabIndex = 137;
            this.label1.Text = "Description";
            // 
            // lbl_description
            // 
            this.lbl_description.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_description.AutoSize = true;
            this.lbl_description.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_description.Location = new System.Drawing.Point(124, 424);
            this.lbl_description.Name = "lbl_description";
            this.lbl_description.Size = new System.Drawing.Size(814, 96);
            this.lbl_description.TabIndex = 123;
            this.lbl_description.Text = resources.GetString("lbl_description.Text");
            // 
            // pnl_StudentTop
            // 
            this.pnl_StudentTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_StudentTop.Location = new System.Drawing.Point(3, 0);
            this.pnl_StudentTop.Name = "pnl_StudentTop";
            this.pnl_StudentTop.Size = new System.Drawing.Size(1145, 3);
            this.pnl_StudentTop.TabIndex = 122;
            // 
            // pnl_StudentBottom
            // 
            this.pnl_StudentBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_StudentBottom.Location = new System.Drawing.Point(3, 579);
            this.pnl_StudentBottom.Name = "pnl_StudentBottom";
            this.pnl_StudentBottom.Size = new System.Drawing.Size(1145, 3);
            this.pnl_StudentBottom.TabIndex = 121;
            // 
            // pnl_StudentRight
            // 
            this.pnl_StudentRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_StudentRight.Location = new System.Drawing.Point(1148, 0);
            this.pnl_StudentRight.Name = "pnl_StudentRight";
            this.pnl_StudentRight.Size = new System.Drawing.Size(3, 582);
            this.pnl_StudentRight.TabIndex = 120;
            // 
            // pnl_StudentLeft
            // 
            this.pnl_StudentLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_StudentLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_StudentLeft.Name = "pnl_StudentLeft";
            this.pnl_StudentLeft.Size = new System.Drawing.Size(3, 582);
            this.pnl_StudentLeft.TabIndex = 119;
            // 
            // pb_logo
            // 
            this.pb_logo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_logo.Image = global::Library.Properties.Resources.Library;
            this.pb_logo.Location = new System.Drawing.Point(420, 36);
            this.pb_logo.Name = "pb_logo";
            this.pb_logo.Size = new System.Drawing.Size(71, 66);
            this.pb_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_logo.TabIndex = 138;
            this.pb_logo.TabStop = false;
            // 
            // UC_about
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pb_logo);
            this.Controls.Add(this.pnl_Student);
            this.Controls.Add(this.lbl_head);
            this.Name = "UC_about";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_about_Load);
            this.pnl_Student.ResumeLayout(false);
            this.pnl_Student.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_face)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_twitter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_whatsapp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_insta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_facebook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.Panel pnl_Student;
        private System.Windows.Forms.Panel pnl_StudentTop;
        private System.Windows.Forms.Panel pnl_StudentBottom;
        private System.Windows.Forms.Panel pnl_StudentRight;
        private System.Windows.Forms.Panel pnl_StudentLeft;
        private System.Windows.Forms.PictureBox pb_logo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_description;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.LinkLabel linklbl_whastapp;
        private System.Windows.Forms.PictureBox pb_whatsapp;
        private System.Windows.Forms.LinkLabel linklbl_insta;
        private System.Windows.Forms.PictureBox pb_insta;
        private System.Windows.Forms.LinkLabel linklbl_facebook;
        private System.Windows.Forms.PictureBox pb_facebook;
        private System.Windows.Forms.LinkLabel linklbl_twitter;
        private System.Windows.Forms.PictureBox pb_twitter;
        private System.Windows.Forms.LinkLabel linkLbl_facebookSuhaif;
        private System.Windows.Forms.PictureBox pb_face;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pb_student;
    }
}
