﻿namespace Library.UserControls
{
    partial class UC_about
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_about));
            this.lbl_head = new System.Windows.Forms.Label();
            this.pnl_Student = new System.Windows.Forms.Panel();
            this.lbl_pbSuhaif = new System.Windows.Forms.Label();
            this.lbl_pbAsh = new System.Windows.Forms.Label();
            this.lbl_developersAsh = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pb_suhaif = new System.Windows.Forms.PictureBox();
            this.pb_student = new System.Windows.Forms.PictureBox();
            this.linkLbl_facebookSuhaif = new System.Windows.Forms.LinkLabel();
            this.pb_face = new System.Windows.Forms.PictureBox();
            this.lbl_suhaifDescription = new System.Windows.Forms.Label();
            this.linklbl_twitter = new System.Windows.Forms.LinkLabel();
            this.pb_twitter = new System.Windows.Forms.PictureBox();
            this.linklbl_whastapp = new System.Windows.Forms.LinkLabel();
            this.pb_whatsapp = new System.Windows.Forms.PictureBox();
            this.linklbl_insta = new System.Windows.Forms.LinkLabel();
            this.pb_insta = new System.Windows.Forms.PictureBox();
            this.linklbl_facebook = new System.Windows.Forms.LinkLabel();
            this.pb_facebook = new System.Windows.Forms.PictureBox();
            this.lbl_copy1 = new System.Windows.Forms.Label();
            this.lbl_ashDescription = new System.Windows.Forms.Label();
            this.lbl_aboutSoft = new System.Windows.Forms.Label();
            this.lbl_about_soft = new System.Windows.Forms.Label();
            this.lbl_aboutDevelopersHead = new System.Windows.Forms.Label();
            this.lbl_description_head = new System.Windows.Forms.Label();
            this.lbl_description = new System.Windows.Forms.Label();
            this.pnl_StudentTop = new System.Windows.Forms.Panel();
            this.pnl_StudentBottom = new System.Windows.Forms.Panel();
            this.pnl_StudentRight = new System.Windows.Forms.Panel();
            this.pnl_StudentLeft = new System.Windows.Forms.Panel();
            this.pnl_fans = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.linkLbl_sakthi_Insta = new System.Windows.Forms.LinkLabel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.linkLbl_sakthi_Facebook = new System.Windows.Forms.LinkLabel();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.linkLbl_musthafa_Insta = new System.Windows.Forms.LinkLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.linkLbl_musthafa_Facebook = new System.Windows.Forms.LinkLabel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pb_sakthi = new System.Windows.Forms.PictureBox();
            this.pb_musthafa = new System.Windows.Forms.PictureBox();
            this.pb_abdul = new System.Windows.Forms.PictureBox();
            this.linkLbl_abdul_Insta = new System.Windows.Forms.LinkLabel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.linkLbl_abdul_Facebook = new System.Windows.Forms.LinkLabel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.lbl_copy2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.timer_about = new System.Windows.Forms.Timer(this.components);
            this.pb_logo = new System.Windows.Forms.PictureBox();
            this.pnl_Student.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_suhaif)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_face)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_twitter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_whatsapp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_insta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_facebook)).BeginInit();
            this.pnl_fans.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_sakthi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_musthafa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_abdul)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(489, 37);
            this.lbl_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(285, 40);
            this.lbl_head.TabIndex = 136;
            this.lbl_head.Text = "About Library Soft";
            // 
            // pnl_Student
            // 
            this.pnl_Student.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_Student.Controls.Add(this.lbl_pbSuhaif);
            this.pnl_Student.Controls.Add(this.lbl_pbAsh);
            this.pnl_Student.Controls.Add(this.lbl_developersAsh);
            this.pnl_Student.Controls.Add(this.linkLabel1);
            this.pnl_Student.Controls.Add(this.pictureBox2);
            this.pnl_Student.Controls.Add(this.pb_suhaif);
            this.pnl_Student.Controls.Add(this.pb_student);
            this.pnl_Student.Controls.Add(this.linkLbl_facebookSuhaif);
            this.pnl_Student.Controls.Add(this.pb_face);
            this.pnl_Student.Controls.Add(this.lbl_suhaifDescription);
            this.pnl_Student.Controls.Add(this.linklbl_twitter);
            this.pnl_Student.Controls.Add(this.pb_twitter);
            this.pnl_Student.Controls.Add(this.linklbl_whastapp);
            this.pnl_Student.Controls.Add(this.pb_whatsapp);
            this.pnl_Student.Controls.Add(this.linklbl_insta);
            this.pnl_Student.Controls.Add(this.pb_insta);
            this.pnl_Student.Controls.Add(this.linklbl_facebook);
            this.pnl_Student.Controls.Add(this.pb_facebook);
            this.pnl_Student.Controls.Add(this.lbl_copy1);
            this.pnl_Student.Controls.Add(this.lbl_ashDescription);
            this.pnl_Student.Controls.Add(this.lbl_aboutSoft);
            this.pnl_Student.Controls.Add(this.lbl_about_soft);
            this.pnl_Student.Controls.Add(this.lbl_aboutDevelopersHead);
            this.pnl_Student.Controls.Add(this.lbl_description_head);
            this.pnl_Student.Controls.Add(this.lbl_description);
            this.pnl_Student.Controls.Add(this.pnl_StudentTop);
            this.pnl_Student.Controls.Add(this.pnl_StudentBottom);
            this.pnl_Student.Controls.Add(this.pnl_StudentRight);
            this.pnl_Student.Controls.Add(this.pnl_StudentLeft);
            this.pnl_Student.Location = new System.Drawing.Point(25, 94);
            this.pnl_Student.Name = "pnl_Student";
            this.pnl_Student.Size = new System.Drawing.Size(1150, 600);
            this.pnl_Student.TabIndex = 137;
            // 
            // lbl_pbSuhaif
            // 
            this.lbl_pbSuhaif.AutoSize = true;
            this.lbl_pbSuhaif.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_pbSuhaif.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pbSuhaif.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_pbSuhaif.Location = new System.Drawing.Point(929, 281);
            this.lbl_pbSuhaif.Name = "lbl_pbSuhaif";
            this.lbl_pbSuhaif.Size = new System.Drawing.Size(167, 24);
            this.lbl_pbSuhaif.TabIndex = 160;
            this.lbl_pbSuhaif.Text = "Mohamed Suhaif";
            // 
            // lbl_pbAsh
            // 
            this.lbl_pbAsh.AutoSize = true;
            this.lbl_pbAsh.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_pbAsh.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pbAsh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_pbAsh.Location = new System.Drawing.Point(773, 281);
            this.lbl_pbAsh.Name = "lbl_pbAsh";
            this.lbl_pbAsh.Size = new System.Drawing.Size(134, 24);
            this.lbl_pbAsh.TabIndex = 159;
            this.lbl_pbAsh.Text = "Ashfaq Naina";
            // 
            // lbl_developersAsh
            // 
            this.lbl_developersAsh.AutoSize = true;
            this.lbl_developersAsh.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_developersAsh.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_developersAsh.ForeColor = System.Drawing.Color.Red;
            this.lbl_developersAsh.Location = new System.Drawing.Point(368, 330);
            this.lbl_developersAsh.Name = "lbl_developersAsh";
            this.lbl_developersAsh.Size = new System.Drawing.Size(164, 24);
            this.lbl_developersAsh.TabIndex = 158;
            this.lbl_developersAsh.Text = "ASHFAQ NAINA";
            // 
            // linkLabel1
            // 
            this.linkLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linkLabel1.Location = new System.Drawing.Point(533, 249);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(117, 18);
            this.linkLabel1.TabIndex = 157;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "+91 9003892841";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Image = global::Library.Properties.Resources.Whatsapp_20;
            this.pictureBox2.Location = new System.Drawing.Point(512, 248);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 20);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 156;
            this.pictureBox2.TabStop = false;
            // 
            // pb_suhaif
            // 
            this.pb_suhaif.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_suhaif.Image = global::Library.Properties.Resources.Mohamed_Suhaif;
            this.pb_suhaif.Location = new System.Drawing.Point(937, 101);
            this.pb_suhaif.Name = "pb_suhaif";
            this.pb_suhaif.Size = new System.Drawing.Size(146, 180);
            this.pb_suhaif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_suhaif.TabIndex = 155;
            this.pb_suhaif.TabStop = false;
            // 
            // pb_student
            // 
            this.pb_student.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_student.Image = global::Library.Properties.Resources.Ashfaq_01;
            this.pb_student.Location = new System.Drawing.Point(760, 101);
            this.pb_student.Name = "pb_student";
            this.pb_student.Size = new System.Drawing.Size(154, 180);
            this.pb_student.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_student.TabIndex = 144;
            this.pb_student.TabStop = false;
            // 
            // linkLbl_facebookSuhaif
            // 
            this.linkLbl_facebookSuhaif.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linkLbl_facebookSuhaif.AutoSize = true;
            this.linkLbl_facebookSuhaif.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_facebookSuhaif.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linkLbl_facebookSuhaif.Location = new System.Drawing.Point(370, 249);
            this.linkLbl_facebookSuhaif.Name = "linkLbl_facebookSuhaif";
            this.linkLbl_facebookSuhaif.Size = new System.Drawing.Size(120, 18);
            this.linkLbl_facebookSuhaif.TabIndex = 154;
            this.linkLbl_facebookSuhaif.TabStop = true;
            this.linkLbl_facebookSuhaif.Text = "Mohamed Suhaif";
            this.linkLbl_facebookSuhaif.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_facebookSuhaif_LinkClicked);
            // 
            // pb_face
            // 
            this.pb_face.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_face.Image = global::Library.Properties.Resources.Facebook_20;
            this.pb_face.Location = new System.Drawing.Point(347, 247);
            this.pb_face.Name = "pb_face";
            this.pb_face.Size = new System.Drawing.Size(20, 20);
            this.pb_face.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_face.TabIndex = 153;
            this.pb_face.TabStop = false;
            // 
            // lbl_suhaifDescription
            // 
            this.lbl_suhaifDescription.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_suhaifDescription.AutoSize = true;
            this.lbl_suhaifDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_suhaifDescription.Location = new System.Drawing.Point(75, 215);
            this.lbl_suhaifDescription.Name = "lbl_suhaifDescription";
            this.lbl_suhaifDescription.Size = new System.Drawing.Size(571, 48);
            this.lbl_suhaifDescription.TabIndex = 152;
            this.lbl_suhaifDescription.Text = "*Mohamed Suhaif,He is a back-end developer(MS-SQL) and\r\n server maintainance..\r\n";
            // 
            // linklbl_twitter
            // 
            this.linklbl_twitter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linklbl_twitter.AutoSize = true;
            this.linklbl_twitter.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklbl_twitter.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linklbl_twitter.Location = new System.Drawing.Point(396, 173);
            this.linklbl_twitter.Name = "linklbl_twitter";
            this.linklbl_twitter.Size = new System.Drawing.Size(99, 18);
            this.linklbl_twitter.TabIndex = 151;
            this.linklbl_twitter.TabStop = true;
            this.linklbl_twitter.Text = "@ashfaq_463";
            this.linklbl_twitter.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklbl_twitter_LinkClicked);
            // 
            // pb_twitter
            // 
            this.pb_twitter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_twitter.Image = global::Library.Properties.Resources.twitter_20;
            this.pb_twitter.Location = new System.Drawing.Point(373, 173);
            this.pb_twitter.Name = "pb_twitter";
            this.pb_twitter.Size = new System.Drawing.Size(20, 20);
            this.pb_twitter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_twitter.TabIndex = 150;
            this.pb_twitter.TabStop = false;
            // 
            // linklbl_whastapp
            // 
            this.linklbl_whastapp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linklbl_whastapp.AutoSize = true;
            this.linklbl_whastapp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklbl_whastapp.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linklbl_whastapp.Location = new System.Drawing.Point(533, 173);
            this.linklbl_whastapp.Name = "linklbl_whastapp";
            this.linklbl_whastapp.Size = new System.Drawing.Size(117, 18);
            this.linklbl_whastapp.TabIndex = 149;
            this.linklbl_whastapp.TabStop = true;
            this.linklbl_whastapp.Text = "+91 7339114440";
            // 
            // pb_whatsapp
            // 
            this.pb_whatsapp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_whatsapp.Image = global::Library.Properties.Resources.Whatsapp_20;
            this.pb_whatsapp.Location = new System.Drawing.Point(512, 172);
            this.pb_whatsapp.Name = "pb_whatsapp";
            this.pb_whatsapp.Size = new System.Drawing.Size(20, 20);
            this.pb_whatsapp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_whatsapp.TabIndex = 148;
            this.pb_whatsapp.TabStop = false;
            // 
            // linklbl_insta
            // 
            this.linklbl_insta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linklbl_insta.AutoSize = true;
            this.linklbl_insta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklbl_insta.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linklbl_insta.Location = new System.Drawing.Point(259, 173);
            this.linklbl_insta.Name = "linklbl_insta";
            this.linklbl_insta.Size = new System.Drawing.Size(102, 18);
            this.linklbl_insta.TabIndex = 147;
            this.linklbl_insta.TabStop = true;
            this.linklbl_insta.Text = "@ashfaqnaina";
            this.linklbl_insta.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklbl_insta_LinkClicked);
            // 
            // pb_insta
            // 
            this.pb_insta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_insta.Image = global::Library.Properties.Resources.Insta_small;
            this.pb_insta.Location = new System.Drawing.Point(235, 172);
            this.pb_insta.Name = "pb_insta";
            this.pb_insta.Size = new System.Drawing.Size(20, 20);
            this.pb_insta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_insta.TabIndex = 146;
            this.pb_insta.TabStop = false;
            // 
            // linklbl_facebook
            // 
            this.linklbl_facebook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linklbl_facebook.AutoSize = true;
            this.linklbl_facebook.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklbl_facebook.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linklbl_facebook.Location = new System.Drawing.Point(127, 174);
            this.linklbl_facebook.Name = "linklbl_facebook";
            this.linklbl_facebook.Size = new System.Drawing.Size(95, 18);
            this.linklbl_facebook.TabIndex = 145;
            this.linklbl_facebook.TabStop = true;
            this.linklbl_facebook.Text = "Ashfaq Naina";
            this.linklbl_facebook.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklbl_facebook_LinkClicked);
            // 
            // pb_facebook
            // 
            this.pb_facebook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_facebook.Image = global::Library.Properties.Resources.Facebook_20;
            this.pb_facebook.Location = new System.Drawing.Point(106, 172);
            this.pb_facebook.Name = "pb_facebook";
            this.pb_facebook.Size = new System.Drawing.Size(20, 20);
            this.pb_facebook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_facebook.TabIndex = 144;
            this.pb_facebook.TabStop = false;
            // 
            // lbl_copy1
            // 
            this.lbl_copy1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_copy1.AutoSize = true;
            this.lbl_copy1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_copy1.Location = new System.Drawing.Point(456, 562);
            this.lbl_copy1.Name = "lbl_copy1";
            this.lbl_copy1.Size = new System.Drawing.Size(238, 16);
            this.lbl_copy1.TabIndex = 143;
            this.lbl_copy1.Text = "CopyRight © 2020 All Rights Reserved.";
            // 
            // lbl_ashDescription
            // 
            this.lbl_ashDescription.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_ashDescription.AutoSize = true;
            this.lbl_ashDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ashDescription.Location = new System.Drawing.Point(75, 113);
            this.lbl_ashDescription.Name = "lbl_ashDescription";
            this.lbl_ashDescription.Size = new System.Drawing.Size(619, 72);
            this.lbl_ashDescription.TabIndex = 141;
            this.lbl_ashDescription.Text = "*Ashfaq Naina,He is expert in developing windows applications.\r\n He is studying f" +
    "inal year BCA @ Jamal Mohamed College-Trichy.\r\n\r\n";
            // 
            // lbl_aboutSoft
            // 
            this.lbl_aboutSoft.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_aboutSoft.AutoSize = true;
            this.lbl_aboutSoft.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aboutSoft.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_aboutSoft.Location = new System.Drawing.Point(53, 281);
            this.lbl_aboutSoft.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_aboutSoft.Name = "lbl_aboutSoft";
            this.lbl_aboutSoft.Size = new System.Drawing.Size(135, 32);
            this.lbl_aboutSoft.TabIndex = 140;
            this.lbl_aboutSoft.Text = "About Soft";
            // 
            // lbl_about_soft
            // 
            this.lbl_about_soft.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_about_soft.AutoSize = true;
            this.lbl_about_soft.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_about_soft.Location = new System.Drawing.Point(75, 331);
            this.lbl_about_soft.Name = "lbl_about_soft";
            this.lbl_about_soft.Size = new System.Drawing.Size(755, 48);
            this.lbl_about_soft.TabIndex = 139;
            this.lbl_about_soft.Text = "Library Soft was Developed by                              to use C#.Net (Front e" +
    "nd) and \r\nMS-SQL Server (back end) in Visual Studio 2017 Enterprise.....";
            // 
            // lbl_aboutDevelopersHead
            // 
            this.lbl_aboutDevelopersHead.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_aboutDevelopersHead.AutoSize = true;
            this.lbl_aboutDevelopersHead.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aboutDevelopersHead.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_aboutDevelopersHead.Location = new System.Drawing.Point(53, 59);
            this.lbl_aboutDevelopersHead.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_aboutDevelopersHead.Name = "lbl_aboutDevelopersHead";
            this.lbl_aboutDevelopersHead.Size = new System.Drawing.Size(214, 32);
            this.lbl_aboutDevelopersHead.TabIndex = 138;
            this.lbl_aboutDevelopersHead.Text = "About Developers";
            // 
            // lbl_description_head
            // 
            this.lbl_description_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_description_head.AutoSize = true;
            this.lbl_description_head.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_description_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_description_head.Location = new System.Drawing.Point(53, 402);
            this.lbl_description_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_description_head.Name = "lbl_description_head";
            this.lbl_description_head.Size = new System.Drawing.Size(144, 32);
            this.lbl_description_head.TabIndex = 137;
            this.lbl_description_head.Text = "Description";
            // 
            // lbl_description
            // 
            this.lbl_description.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_description.AutoSize = true;
            this.lbl_description.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_description.Location = new System.Drawing.Point(75, 443);
            this.lbl_description.Name = "lbl_description";
            this.lbl_description.Size = new System.Drawing.Size(814, 96);
            this.lbl_description.TabIndex = 123;
            this.lbl_description.Text = resources.GetString("lbl_description.Text");
            // 
            // pnl_StudentTop
            // 
            this.pnl_StudentTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_StudentTop.Location = new System.Drawing.Point(3, 0);
            this.pnl_StudentTop.Name = "pnl_StudentTop";
            this.pnl_StudentTop.Size = new System.Drawing.Size(1144, 3);
            this.pnl_StudentTop.TabIndex = 122;
            // 
            // pnl_StudentBottom
            // 
            this.pnl_StudentBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_StudentBottom.Location = new System.Drawing.Point(3, 597);
            this.pnl_StudentBottom.Name = "pnl_StudentBottom";
            this.pnl_StudentBottom.Size = new System.Drawing.Size(1144, 3);
            this.pnl_StudentBottom.TabIndex = 121;
            // 
            // pnl_StudentRight
            // 
            this.pnl_StudentRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_StudentRight.Location = new System.Drawing.Point(1147, 0);
            this.pnl_StudentRight.Name = "pnl_StudentRight";
            this.pnl_StudentRight.Size = new System.Drawing.Size(3, 600);
            this.pnl_StudentRight.TabIndex = 120;
            // 
            // pnl_StudentLeft
            // 
            this.pnl_StudentLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_StudentLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_StudentLeft.Name = "pnl_StudentLeft";
            this.pnl_StudentLeft.Size = new System.Drawing.Size(3, 600);
            this.pnl_StudentLeft.TabIndex = 119;
            // 
            // pnl_fans
            // 
            this.pnl_fans.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_fans.Controls.Add(this.label3);
            this.pnl_fans.Controls.Add(this.label2);
            this.pnl_fans.Controls.Add(this.label1);
            this.pnl_fans.Controls.Add(this.linkLbl_sakthi_Insta);
            this.pnl_fans.Controls.Add(this.pictureBox9);
            this.pnl_fans.Controls.Add(this.linkLbl_sakthi_Facebook);
            this.pnl_fans.Controls.Add(this.pictureBox10);
            this.pnl_fans.Controls.Add(this.linkLbl_musthafa_Insta);
            this.pnl_fans.Controls.Add(this.pictureBox3);
            this.pnl_fans.Controls.Add(this.linkLbl_musthafa_Facebook);
            this.pnl_fans.Controls.Add(this.pictureBox4);
            this.pnl_fans.Controls.Add(this.pb_sakthi);
            this.pnl_fans.Controls.Add(this.pb_musthafa);
            this.pnl_fans.Controls.Add(this.pb_abdul);
            this.pnl_fans.Controls.Add(this.linkLbl_abdul_Insta);
            this.pnl_fans.Controls.Add(this.pictureBox5);
            this.pnl_fans.Controls.Add(this.linkLbl_abdul_Facebook);
            this.pnl_fans.Controls.Add(this.pictureBox6);
            this.pnl_fans.Controls.Add(this.lbl_copy2);
            this.pnl_fans.Controls.Add(this.label13);
            this.pnl_fans.Controls.Add(this.panel2);
            this.pnl_fans.Controls.Add(this.panel3);
            this.pnl_fans.Controls.Add(this.panel4);
            this.pnl_fans.Controls.Add(this.panel5);
            this.pnl_fans.Location = new System.Drawing.Point(25, 94);
            this.pnl_fans.Name = "pnl_fans";
            this.pnl_fans.Size = new System.Drawing.Size(1150, 600);
            this.pnl_fans.TabIndex = 155;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label3.Location = new System.Drawing.Point(849, 357);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 24);
            this.label3.TabIndex = 167;
            this.label3.Text = "SAKTHIVEL";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label2.Location = new System.Drawing.Point(459, 357);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(217, 24);
            this.label2.TabIndex = 166;
            this.label2.Text = "AHAMED MUSTHAFA";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label1.Location = new System.Drawing.Point(136, 357);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 24);
            this.label1.TabIndex = 165;
            this.label1.Text = "ABDUL RAHMAN";
            // 
            // linkLbl_sakthi_Insta
            // 
            this.linkLbl_sakthi_Insta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linkLbl_sakthi_Insta.AutoSize = true;
            this.linkLbl_sakthi_Insta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_sakthi_Insta.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linkLbl_sakthi_Insta.Location = new System.Drawing.Point(932, 404);
            this.linkLbl_sakthi_Insta.Name = "linkLbl_sakthi_Insta";
            this.linkLbl_sakthi_Insta.Size = new System.Drawing.Size(119, 18);
            this.linkLbl_sakthi_Insta.TabIndex = 164;
            this.linkLbl_sakthi_Insta.TabStop = true;
            this.linkLbl_sakthi_Insta.Text = "@karathe_sakthi";
            this.linkLbl_sakthi_Insta.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_sakthi_Insta_LinkClicked);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox9.Image = global::Library.Properties.Resources.Insta_small;
            this.pictureBox9.Location = new System.Drawing.Point(908, 403);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(20, 20);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox9.TabIndex = 163;
            this.pictureBox9.TabStop = false;
            // 
            // linkLbl_sakthi_Facebook
            // 
            this.linkLbl_sakthi_Facebook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linkLbl_sakthi_Facebook.AutoSize = true;
            this.linkLbl_sakthi_Facebook.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_sakthi_Facebook.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linkLbl_sakthi_Facebook.Location = new System.Drawing.Point(797, 404);
            this.linkLbl_sakthi_Facebook.Name = "linkLbl_sakthi_Facebook";
            this.linkLbl_sakthi_Facebook.Size = new System.Drawing.Size(104, 18);
            this.linkLbl_sakthi_Facebook.TabIndex = 162;
            this.linkLbl_sakthi_Facebook.TabStop = true;
            this.linkLbl_sakthi_Facebook.Text = "Karathe Sakthi";
            this.linkLbl_sakthi_Facebook.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_sakthi_Facebook_LinkClicked);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox10.Image = global::Library.Properties.Resources.Facebook_20;
            this.pictureBox10.Location = new System.Drawing.Point(776, 402);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(20, 20);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox10.TabIndex = 161;
            this.pictureBox10.TabStop = false;
            // 
            // linkLbl_musthafa_Insta
            // 
            this.linkLbl_musthafa_Insta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linkLbl_musthafa_Insta.AutoSize = true;
            this.linkLbl_musthafa_Insta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_musthafa_Insta.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linkLbl_musthafa_Insta.Location = new System.Drawing.Point(582, 405);
            this.linkLbl_musthafa_Insta.Name = "linkLbl_musthafa_Insta";
            this.linkLbl_musthafa_Insta.Size = new System.Drawing.Size(130, 18);
            this.linkLbl_musthafa_Insta.TabIndex = 160;
            this.linkLbl_musthafa_Insta.TabStop = true;
            this.linkLbl_musthafa_Insta.Text = "@innocent_kid_06";
            this.linkLbl_musthafa_Insta.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_musthafa_Insta_LinkClicked);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox3.Image = global::Library.Properties.Resources.Insta_small;
            this.pictureBox3.Location = new System.Drawing.Point(558, 404);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(20, 20);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 159;
            this.pictureBox3.TabStop = false;
            // 
            // linkLbl_musthafa_Facebook
            // 
            this.linkLbl_musthafa_Facebook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linkLbl_musthafa_Facebook.AutoSize = true;
            this.linkLbl_musthafa_Facebook.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_musthafa_Facebook.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linkLbl_musthafa_Facebook.Location = new System.Drawing.Point(447, 405);
            this.linkLbl_musthafa_Facebook.Name = "linkLbl_musthafa_Facebook";
            this.linkLbl_musthafa_Facebook.Size = new System.Drawing.Size(94, 18);
            this.linkLbl_musthafa_Facebook.TabIndex = 158;
            this.linkLbl_musthafa_Facebook.TabStop = true;
            this.linkLbl_musthafa_Facebook.Text = "Musthafa SD";
            this.linkLbl_musthafa_Facebook.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_musthafa_Facebook_LinkClicked);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox4.Image = global::Library.Properties.Resources.Facebook_20;
            this.pictureBox4.Location = new System.Drawing.Point(426, 403);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(20, 20);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 157;
            this.pictureBox4.TabStop = false;
            // 
            // pb_sakthi
            // 
            this.pb_sakthi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_sakthi.Image = global::Library.Properties.Resources.Sakthi_karathe;
            this.pb_sakthi.Location = new System.Drawing.Point(828, 136);
            this.pb_sakthi.Name = "pb_sakthi";
            this.pb_sakthi.Size = new System.Drawing.Size(158, 200);
            this.pb_sakthi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_sakthi.TabIndex = 156;
            this.pb_sakthi.TabStop = false;
            // 
            // pb_musthafa
            // 
            this.pb_musthafa.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_musthafa.Image = global::Library.Properties.Resources.Ahamed_Musthafa;
            this.pb_musthafa.Location = new System.Drawing.Point(496, 136);
            this.pb_musthafa.Name = "pb_musthafa";
            this.pb_musthafa.Size = new System.Drawing.Size(150, 200);
            this.pb_musthafa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_musthafa.TabIndex = 155;
            this.pb_musthafa.TabStop = false;
            // 
            // pb_abdul
            // 
            this.pb_abdul.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_abdul.Image = global::Library.Properties.Resources.Abdul_Rahman;
            this.pb_abdul.Location = new System.Drawing.Point(145, 136);
            this.pb_abdul.Name = "pb_abdul";
            this.pb_abdul.Size = new System.Drawing.Size(150, 200);
            this.pb_abdul.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_abdul.TabIndex = 144;
            this.pb_abdul.TabStop = false;
            // 
            // linkLbl_abdul_Insta
            // 
            this.linkLbl_abdul_Insta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linkLbl_abdul_Insta.AutoSize = true;
            this.linkLbl_abdul_Insta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_abdul_Insta.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linkLbl_abdul_Insta.Location = new System.Drawing.Point(232, 406);
            this.linkLbl_abdul_Insta.Name = "linkLbl_abdul_Insta";
            this.linkLbl_abdul_Insta.Size = new System.Drawing.Size(100, 18);
            this.linkLbl_abdul_Insta.TabIndex = 147;
            this.linkLbl_abdul_Insta.TabStop = true;
            this.linkLbl_abdul_Insta.Text = "@_riyasome_";
            this.linkLbl_abdul_Insta.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_abdul_Insta_LinkClicked);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox5.Image = global::Library.Properties.Resources.Insta_small;
            this.pictureBox5.Location = new System.Drawing.Point(208, 405);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(20, 20);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox5.TabIndex = 146;
            this.pictureBox5.TabStop = false;
            // 
            // linkLbl_abdul_Facebook
            // 
            this.linkLbl_abdul_Facebook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.linkLbl_abdul_Facebook.AutoSize = true;
            this.linkLbl_abdul_Facebook.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_abdul_Facebook.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.linkLbl_abdul_Facebook.Location = new System.Drawing.Point(114, 406);
            this.linkLbl_abdul_Facebook.Name = "linkLbl_abdul_Facebook";
            this.linkLbl_abdul_Facebook.Size = new System.Drawing.Size(75, 18);
            this.linkLbl_abdul_Facebook.TabIndex = 145;
            this.linkLbl_abdul_Facebook.TabStop = true;
            this.linkLbl_abdul_Facebook.Text = "Riyasome";
            this.linkLbl_abdul_Facebook.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_abdul_Facebook_LinkClicked);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox6.Image = global::Library.Properties.Resources.Facebook_20;
            this.pictureBox6.Location = new System.Drawing.Point(93, 404);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(20, 20);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox6.TabIndex = 144;
            this.pictureBox6.TabStop = false;
            // 
            // lbl_copy2
            // 
            this.lbl_copy2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_copy2.AutoSize = true;
            this.lbl_copy2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_copy2.Location = new System.Drawing.Point(456, 562);
            this.lbl_copy2.Name = "lbl_copy2";
            this.lbl_copy2.Size = new System.Drawing.Size(238, 16);
            this.lbl_copy2.TabIndex = 143;
            this.lbl_copy2.Text = "CopyRight © 2020 All Rights Reserved.";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label13.Location = new System.Drawing.Point(53, 47);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(141, 32);
            this.label13.TabIndex = 138;
            this.label13.Text = "Our Clients";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1144, 3);
            this.panel2.TabIndex = 122;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(3, 597);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1144, 3);
            this.panel3.TabIndex = 121;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(1147, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 600);
            this.panel4.TabIndex = 120;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 600);
            this.panel5.TabIndex = 119;
            // 
            // timer_about
            // 
            this.timer_about.Tick += new System.EventHandler(this.timer_about_Tick);
            // 
            // pb_logo
            // 
            this.pb_logo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_logo.Image = global::Library.Properties.Resources.Library;
            this.pb_logo.Location = new System.Drawing.Point(420, 25);
            this.pb_logo.Name = "pb_logo";
            this.pb_logo.Size = new System.Drawing.Size(71, 66);
            this.pb_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_logo.TabIndex = 138;
            this.pb_logo.TabStop = false;
            // 
            // UC_about
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pb_logo);
            this.Controls.Add(this.lbl_head);
            this.Controls.Add(this.pnl_Student);
            this.Controls.Add(this.pnl_fans);
            this.Name = "UC_about";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_about_Load);
            this.pnl_Student.ResumeLayout(false);
            this.pnl_Student.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_suhaif)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_face)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_twitter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_whatsapp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_insta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_facebook)).EndInit();
            this.pnl_fans.ResumeLayout(false);
            this.pnl_fans.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_sakthi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_musthafa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_abdul)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.Panel pnl_Student;
        private System.Windows.Forms.Panel pnl_StudentTop;
        private System.Windows.Forms.Panel pnl_StudentBottom;
        private System.Windows.Forms.Panel pnl_StudentRight;
        private System.Windows.Forms.Panel pnl_StudentLeft;
        private System.Windows.Forms.PictureBox pb_logo;
        private System.Windows.Forms.Label lbl_aboutSoft;
        private System.Windows.Forms.Label lbl_about_soft;
        private System.Windows.Forms.Label lbl_aboutDevelopersHead;
        private System.Windows.Forms.Label lbl_description_head;
        private System.Windows.Forms.Label lbl_description;
        private System.Windows.Forms.Label lbl_ashDescription;
        private System.Windows.Forms.Label lbl_copy1;
        private System.Windows.Forms.LinkLabel linklbl_whastapp;
        private System.Windows.Forms.PictureBox pb_whatsapp;
        private System.Windows.Forms.LinkLabel linklbl_insta;
        private System.Windows.Forms.PictureBox pb_insta;
        private System.Windows.Forms.LinkLabel linklbl_facebook;
        private System.Windows.Forms.PictureBox pb_facebook;
        private System.Windows.Forms.LinkLabel linklbl_twitter;
        private System.Windows.Forms.PictureBox pb_twitter;
        private System.Windows.Forms.LinkLabel linkLbl_facebookSuhaif;
        private System.Windows.Forms.PictureBox pb_face;
        private System.Windows.Forms.Label lbl_suhaifDescription;
        private System.Windows.Forms.PictureBox pb_student;
        private System.Windows.Forms.Panel pnl_fans;
        private System.Windows.Forms.LinkLabel linkLbl_sakthi_Insta;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.LinkLabel linkLbl_sakthi_Facebook;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.LinkLabel linkLbl_musthafa_Insta;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.LinkLabel linkLbl_musthafa_Facebook;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pb_sakthi;
        private System.Windows.Forms.PictureBox pb_musthafa;
        private System.Windows.Forms.PictureBox pb_abdul;
        private System.Windows.Forms.LinkLabel linkLbl_abdul_Insta;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.LinkLabel linkLbl_abdul_Facebook;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label lbl_copy2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_pbSuhaif;
        private System.Windows.Forms.Label lbl_pbAsh;
        private System.Windows.Forms.Label lbl_developersAsh;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pb_suhaif;
        private System.Windows.Forms.Timer timer_about;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}
