﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;

namespace Library
{
    public partial class UC_Mail : UserControl
    {
        NetworkCredential login;
        SmtpClient client;
        MailMessage msg;
        string smtp="smtp.gmail.com";
        string port = "587";
        string user = "library.alertnotification";
        string pass = "#Developers";
        public UC_Mail()
        {
            InitializeComponent();
        }
        private void btn_send_Click(object sender, EventArgs e)
        {
            try
            {
                login = new NetworkCredential(user,pass);
                client = new SmtpClient(smtp);
                client.Port = Convert.ToInt32(port);
                client.EnableSsl = bunifu_SSL.Checked;
                client.Credentials = login;
                msg = new MailMessage { From = new MailAddress(user+ smtp.Replace("smtp.", "@"), "Library Notification", Encoding.UTF8) };
                msg.To.Add(new MailAddress(txt_To.Text));
                if (!string.IsNullOrEmpty(txt_CC.Text))
                {
                    msg.To.Add(new MailAddress(txt_CC.Text));
                }
                msg.Subject = txt_subject.Text;
                msg.Body = rtxt_message.Text;
                msg.BodyEncoding = Encoding.UTF8;
                msg.IsBodyHtml = true;
                msg.Priority = MailPriority.Normal;
                msg.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                client.SendCompleted += new SendCompletedEventHandler(SendCompletedCallback);
                string userstate = "Sending...";
                client.SendAsync(msg, userstate);
            }
            catch(Exception x)
            {
                MessageBox.Show("Error " + x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static void SendCompletedCallback(object sender,AsyncCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                MessageBox.Show(string.Format("{0} send cancelled.", e.UserState), "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (e.Error != null)
            {
                MessageBox.Show(string.Format("{0} {1}", e.UserState, e.Error), "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                MessageBox.Show("Your message has been successfully sent", "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
