﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Library
{
    public partial class UC_settings : UserControl
    {
        public UC_settings()
        {
            InitializeComponent();
        }

        string img_file;
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;

        private void btn_browse_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog o = new OpenFileDialog();
                if (o.ShowDialog() != DialogResult.Cancel)
                {
                    img_file = o.FileName;
                    pb_student.Image = Image.FromFile(o.FileName);
                }
            }
            catch (Exception x)
            {
                MessageBox.Show("Error " + x.Message, "Library Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (img_file != null)
            {

                con.Open();
                FileStream fs = new FileStream(img_file, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                byte[] image = new byte[fs.Length];
                fs.Read(image, 0, Convert.ToInt32(fs.Length));
                fs.Close();
                ///////
                cmd = new SqlCommand("insert into Res_Images(Images) values(@pic)", con);
                SqlParameter prm = new SqlParameter("@pic", SqlDbType.VarBinary, image.Length, ParameterDirection.Input, false, 0, 0, null, DataRowVersion.Current, image);
                cmd.Parameters.Add(prm);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                lbl_saveinfo.Text = "You added a new image!!!";
                lbl_saveinfo.ForeColor = Color.Green;
                con.Close();


            }
            else
            {
                lbl_saveinfo.Text = "Please Upload Image";
                lbl_saveinfo.ForeColor = Color.Red;
            }
        }
    }
}
