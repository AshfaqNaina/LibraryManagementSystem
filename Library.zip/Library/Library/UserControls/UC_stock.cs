﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Library.UserControls
{
    public partial class UC_stock : UserControl
    {
        public UC_stock()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        private void UC_stock_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select Book_ID,Book_Name,Author,Publisher,ISBN_No,Category,Price,Quantity,Remarks from Book", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select Book_ID,Book_Name,Author,Publisher,ISBN_No,Category,Price,Quantity,Remarks from Book where Book_ID like '%" + txt_search.Text + "%' or Book_Name like '%" + txt_search.Text + "%' or Author like '%" + txt_search.Text + "%' or Publisher like '%" + txt_search.Text + "%' or ISBN_No  like '%" + txt_search.Text + "%' or Category like '%" + txt_search.Text + "%' or Price  like '%" + txt_search.Text + "%' or Quantity like  '%" + txt_search.Text + "%' or Remarks like  '%" + txt_search.Text + "%'", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select Book_ID,Book_Name,Author,Publisher,ISBN_No,Category,Price,Quantity,Remarks from Book where Book_ID like '%" + txt_search.Text + "%' or Book_Name like '%" + txt_search.Text + "%' or Author like '%" + txt_search.Text + "%' or Publisher like '%" + txt_search.Text + "%' or ISBN_No  like '%" + txt_search.Text + "%' or Category like '%" + txt_search.Text + "%' or Price  like '%" + txt_search.Text + "%' or Quantity like  '%" + txt_search.Text + "%' or Remarks like  '%" + txt_search.Text + "%'", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Admin_Username,Admin_Password from Admin where Admin_Username='"+txt_username.Text+"' and Admin_Password='" + txt_adminpass.Text + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.Read())
            {
                WindowsForms.truncate t = new WindowsForms.truncate();
                pnl_admin.Visible = false;
                t.Show();
            }
            else
            {
                MessageBox.Show("Username or Password is Incorrect", "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            pnl_admin.Visible = false;
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_adminpass.Clear();
            txt_username.Clear();
        }

        private void btn_admin_Click(object sender, EventArgs e)
        {
            pnl_admin.Visible = true;
        }
    }
}
