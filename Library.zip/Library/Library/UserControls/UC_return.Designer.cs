﻿namespace Library
{
    partial class UC_return
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_bookreturn = new System.Windows.Forms.Panel();
            this.btn_clear = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_idetails = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.lbl_sid = new System.Windows.Forms.Label();
            this.txt_sid = new System.Windows.Forms.TextBox();
            this.lbl_saveinfo = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.lbl_date = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_bookID = new System.Windows.Forms.TextBox();
            this.dtp_bookreturn = new System.Windows.Forms.DateTimePicker();
            this.lbl_bid = new System.Windows.Forms.Label();
            this.lbl_sname = new System.Windows.Forms.Label();
            this.lbl_isbn = new System.Windows.Forms.Label();
            this.lbl_course = new System.Windows.Forms.Label();
            this.txt_dept = new System.Windows.Forms.TextBox();
            this.txt_course = new System.Windows.Forms.TextBox();
            this.txt_author = new System.Windows.Forms.TextBox();
            this.txt_bname = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_isbn = new System.Windows.Forms.TextBox();
            this.lbl_author = new System.Windows.Forms.Label();
            this.lbl_price = new System.Windows.Forms.Label();
            this.lbl_bname = new System.Windows.Forms.Label();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.lbl_sdept = new System.Windows.Forms.Label();
            this.btn_return = new System.Windows.Forms.Button();
            this.lbl_head = new System.Windows.Forms.Label();
            this.txt_bookissue = new System.Windows.Forms.TextBox();
            this.txt_barcode = new System.Windows.Forms.TextBox();
            this.lbl_bar = new System.Windows.Forms.Label();
            this.pnl_Return = new System.Windows.Forms.Panel();
            this.pb_bar = new System.Windows.Forms.PictureBox();
            this.bunifuSend = new Bunifu.Framework.UI.BunifuCheckbox();
            this.lbl_sendmail = new System.Windows.Forms.Label();
            this.pnl_ReturnTop = new System.Windows.Forms.Panel();
            this.pnl_ReturnBottom = new System.Windows.Forms.Panel();
            this.pnl_ReturnRight = new System.Windows.Forms.Panel();
            this.pnl_ReturnLeft = new System.Windows.Forms.Panel();
            this.txt_Category = new System.Windows.Forms.TextBox();
            this.lbl_message = new System.Windows.Forms.Label();
            this.txt_subject = new System.Windows.Forms.TextBox();
            this.rtxt_message = new System.Windows.Forms.RichTextBox();
            this.lbl_Subject = new System.Windows.Forms.Label();
            this.txt_To = new System.Windows.Forms.TextBox();
            this.lbl_To = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnl_mail = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pb_mail = new System.Windows.Forms.PictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btn_send = new System.Windows.Forms.Button();
            this.pnl_bookreturn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.pnl_Return.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bar)).BeginInit();
            this.pnl_mail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mail)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_bookreturn
            // 
            this.pnl_bookreturn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_bookreturn.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_bookreturn.Controls.Add(this.btn_clear);
            this.pnl_bookreturn.Controls.Add(this.panel4);
            this.pnl_bookreturn.Controls.Add(this.panel3);
            this.pnl_bookreturn.Controls.Add(this.panel2);
            this.pnl_bookreturn.Controls.Add(this.panel1);
            this.pnl_bookreturn.Controls.Add(this.btn_idetails);
            this.pnl_bookreturn.Controls.Add(this.btn_search);
            this.pnl_bookreturn.Controls.Add(this.lbl_sid);
            this.pnl_bookreturn.Controls.Add(this.txt_sid);
            this.pnl_bookreturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnl_bookreturn.Location = new System.Drawing.Point(24, 54);
            this.pnl_bookreturn.Name = "pnl_bookreturn";
            this.pnl_bookreturn.Size = new System.Drawing.Size(1153, 59);
            this.pnl_bookreturn.TabIndex = 111;
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_clear.BackColor = System.Drawing.Color.Red;
            this.btn_clear.FlatAppearance.BorderSize = 0;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.White;
            this.btn_clear.Image = global::Library.Properties.Resources.Clear;
            this.btn_clear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_clear.Location = new System.Drawing.Point(685, 15);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(89, 29);
            this.btn_clear.TabIndex = 127;
            this.btn_clear.Text = "  Clear";
            this.btn_clear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 53);
            this.panel4.TabIndex = 125;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(1150, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 53);
            this.panel3.TabIndex = 124;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1153, 3);
            this.panel2.TabIndex = 123;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 56);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1153, 3);
            this.panel1.TabIndex = 122;
            // 
            // btn_idetails
            // 
            this.btn_idetails.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_idetails.BackColor = System.Drawing.Color.Navy;
            this.btn_idetails.FlatAppearance.BorderSize = 0;
            this.btn_idetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_idetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_idetails.ForeColor = System.Drawing.Color.White;
            this.btn_idetails.Image = global::Library.Properties.Resources.Up_Arrow;
            this.btn_idetails.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_idetails.Location = new System.Drawing.Point(780, 15);
            this.btn_idetails.Name = "btn_idetails";
            this.btn_idetails.Size = new System.Drawing.Size(188, 29);
            this.btn_idetails.TabIndex = 113;
            this.btn_idetails.Text = "Book Issue Details";
            this.btn_idetails.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_idetails.UseVisualStyleBackColor = false;
            this.btn_idetails.Click += new System.EventHandler(this.btn_idetails_Click);
            // 
            // btn_search
            // 
            this.btn_search.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_search.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_search.FlatAppearance.BorderSize = 0;
            this.btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.ForeColor = System.Drawing.Color.White;
            this.btn_search.Image = global::Library.Properties.Resources.search;
            this.btn_search.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_search.Location = new System.Drawing.Point(579, 15);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(100, 29);
            this.btn_search.TabIndex = 113;
            this.btn_search.Text = "Search";
            this.btn_search.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // lbl_sid
            // 
            this.lbl_sid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sid.AutoSize = true;
            this.lbl_sid.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sid.ForeColor = System.Drawing.Color.Black;
            this.lbl_sid.Location = new System.Drawing.Point(212, 17);
            this.lbl_sid.Name = "lbl_sid";
            this.lbl_sid.Size = new System.Drawing.Size(174, 25);
            this.lbl_sid.TabIndex = 40;
            this.lbl_sid.Text = "User\'s/Student ID:";
            // 
            // txt_sid
            // 
            this.txt_sid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_sid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sid.Location = new System.Drawing.Point(392, 15);
            this.txt_sid.Name = "txt_sid";
            this.txt_sid.Size = new System.Drawing.Size(187, 29);
            this.txt_sid.TabIndex = 41;
            // 
            // lbl_saveinfo
            // 
            this.lbl_saveinfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_saveinfo.AutoSize = true;
            this.lbl_saveinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saveinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_saveinfo.Location = new System.Drawing.Point(22, 288);
            this.lbl_saveinfo.Name = "lbl_saveinfo";
            this.lbl_saveinfo.Size = new System.Drawing.Size(15, 18);
            this.lbl_saveinfo.TabIndex = 110;
            this.lbl_saveinfo.Text = "*";
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv.BackgroundColor = System.Drawing.Color.White;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(24, 119);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.RowHeadersWidth = 51;
            this.dgv.RowTemplate.Height = 24;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(1153, 252);
            this.dgv.TabIndex = 107;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // lbl_date
            // 
            this.lbl_date.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.ForeColor = System.Drawing.Color.Black;
            this.lbl_date.Location = new System.Drawing.Point(449, 116);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(102, 20);
            this.lbl_date.TabIndex = 118;
            this.lbl_date.Text = "Issue Date:";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(438, 163);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 20);
            this.label1.TabIndex = 117;
            this.label1.Text = "Return Date:";
            // 
            // txt_bookID
            // 
            this.txt_bookID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_bookID.BackColor = System.Drawing.SystemColors.Window;
            this.txt_bookID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_bookID.Location = new System.Drawing.Point(177, 69);
            this.txt_bookID.Name = "txt_bookID";
            this.txt_bookID.Size = new System.Drawing.Size(225, 26);
            this.txt_bookID.TabIndex = 106;
            // 
            // dtp_bookreturn
            // 
            this.dtp_bookreturn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtp_bookreturn.CalendarFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_bookreturn.CustomFormat = "dd/MM/yyyy hh:mm:ss tt";
            this.dtp_bookreturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_bookreturn.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_bookreturn.Location = new System.Drawing.Point(572, 157);
            this.dtp_bookreturn.Name = "dtp_bookreturn";
            this.dtp_bookreturn.Size = new System.Drawing.Size(236, 26);
            this.dtp_bookreturn.TabIndex = 116;
            // 
            // lbl_bid
            // 
            this.lbl_bid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bid.AutoSize = true;
            this.lbl_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bid.ForeColor = System.Drawing.Color.Black;
            this.lbl_bid.Location = new System.Drawing.Point(21, 72);
            this.lbl_bid.Name = "lbl_bid";
            this.lbl_bid.Size = new System.Drawing.Size(79, 20);
            this.lbl_bid.TabIndex = 105;
            this.lbl_bid.Text = "Book ID:";
            // 
            // lbl_sname
            // 
            this.lbl_sname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sname.AutoSize = true;
            this.lbl_sname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sname.ForeColor = System.Drawing.Color.Black;
            this.lbl_sname.Location = new System.Drawing.Point(21, 27);
            this.lbl_sname.Name = "lbl_sname";
            this.lbl_sname.Size = new System.Drawing.Size(116, 20);
            this.lbl_sname.TabIndex = 111;
            this.lbl_sname.Text = "User\'s Name:";
            // 
            // lbl_isbn
            // 
            this.lbl_isbn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_isbn.AutoSize = true;
            this.lbl_isbn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_isbn.ForeColor = System.Drawing.Color.Black;
            this.lbl_isbn.Location = new System.Drawing.Point(21, 205);
            this.lbl_isbn.Name = "lbl_isbn";
            this.lbl_isbn.Size = new System.Drawing.Size(83, 20);
            this.lbl_isbn.TabIndex = 110;
            this.lbl_isbn.Text = "ISBN No:";
            // 
            // lbl_course
            // 
            this.lbl_course.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_course.AutoSize = true;
            this.lbl_course.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course.ForeColor = System.Drawing.Color.Black;
            this.lbl_course.Location = new System.Drawing.Point(21, 248);
            this.lbl_course.Name = "lbl_course";
            this.lbl_course.Size = new System.Drawing.Size(71, 20);
            this.lbl_course.TabIndex = 109;
            this.lbl_course.Text = "Course:";
            // 
            // txt_dept
            // 
            this.txt_dept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_dept.BackColor = System.Drawing.SystemColors.Window;
            this.txt_dept.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dept.Location = new System.Drawing.Point(572, 24);
            this.txt_dept.Name = "txt_dept";
            this.txt_dept.ReadOnly = true;
            this.txt_dept.Size = new System.Drawing.Size(236, 26);
            this.txt_dept.TabIndex = 108;
            // 
            // txt_course
            // 
            this.txt_course.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_course.BackColor = System.Drawing.SystemColors.Window;
            this.txt_course.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_course.Location = new System.Drawing.Point(177, 245);
            this.txt_course.Name = "txt_course";
            this.txt_course.ReadOnly = true;
            this.txt_course.Size = new System.Drawing.Size(225, 26);
            this.txt_course.TabIndex = 107;
            // 
            // txt_author
            // 
            this.txt_author.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_author.BackColor = System.Drawing.SystemColors.Window;
            this.txt_author.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_author.Location = new System.Drawing.Point(177, 157);
            this.txt_author.Name = "txt_author";
            this.txt_author.ReadOnly = true;
            this.txt_author.Size = new System.Drawing.Size(225, 26);
            this.txt_author.TabIndex = 106;
            // 
            // txt_bname
            // 
            this.txt_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_bname.BackColor = System.Drawing.SystemColors.Window;
            this.txt_bname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_bname.Location = new System.Drawing.Point(177, 113);
            this.txt_bname.Name = "txt_bname";
            this.txt_bname.ReadOnly = true;
            this.txt_bname.Size = new System.Drawing.Size(225, 26);
            this.txt_bname.TabIndex = 105;
            // 
            // txt_name
            // 
            this.txt_name.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_name.BackColor = System.Drawing.SystemColors.Window;
            this.txt_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name.Location = new System.Drawing.Point(177, 26);
            this.txt_name.Name = "txt_name";
            this.txt_name.ReadOnly = true;
            this.txt_name.Size = new System.Drawing.Size(225, 26);
            this.txt_name.TabIndex = 104;
            // 
            // txt_isbn
            // 
            this.txt_isbn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_isbn.BackColor = System.Drawing.SystemColors.Window;
            this.txt_isbn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_isbn.Location = new System.Drawing.Point(177, 201);
            this.txt_isbn.Name = "txt_isbn";
            this.txt_isbn.ReadOnly = true;
            this.txt_isbn.Size = new System.Drawing.Size(225, 26);
            this.txt_isbn.TabIndex = 103;
            // 
            // lbl_author
            // 
            this.lbl_author.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_author.AutoSize = true;
            this.lbl_author.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_author.ForeColor = System.Drawing.Color.Black;
            this.lbl_author.Location = new System.Drawing.Point(21, 162);
            this.lbl_author.Name = "lbl_author";
            this.lbl_author.Size = new System.Drawing.Size(119, 20);
            this.lbl_author.TabIndex = 114;
            this.lbl_author.Text = "Author Name:";
            // 
            // lbl_price
            // 
            this.lbl_price.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_price.AutoSize = true;
            this.lbl_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_price.ForeColor = System.Drawing.Color.Black;
            this.lbl_price.Location = new System.Drawing.Point(497, 72);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(54, 20);
            this.lbl_price.TabIndex = 102;
            this.lbl_price.Text = "Price:";
            // 
            // lbl_bname
            // 
            this.lbl_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bname.AutoSize = true;
            this.lbl_bname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bname.ForeColor = System.Drawing.Color.Black;
            this.lbl_bname.Location = new System.Drawing.Point(21, 116);
            this.lbl_bname.Name = "lbl_bname";
            this.lbl_bname.Size = new System.Drawing.Size(106, 20);
            this.lbl_bname.TabIndex = 113;
            this.lbl_bname.Text = "Book Name:";
            // 
            // txt_price
            // 
            this.txt_price.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_price.BackColor = System.Drawing.SystemColors.Window;
            this.txt_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_price.Location = new System.Drawing.Point(572, 69);
            this.txt_price.Name = "txt_price";
            this.txt_price.ReadOnly = true;
            this.txt_price.Size = new System.Drawing.Size(236, 26);
            this.txt_price.TabIndex = 101;
            // 
            // lbl_sdept
            // 
            this.lbl_sdept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sdept.AutoSize = true;
            this.lbl_sdept.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sdept.ForeColor = System.Drawing.Color.Black;
            this.lbl_sdept.Location = new System.Drawing.Point(442, 27);
            this.lbl_sdept.Name = "lbl_sdept";
            this.lbl_sdept.Size = new System.Drawing.Size(109, 20);
            this.lbl_sdept.TabIndex = 112;
            this.lbl_sdept.Text = "User\'s Dept:";
            // 
            // btn_return
            // 
            this.btn_return.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_return.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_return.FlatAppearance.BorderSize = 0;
            this.btn_return.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_return.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_return.ForeColor = System.Drawing.Color.White;
            this.btn_return.Location = new System.Drawing.Point(608, 273);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(200, 30);
            this.btn_return.TabIndex = 112;
            this.btn_return.Text = "Return Book";
            this.btn_return.UseVisualStyleBackColor = false;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(502, 8);
            this.lbl_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(196, 40);
            this.lbl_head.TabIndex = 116;
            this.lbl_head.Text = "Book Return";
            // 
            // txt_bookissue
            // 
            this.txt_bookissue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_bookissue.BackColor = System.Drawing.SystemColors.Window;
            this.txt_bookissue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_bookissue.Location = new System.Drawing.Point(572, 113);
            this.txt_bookissue.Name = "txt_bookissue";
            this.txt_bookissue.ReadOnly = true;
            this.txt_bookissue.Size = new System.Drawing.Size(236, 26);
            this.txt_bookissue.TabIndex = 119;
            // 
            // txt_barcode
            // 
            this.txt_barcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_barcode.BackColor = System.Drawing.SystemColors.Window;
            this.txt_barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_barcode.Location = new System.Drawing.Point(588, 205);
            this.txt_barcode.Name = "txt_barcode";
            this.txt_barcode.ReadOnly = true;
            this.txt_barcode.Size = new System.Drawing.Size(209, 29);
            this.txt_barcode.TabIndex = 121;
            this.txt_barcode.TextChanged += new System.EventHandler(this.txt_barcode_TextChanged);
            // 
            // lbl_bar
            // 
            this.lbl_bar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bar.AutoSize = true;
            this.lbl_bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bar.ForeColor = System.Drawing.Color.Black;
            this.lbl_bar.Location = new System.Drawing.Point(416, 219);
            this.lbl_bar.Name = "lbl_bar";
            this.lbl_bar.Size = new System.Drawing.Size(135, 20);
            this.lbl_bar.TabIndex = 122;
            this.lbl_bar.Text = "Book Bar Code:";
            // 
            // pnl_Return
            // 
            this.pnl_Return.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_Return.Controls.Add(this.pb_bar);
            this.pnl_Return.Controls.Add(this.bunifuSend);
            this.pnl_Return.Controls.Add(this.lbl_sendmail);
            this.pnl_Return.Controls.Add(this.pnl_ReturnTop);
            this.pnl_Return.Controls.Add(this.lbl_bar);
            this.pnl_Return.Controls.Add(this.pnl_ReturnBottom);
            this.pnl_Return.Controls.Add(this.pnl_ReturnRight);
            this.pnl_Return.Controls.Add(this.txt_barcode);
            this.pnl_Return.Controls.Add(this.pnl_ReturnLeft);
            this.pnl_Return.Controls.Add(this.txt_bookissue);
            this.pnl_Return.Controls.Add(this.txt_course);
            this.pnl_Return.Controls.Add(this.lbl_saveinfo);
            this.pnl_Return.Controls.Add(this.txt_bname);
            this.pnl_Return.Controls.Add(this.btn_return);
            this.pnl_Return.Controls.Add(this.lbl_isbn);
            this.pnl_Return.Controls.Add(this.txt_name);
            this.pnl_Return.Controls.Add(this.lbl_sname);
            this.pnl_Return.Controls.Add(this.lbl_sdept);
            this.pnl_Return.Controls.Add(this.lbl_date);
            this.pnl_Return.Controls.Add(this.txt_isbn);
            this.pnl_Return.Controls.Add(this.label1);
            this.pnl_Return.Controls.Add(this.txt_price);
            this.pnl_Return.Controls.Add(this.txt_author);
            this.pnl_Return.Controls.Add(this.lbl_bid);
            this.pnl_Return.Controls.Add(this.dtp_bookreturn);
            this.pnl_Return.Controls.Add(this.lbl_price);
            this.pnl_Return.Controls.Add(this.lbl_course);
            this.pnl_Return.Controls.Add(this.lbl_author);
            this.pnl_Return.Controls.Add(this.txt_bookID);
            this.pnl_Return.Controls.Add(this.lbl_bname);
            this.pnl_Return.Controls.Add(this.txt_dept);
            this.pnl_Return.Controls.Add(this.txt_Category);
            this.pnl_Return.Location = new System.Drawing.Point(24, 377);
            this.pnl_Return.Name = "pnl_Return";
            this.pnl_Return.Size = new System.Drawing.Size(828, 330);
            this.pnl_Return.TabIndex = 123;
            // 
            // pb_bar
            // 
            this.pb_bar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_bar.Image = global::Library.Properties.Resources.Barcode_70;
            this.pb_bar.Location = new System.Drawing.Point(572, 198);
            this.pb_bar.Name = "pb_bar";
            this.pb_bar.Size = new System.Drawing.Size(236, 61);
            this.pb_bar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_bar.TabIndex = 120;
            this.pb_bar.TabStop = false;
            // 
            // bunifuSend
            // 
            this.bunifuSend.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuSend.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuSend.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuSend.Checked = true;
            this.bunifuSend.CheckedOnColor = System.Drawing.Color.SeaGreen;
            this.bunifuSend.ForeColor = System.Drawing.Color.White;
            this.bunifuSend.Location = new System.Drawing.Point(572, 278);
            this.bunifuSend.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuSend.Name = "bunifuSend";
            this.bunifuSend.Size = new System.Drawing.Size(20, 20);
            this.bunifuSend.TabIndex = 126;
            // 
            // lbl_sendmail
            // 
            this.lbl_sendmail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sendmail.AutoSize = true;
            this.lbl_sendmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sendmail.ForeColor = System.Drawing.Color.Black;
            this.lbl_sendmail.Location = new System.Drawing.Point(458, 278);
            this.lbl_sendmail.Name = "lbl_sendmail";
            this.lbl_sendmail.Size = new System.Drawing.Size(93, 20);
            this.lbl_sendmail.TabIndex = 124;
            this.lbl_sendmail.Text = "Send Mail:";
            // 
            // pnl_ReturnTop
            // 
            this.pnl_ReturnTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_ReturnTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_ReturnTop.Location = new System.Drawing.Point(3, 0);
            this.pnl_ReturnTop.Name = "pnl_ReturnTop";
            this.pnl_ReturnTop.Size = new System.Drawing.Size(822, 3);
            this.pnl_ReturnTop.TabIndex = 122;
            // 
            // pnl_ReturnBottom
            // 
            this.pnl_ReturnBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_ReturnBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_ReturnBottom.Location = new System.Drawing.Point(3, 327);
            this.pnl_ReturnBottom.Name = "pnl_ReturnBottom";
            this.pnl_ReturnBottom.Size = new System.Drawing.Size(822, 3);
            this.pnl_ReturnBottom.TabIndex = 121;
            // 
            // pnl_ReturnRight
            // 
            this.pnl_ReturnRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_ReturnRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_ReturnRight.Location = new System.Drawing.Point(825, 0);
            this.pnl_ReturnRight.Name = "pnl_ReturnRight";
            this.pnl_ReturnRight.Size = new System.Drawing.Size(3, 330);
            this.pnl_ReturnRight.TabIndex = 120;
            // 
            // pnl_ReturnLeft
            // 
            this.pnl_ReturnLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_ReturnLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_ReturnLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_ReturnLeft.Name = "pnl_ReturnLeft";
            this.pnl_ReturnLeft.Size = new System.Drawing.Size(3, 330);
            this.pnl_ReturnLeft.TabIndex = 119;
            // 
            // txt_Category
            // 
            this.txt_Category.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Category.BackColor = System.Drawing.SystemColors.Window;
            this.txt_Category.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Category.Location = new System.Drawing.Point(588, 230);
            this.txt_Category.Name = "txt_Category";
            this.txt_Category.ReadOnly = true;
            this.txt_Category.Size = new System.Drawing.Size(209, 26);
            this.txt_Category.TabIndex = 125;
            // 
            // lbl_message
            // 
            this.lbl_message.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_message.AutoSize = true;
            this.lbl_message.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_message.ForeColor = System.Drawing.Color.Black;
            this.lbl_message.Location = new System.Drawing.Point(13, 153);
            this.lbl_message.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_message.Name = "lbl_message";
            this.lbl_message.Size = new System.Drawing.Size(76, 16);
            this.lbl_message.TabIndex = 142;
            this.lbl_message.Text = "Message:";
            // 
            // txt_subject
            // 
            this.txt_subject.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_subject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_subject.Location = new System.Drawing.Point(94, 110);
            this.txt_subject.Margin = new System.Windows.Forms.Padding(4);
            this.txt_subject.Name = "txt_subject";
            this.txt_subject.Size = new System.Drawing.Size(206, 22);
            this.txt_subject.TabIndex = 141;
            this.txt_subject.Text = "Alert!! Return Your Books";
            // 
            // rtxt_message
            // 
            this.rtxt_message.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rtxt_message.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxt_message.Location = new System.Drawing.Point(94, 151);
            this.rtxt_message.Name = "rtxt_message";
            this.rtxt_message.Size = new System.Drawing.Size(204, 105);
            this.rtxt_message.TabIndex = 137;
            this.rtxt_message.Text = "Please return the borrowed book otherwise you will pay fine\n";
            // 
            // lbl_Subject
            // 
            this.lbl_Subject.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_Subject.AutoSize = true;
            this.lbl_Subject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subject.ForeColor = System.Drawing.Color.Black;
            this.lbl_Subject.Location = new System.Drawing.Point(25, 113);
            this.lbl_Subject.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Subject.Name = "lbl_Subject";
            this.lbl_Subject.Size = new System.Drawing.Size(64, 16);
            this.lbl_Subject.TabIndex = 140;
            this.lbl_Subject.Text = "Subject:";
            // 
            // txt_To
            // 
            this.txt_To.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_To.BackColor = System.Drawing.SystemColors.Window;
            this.txt_To.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_To.Location = new System.Drawing.Point(94, 75);
            this.txt_To.Name = "txt_To";
            this.txt_To.Size = new System.Drawing.Size(206, 22);
            this.txt_To.TabIndex = 135;
            // 
            // lbl_To
            // 
            this.lbl_To.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_To.AutoSize = true;
            this.lbl_To.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_To.ForeColor = System.Drawing.Color.Black;
            this.lbl_To.Location = new System.Drawing.Point(58, 78);
            this.lbl_To.Name = "lbl_To";
            this.lbl_To.Size = new System.Drawing.Size(31, 16);
            this.lbl_To.TabIndex = 139;
            this.lbl_To.Text = "To:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label3.Location = new System.Drawing.Point(124, 33);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 20);
            this.label3.TabIndex = 148;
            this.label3.Text = "Mail Service";
            // 
            // pnl_mail
            // 
            this.pnl_mail.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pnl_mail.Controls.Add(this.panel8);
            this.pnl_mail.Controls.Add(this.label3);
            this.pnl_mail.Controls.Add(this.panel9);
            this.pnl_mail.Controls.Add(this.pb_mail);
            this.pnl_mail.Controls.Add(this.panel10);
            this.pnl_mail.Controls.Add(this.panel11);
            this.pnl_mail.Controls.Add(this.btn_send);
            this.pnl_mail.Controls.Add(this.lbl_To);
            this.pnl_mail.Controls.Add(this.txt_To);
            this.pnl_mail.Controls.Add(this.lbl_Subject);
            this.pnl_mail.Controls.Add(this.rtxt_message);
            this.pnl_mail.Controls.Add(this.txt_subject);
            this.pnl_mail.Controls.Add(this.lbl_message);
            this.pnl_mail.Location = new System.Drawing.Point(858, 377);
            this.pnl_mail.Name = "pnl_mail";
            this.pnl_mail.Size = new System.Drawing.Size(319, 330);
            this.pnl_mail.TabIndex = 124;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(3, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(313, 3);
            this.panel8.TabIndex = 122;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel9.Location = new System.Drawing.Point(3, 327);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(313, 3);
            this.panel9.TabIndex = 121;
            // 
            // pb_mail
            // 
            this.pb_mail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_mail.Image = global::Library.Properties.Resources.gmail_20;
            this.pb_mail.Location = new System.Drawing.Point(94, 31);
            this.pb_mail.Name = "pb_mail";
            this.pb_mail.Size = new System.Drawing.Size(30, 22);
            this.pb_mail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_mail.TabIndex = 147;
            this.pb_mail.TabStop = false;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel10.Location = new System.Drawing.Point(316, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(3, 330);
            this.panel10.TabIndex = 120;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel11.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(3, 330);
            this.panel11.TabIndex = 119;
            // 
            // btn_send
            // 
            this.btn_send.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_send.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_send.FlatAppearance.BorderSize = 0;
            this.btn_send.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_send.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_send.ForeColor = System.Drawing.Color.White;
            this.btn_send.Image = global::Library.Properties.Resources.Send;
            this.btn_send.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_send.Location = new System.Drawing.Point(206, 275);
            this.btn_send.Name = "btn_send";
            this.btn_send.Size = new System.Drawing.Size(91, 29);
            this.btn_send.TabIndex = 143;
            this.btn_send.Text = "    Send";
            this.btn_send.UseVisualStyleBackColor = false;
            this.btn_send.Click += new System.EventHandler(this.btn_send_Click);
            // 
            // UC_return
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnl_mail);
            this.Controls.Add(this.pnl_Return);
            this.Controls.Add(this.lbl_head);
            this.Controls.Add(this.pnl_bookreturn);
            this.Controls.Add(this.dgv);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "UC_return";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_return_Load);
            this.pnl_bookreturn.ResumeLayout(false);
            this.pnl_bookreturn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.pnl_Return.ResumeLayout(false);
            this.pnl_Return.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bar)).EndInit();
            this.pnl_mail.ResumeLayout(false);
            this.pnl_mail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mail)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_bookreturn;
        private System.Windows.Forms.Label lbl_sid;
        private System.Windows.Forms.TextBox txt_sid;
        private System.Windows.Forms.Label lbl_saveinfo;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_bookID;
        private System.Windows.Forms.DateTimePicker dtp_bookreturn;
        private System.Windows.Forms.Label lbl_bid;
        private System.Windows.Forms.Label lbl_sname;
        private System.Windows.Forms.Label lbl_isbn;
        private System.Windows.Forms.Label lbl_course;
        private System.Windows.Forms.TextBox txt_dept;
        private System.Windows.Forms.TextBox txt_course;
        private System.Windows.Forms.TextBox txt_author;
        private System.Windows.Forms.TextBox txt_bname;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_isbn;
        private System.Windows.Forms.Label lbl_author;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.Label lbl_bname;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Label lbl_sdept;
        private System.Windows.Forms.Button btn_idetails;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.TextBox txt_bookissue;
        private System.Windows.Forms.PictureBox pb_bar;
        private System.Windows.Forms.TextBox txt_barcode;
        private System.Windows.Forms.Label lbl_bar;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnl_Return;
        private System.Windows.Forms.Panel pnl_ReturnTop;
        private System.Windows.Forms.Panel pnl_ReturnBottom;
        private System.Windows.Forms.Panel pnl_ReturnRight;
        private System.Windows.Forms.Panel pnl_ReturnLeft;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_send;
        private System.Windows.Forms.Label lbl_message;
        private System.Windows.Forms.TextBox txt_subject;
        private System.Windows.Forms.RichTextBox rtxt_message;
        private System.Windows.Forms.Label lbl_Subject;
        private System.Windows.Forms.TextBox txt_To;
        private System.Windows.Forms.Label lbl_To;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pb_mail;
        private System.Windows.Forms.Panel pnl_mail;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label lbl_sendmail;
        private System.Windows.Forms.TextBox txt_Category;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuSend;
    }
}
