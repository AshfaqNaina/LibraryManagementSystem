﻿namespace Library
{
    partial class UC_return
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_bookreturn = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_sid = new System.Windows.Forms.Label();
            this.txt_sid = new System.Windows.Forms.TextBox();
            this.lbl_saveinfo = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.lbl_date = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_bookID = new System.Windows.Forms.TextBox();
            this.dtp_bookreturn = new System.Windows.Forms.DateTimePicker();
            this.lbl_bid = new System.Windows.Forms.Label();
            this.lbl_sname = new System.Windows.Forms.Label();
            this.lbl_isbn = new System.Windows.Forms.Label();
            this.lbl_course = new System.Windows.Forms.Label();
            this.txt_dept = new System.Windows.Forms.TextBox();
            this.txt_course = new System.Windows.Forms.TextBox();
            this.txt_author = new System.Windows.Forms.TextBox();
            this.txt_bname = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_isbn = new System.Windows.Forms.TextBox();
            this.lbl_author = new System.Windows.Forms.Label();
            this.lbl_price = new System.Windows.Forms.Label();
            this.lbl_bname = new System.Windows.Forms.Label();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.lbl_sdept = new System.Windows.Forms.Label();
            this.btn_return = new System.Windows.Forms.Button();
            this.lbl_head = new System.Windows.Forms.Label();
            this.txt_bookissue = new System.Windows.Forms.TextBox();
            this.txt_barcode = new System.Windows.Forms.TextBox();
            this.lbl_bar = new System.Windows.Forms.Label();
            this.pnl_Return = new System.Windows.Forms.Panel();
            this.pnl_ReturnTop = new System.Windows.Forms.Panel();
            this.pnl_ReturnBottom = new System.Windows.Forms.Panel();
            this.pnl_ReturnRight = new System.Windows.Forms.Panel();
            this.pnl_ReturnLeft = new System.Windows.Forms.Panel();
            this.pb_bar = new System.Windows.Forms.PictureBox();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_idetails = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.pnl_bookreturn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.pnl_Return.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bar)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_bookreturn
            // 
            this.pnl_bookreturn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_bookreturn.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_bookreturn.Controls.Add(this.btn_clear);
            this.pnl_bookreturn.Controls.Add(this.panel4);
            this.pnl_bookreturn.Controls.Add(this.panel3);
            this.pnl_bookreturn.Controls.Add(this.panel2);
            this.pnl_bookreturn.Controls.Add(this.panel1);
            this.pnl_bookreturn.Controls.Add(this.btn_idetails);
            this.pnl_bookreturn.Controls.Add(this.btn_search);
            this.pnl_bookreturn.Controls.Add(this.lbl_sid);
            this.pnl_bookreturn.Controls.Add(this.txt_sid);
            this.pnl_bookreturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnl_bookreturn.Location = new System.Drawing.Point(24, 93);
            this.pnl_bookreturn.Name = "pnl_bookreturn";
            this.pnl_bookreturn.Size = new System.Drawing.Size(1153, 62);
            this.pnl_bookreturn.TabIndex = 111;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 56);
            this.panel4.TabIndex = 125;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(1150, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 56);
            this.panel3.TabIndex = 124;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1153, 3);
            this.panel2.TabIndex = 123;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 59);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1153, 3);
            this.panel1.TabIndex = 122;
            // 
            // lbl_sid
            // 
            this.lbl_sid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sid.AutoSize = true;
            this.lbl_sid.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sid.ForeColor = System.Drawing.Color.Black;
            this.lbl_sid.Location = new System.Drawing.Point(212, 19);
            this.lbl_sid.Name = "lbl_sid";
            this.lbl_sid.Size = new System.Drawing.Size(174, 25);
            this.lbl_sid.TabIndex = 40;
            this.lbl_sid.Text = "User\'s/Student ID:";
            // 
            // txt_sid
            // 
            this.txt_sid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_sid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sid.Location = new System.Drawing.Point(392, 17);
            this.txt_sid.Name = "txt_sid";
            this.txt_sid.Size = new System.Drawing.Size(187, 29);
            this.txt_sid.TabIndex = 41;
            // 
            // lbl_saveinfo
            // 
            this.lbl_saveinfo.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_saveinfo.AutoSize = true;
            this.lbl_saveinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saveinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_saveinfo.Location = new System.Drawing.Point(31, 284);
            this.lbl_saveinfo.Name = "lbl_saveinfo";
            this.lbl_saveinfo.Size = new System.Drawing.Size(18, 24);
            this.lbl_saveinfo.TabIndex = 110;
            this.lbl_saveinfo.Text = "*";
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv.BackgroundColor = System.Drawing.Color.White;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(24, 161);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.RowHeadersWidth = 51;
            this.dgv.RowTemplate.Height = 24;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(1153, 215);
            this.dgv.TabIndex = 107;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // lbl_date
            // 
            this.lbl_date.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.ForeColor = System.Drawing.Color.Black;
            this.lbl_date.Location = new System.Drawing.Point(451, 183);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(166, 24);
            this.lbl_date.TabIndex = 118;
            this.lbl_date.Text = "Book Issue Date:";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(491, 236);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 24);
            this.label1.TabIndex = 117;
            this.label1.Text = "Return Date:";
            // 
            // txt_bookID
            // 
            this.txt_bookID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_bookID.BackColor = System.Drawing.SystemColors.Window;
            this.txt_bookID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_bookID.Location = new System.Drawing.Point(187, 82);
            this.txt_bookID.Name = "txt_bookID";
            this.txt_bookID.Size = new System.Drawing.Size(234, 29);
            this.txt_bookID.TabIndex = 106;
            // 
            // dtp_bookreturn
            // 
            this.dtp_bookreturn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtp_bookreturn.CalendarFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_bookreturn.CustomFormat = "dd/MM/yyyy hh:mm:ss tt";
            this.dtp_bookreturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_bookreturn.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_bookreturn.Location = new System.Drawing.Point(623, 232);
            this.dtp_bookreturn.Name = "dtp_bookreturn";
            this.dtp_bookreturn.Size = new System.Drawing.Size(241, 29);
            this.dtp_bookreturn.TabIndex = 116;
            // 
            // lbl_bid
            // 
            this.lbl_bid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bid.AutoSize = true;
            this.lbl_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bid.ForeColor = System.Drawing.Color.Black;
            this.lbl_bid.Location = new System.Drawing.Point(31, 85);
            this.lbl_bid.Name = "lbl_bid";
            this.lbl_bid.Size = new System.Drawing.Size(88, 24);
            this.lbl_bid.TabIndex = 105;
            this.lbl_bid.Text = "Book ID:";
            // 
            // lbl_sname
            // 
            this.lbl_sname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sname.AutoSize = true;
            this.lbl_sname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sname.ForeColor = System.Drawing.Color.Black;
            this.lbl_sname.Location = new System.Drawing.Point(31, 33);
            this.lbl_sname.Name = "lbl_sname";
            this.lbl_sname.Size = new System.Drawing.Size(135, 24);
            this.lbl_sname.TabIndex = 111;
            this.lbl_sname.Text = "User\'s Name:";
            // 
            // lbl_isbn
            // 
            this.lbl_isbn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_isbn.AutoSize = true;
            this.lbl_isbn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_isbn.ForeColor = System.Drawing.Color.Black;
            this.lbl_isbn.Location = new System.Drawing.Point(31, 233);
            this.lbl_isbn.Name = "lbl_isbn";
            this.lbl_isbn.Size = new System.Drawing.Size(95, 24);
            this.lbl_isbn.TabIndex = 110;
            this.lbl_isbn.Text = "ISBN No:";
            // 
            // lbl_course
            // 
            this.lbl_course.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_course.AutoSize = true;
            this.lbl_course.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course.ForeColor = System.Drawing.Color.Black;
            this.lbl_course.Location = new System.Drawing.Point(534, 33);
            this.lbl_course.Name = "lbl_course";
            this.lbl_course.Size = new System.Drawing.Size(83, 24);
            this.lbl_course.TabIndex = 109;
            this.lbl_course.Text = "Course:";
            // 
            // txt_dept
            // 
            this.txt_dept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_dept.BackColor = System.Drawing.SystemColors.Window;
            this.txt_dept.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dept.Location = new System.Drawing.Point(623, 82);
            this.txt_dept.Name = "txt_dept";
            this.txt_dept.ReadOnly = true;
            this.txt_dept.Size = new System.Drawing.Size(241, 29);
            this.txt_dept.TabIndex = 108;
            // 
            // txt_course
            // 
            this.txt_course.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_course.BackColor = System.Drawing.SystemColors.Window;
            this.txt_course.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_course.Location = new System.Drawing.Point(623, 32);
            this.txt_course.Name = "txt_course";
            this.txt_course.ReadOnly = true;
            this.txt_course.Size = new System.Drawing.Size(241, 29);
            this.txt_course.TabIndex = 107;
            // 
            // txt_author
            // 
            this.txt_author.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_author.BackColor = System.Drawing.SystemColors.Window;
            this.txt_author.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_author.Location = new System.Drawing.Point(187, 182);
            this.txt_author.Name = "txt_author";
            this.txt_author.ReadOnly = true;
            this.txt_author.Size = new System.Drawing.Size(234, 29);
            this.txt_author.TabIndex = 106;
            // 
            // txt_bname
            // 
            this.txt_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_bname.BackColor = System.Drawing.SystemColors.Window;
            this.txt_bname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_bname.Location = new System.Drawing.Point(187, 132);
            this.txt_bname.Name = "txt_bname";
            this.txt_bname.ReadOnly = true;
            this.txt_bname.Size = new System.Drawing.Size(234, 29);
            this.txt_bname.TabIndex = 105;
            // 
            // txt_name
            // 
            this.txt_name.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_name.BackColor = System.Drawing.SystemColors.Window;
            this.txt_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name.Location = new System.Drawing.Point(187, 32);
            this.txt_name.Name = "txt_name";
            this.txt_name.ReadOnly = true;
            this.txt_name.Size = new System.Drawing.Size(234, 29);
            this.txt_name.TabIndex = 104;
            // 
            // txt_isbn
            // 
            this.txt_isbn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_isbn.BackColor = System.Drawing.SystemColors.Window;
            this.txt_isbn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_isbn.Location = new System.Drawing.Point(187, 232);
            this.txt_isbn.Name = "txt_isbn";
            this.txt_isbn.ReadOnly = true;
            this.txt_isbn.Size = new System.Drawing.Size(234, 29);
            this.txt_isbn.TabIndex = 103;
            // 
            // lbl_author
            // 
            this.lbl_author.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_author.AutoSize = true;
            this.lbl_author.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_author.ForeColor = System.Drawing.Color.Black;
            this.lbl_author.Location = new System.Drawing.Point(31, 183);
            this.lbl_author.Name = "lbl_author";
            this.lbl_author.Size = new System.Drawing.Size(139, 24);
            this.lbl_author.TabIndex = 114;
            this.lbl_author.Text = "Author Name:";
            // 
            // lbl_price
            // 
            this.lbl_price.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_price.AutoSize = true;
            this.lbl_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_price.ForeColor = System.Drawing.Color.Black;
            this.lbl_price.Location = new System.Drawing.Point(553, 133);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(64, 24);
            this.lbl_price.TabIndex = 102;
            this.lbl_price.Text = "Price:";
            // 
            // lbl_bname
            // 
            this.lbl_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bname.AutoSize = true;
            this.lbl_bname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bname.ForeColor = System.Drawing.Color.Black;
            this.lbl_bname.Location = new System.Drawing.Point(31, 133);
            this.lbl_bname.Name = "lbl_bname";
            this.lbl_bname.Size = new System.Drawing.Size(124, 24);
            this.lbl_bname.TabIndex = 113;
            this.lbl_bname.Text = "Book Name:";
            // 
            // txt_price
            // 
            this.txt_price.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_price.BackColor = System.Drawing.SystemColors.Window;
            this.txt_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_price.Location = new System.Drawing.Point(623, 132);
            this.txt_price.Name = "txt_price";
            this.txt_price.ReadOnly = true;
            this.txt_price.Size = new System.Drawing.Size(241, 29);
            this.txt_price.TabIndex = 101;
            // 
            // lbl_sdept
            // 
            this.lbl_sdept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sdept.AutoSize = true;
            this.lbl_sdept.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sdept.ForeColor = System.Drawing.Color.Black;
            this.lbl_sdept.Location = new System.Drawing.Point(494, 83);
            this.lbl_sdept.Name = "lbl_sdept";
            this.lbl_sdept.Size = new System.Drawing.Size(123, 24);
            this.lbl_sdept.TabIndex = 112;
            this.lbl_sdept.Text = "User\'s Dept:";
            // 
            // btn_return
            // 
            this.btn_return.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_return.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_return.FlatAppearance.BorderSize = 0;
            this.btn_return.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_return.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_return.ForeColor = System.Drawing.Color.White;
            this.btn_return.Location = new System.Drawing.Point(929, 227);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(173, 41);
            this.btn_return.TabIndex = 112;
            this.btn_return.Text = "Return Book";
            this.btn_return.UseVisualStyleBackColor = false;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(502, 27);
            this.lbl_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(196, 40);
            this.lbl_head.TabIndex = 116;
            this.lbl_head.Text = "Book Return";
            // 
            // txt_bookissue
            // 
            this.txt_bookissue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_bookissue.BackColor = System.Drawing.SystemColors.Window;
            this.txt_bookissue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_bookissue.Location = new System.Drawing.Point(623, 180);
            this.txt_bookissue.Name = "txt_bookissue";
            this.txt_bookissue.ReadOnly = true;
            this.txt_bookissue.Size = new System.Drawing.Size(241, 29);
            this.txt_bookissue.TabIndex = 119;
            // 
            // txt_barcode
            // 
            this.txt_barcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_barcode.BackColor = System.Drawing.SystemColors.Window;
            this.txt_barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_barcode.Location = new System.Drawing.Point(902, 39);
            this.txt_barcode.Name = "txt_barcode";
            this.txt_barcode.ReadOnly = true;
            this.txt_barcode.Size = new System.Drawing.Size(210, 29);
            this.txt_barcode.TabIndex = 121;
            this.txt_barcode.TextChanged += new System.EventHandler(this.txt_barcode_TextChanged);
            // 
            // lbl_bar
            // 
            this.lbl_bar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bar.AutoSize = true;
            this.lbl_bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_bar.Location = new System.Drawing.Point(947, 105);
            this.lbl_bar.Name = "lbl_bar";
            this.lbl_bar.Size = new System.Drawing.Size(130, 20);
            this.lbl_bar.TabIndex = 122;
            this.lbl_bar.Text = "Book Bar Code";
            // 
            // pnl_Return
            // 
            this.pnl_Return.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_Return.Controls.Add(this.pnl_ReturnTop);
            this.pnl_Return.Controls.Add(this.lbl_bar);
            this.pnl_Return.Controls.Add(this.pnl_ReturnBottom);
            this.pnl_Return.Controls.Add(this.pb_bar);
            this.pnl_Return.Controls.Add(this.pnl_ReturnRight);
            this.pnl_Return.Controls.Add(this.txt_barcode);
            this.pnl_Return.Controls.Add(this.pnl_ReturnLeft);
            this.pnl_Return.Controls.Add(this.txt_bookissue);
            this.pnl_Return.Controls.Add(this.txt_course);
            this.pnl_Return.Controls.Add(this.lbl_saveinfo);
            this.pnl_Return.Controls.Add(this.txt_bname);
            this.pnl_Return.Controls.Add(this.btn_return);
            this.pnl_Return.Controls.Add(this.lbl_isbn);
            this.pnl_Return.Controls.Add(this.txt_name);
            this.pnl_Return.Controls.Add(this.lbl_sname);
            this.pnl_Return.Controls.Add(this.lbl_sdept);
            this.pnl_Return.Controls.Add(this.lbl_date);
            this.pnl_Return.Controls.Add(this.txt_isbn);
            this.pnl_Return.Controls.Add(this.label1);
            this.pnl_Return.Controls.Add(this.txt_price);
            this.pnl_Return.Controls.Add(this.txt_author);
            this.pnl_Return.Controls.Add(this.lbl_bid);
            this.pnl_Return.Controls.Add(this.dtp_bookreturn);
            this.pnl_Return.Controls.Add(this.lbl_price);
            this.pnl_Return.Controls.Add(this.lbl_course);
            this.pnl_Return.Controls.Add(this.lbl_author);
            this.pnl_Return.Controls.Add(this.txt_bookID);
            this.pnl_Return.Controls.Add(this.lbl_bname);
            this.pnl_Return.Controls.Add(this.txt_dept);
            this.pnl_Return.Location = new System.Drawing.Point(24, 382);
            this.pnl_Return.Name = "pnl_Return";
            this.pnl_Return.Size = new System.Drawing.Size(1153, 308);
            this.pnl_Return.TabIndex = 123;
            // 
            // pnl_ReturnTop
            // 
            this.pnl_ReturnTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_ReturnTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_ReturnTop.Location = new System.Drawing.Point(3, 0);
            this.pnl_ReturnTop.Name = "pnl_ReturnTop";
            this.pnl_ReturnTop.Size = new System.Drawing.Size(1147, 3);
            this.pnl_ReturnTop.TabIndex = 122;
            // 
            // pnl_ReturnBottom
            // 
            this.pnl_ReturnBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_ReturnBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_ReturnBottom.Location = new System.Drawing.Point(3, 305);
            this.pnl_ReturnBottom.Name = "pnl_ReturnBottom";
            this.pnl_ReturnBottom.Size = new System.Drawing.Size(1147, 3);
            this.pnl_ReturnBottom.TabIndex = 121;
            // 
            // pnl_ReturnRight
            // 
            this.pnl_ReturnRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_ReturnRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_ReturnRight.Location = new System.Drawing.Point(1150, 0);
            this.pnl_ReturnRight.Name = "pnl_ReturnRight";
            this.pnl_ReturnRight.Size = new System.Drawing.Size(3, 308);
            this.pnl_ReturnRight.TabIndex = 120;
            // 
            // pnl_ReturnLeft
            // 
            this.pnl_ReturnLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_ReturnLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_ReturnLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_ReturnLeft.Name = "pnl_ReturnLeft";
            this.pnl_ReturnLeft.Size = new System.Drawing.Size(3, 308);
            this.pnl_ReturnLeft.TabIndex = 119;
            // 
            // pb_bar
            // 
            this.pb_bar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_bar.Image = global::Library.Properties.Resources.Barcode_70;
            this.pb_bar.Location = new System.Drawing.Point(893, 32);
            this.pb_bar.Name = "pb_bar";
            this.pb_bar.Size = new System.Drawing.Size(230, 70);
            this.pb_bar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_bar.TabIndex = 120;
            this.pb_bar.TabStop = false;
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_clear.BackColor = System.Drawing.Color.Red;
            this.btn_clear.FlatAppearance.BorderSize = 0;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.White;
            this.btn_clear.Image = global::Library.Properties.Resources.Clear;
            this.btn_clear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_clear.Location = new System.Drawing.Point(679, 17);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(86, 29);
            this.btn_clear.TabIndex = 127;
            this.btn_clear.Text = "  Clear";
            this.btn_clear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_idetails
            // 
            this.btn_idetails.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_idetails.BackColor = System.Drawing.Color.Navy;
            this.btn_idetails.FlatAppearance.BorderSize = 0;
            this.btn_idetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_idetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_idetails.ForeColor = System.Drawing.Color.White;
            this.btn_idetails.Image = global::Library.Properties.Resources.Up_Arrow;
            this.btn_idetails.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_idetails.Location = new System.Drawing.Point(771, 17);
            this.btn_idetails.Name = "btn_idetails";
            this.btn_idetails.Size = new System.Drawing.Size(188, 29);
            this.btn_idetails.TabIndex = 113;
            this.btn_idetails.Text = "Book Issue Details";
            this.btn_idetails.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_idetails.UseVisualStyleBackColor = false;
            this.btn_idetails.Click += new System.EventHandler(this.btn_idetails_Click);
            // 
            // btn_search
            // 
            this.btn_search.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_search.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_search.FlatAppearance.BorderSize = 0;
            this.btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.ForeColor = System.Drawing.Color.White;
            this.btn_search.Image = global::Library.Properties.Resources.search;
            this.btn_search.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_search.Location = new System.Drawing.Point(579, 17);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(94, 29);
            this.btn_search.TabIndex = 113;
            this.btn_search.Text = "Search";
            this.btn_search.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // UC_return
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnl_Return);
            this.Controls.Add(this.lbl_head);
            this.Controls.Add(this.pnl_bookreturn);
            this.Controls.Add(this.dgv);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "UC_return";
            this.Size = new System.Drawing.Size(1200, 720);
            this.pnl_bookreturn.ResumeLayout(false);
            this.pnl_bookreturn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.pnl_Return.ResumeLayout(false);
            this.pnl_Return.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_bookreturn;
        private System.Windows.Forms.Label lbl_sid;
        private System.Windows.Forms.TextBox txt_sid;
        private System.Windows.Forms.Label lbl_saveinfo;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_bookID;
        private System.Windows.Forms.DateTimePicker dtp_bookreturn;
        private System.Windows.Forms.Label lbl_bid;
        private System.Windows.Forms.Label lbl_sname;
        private System.Windows.Forms.Label lbl_isbn;
        private System.Windows.Forms.Label lbl_course;
        private System.Windows.Forms.TextBox txt_dept;
        private System.Windows.Forms.TextBox txt_course;
        private System.Windows.Forms.TextBox txt_author;
        private System.Windows.Forms.TextBox txt_bname;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_isbn;
        private System.Windows.Forms.Label lbl_author;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.Label lbl_bname;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Label lbl_sdept;
        private System.Windows.Forms.Button btn_idetails;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.TextBox txt_bookissue;
        private System.Windows.Forms.PictureBox pb_bar;
        private System.Windows.Forms.TextBox txt_barcode;
        private System.Windows.Forms.Label lbl_bar;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnl_Return;
        private System.Windows.Forms.Panel pnl_ReturnTop;
        private System.Windows.Forms.Panel pnl_ReturnBottom;
        private System.Windows.Forms.Panel pnl_ReturnRight;
        private System.Windows.Forms.Panel pnl_ReturnLeft;
        private System.Windows.Forms.Button btn_clear;
    }
}
