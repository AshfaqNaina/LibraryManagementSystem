﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library
{
    public partial class UC_Home : UserControl
    {
        public UC_Home()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;


        private void UC_Home_Load(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("select count(User_ID) from Users", con);
            int a = (Int32)cmd.ExecuteScalar();
            string totalStudent = a.ToString();
            lbl_totalStudent.Text = totalStudent;

            SqlCommand cmd1 = new SqlCommand("select count(Book_ID) from Book", con);
            int b = (Int32)cmd1.ExecuteScalar();
            string totalBook = b.ToString();
            lbl_totalBook.Text = totalBook;

            SqlCommand cmd2 = new SqlCommand("select count(Book_ID) from Withdraw", con);
            int c = (Int32)cmd2.ExecuteScalar();
            string BookIssue = c.ToString();
            lbl_bookIssue.Text = BookIssue;
            con.Close();
        }
    }
}
