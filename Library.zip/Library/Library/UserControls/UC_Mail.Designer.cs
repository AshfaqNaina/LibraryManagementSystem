﻿namespace Library
{
    partial class UC_Mail
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_Subject = new System.Windows.Forms.Label();
            this.rtxt_message = new System.Windows.Forms.RichTextBox();
            this.txt_To = new System.Windows.Forms.TextBox();
            this.lbl_To = new System.Windows.Forms.Label();
            this.txt_CC = new System.Windows.Forms.TextBox();
            this.lbl_CC = new System.Windows.Forms.Label();
            this.txt_subject = new System.Windows.Forms.TextBox();
            this.lbl_message = new System.Windows.Forms.Label();
            this.bunifu_SSL = new Bunifu.Framework.UI.BunifuCheckbox();
            this.pnl_Mail = new System.Windows.Forms.Panel();
            this.pb_Gmail = new System.Windows.Forms.PictureBox();
            this.lbl_head = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_MailBottom = new System.Windows.Forms.Panel();
            this.btn_send = new System.Windows.Forms.Button();
            this.pnl_MailTop = new System.Windows.Forms.Panel();
            this.pnl_MailRight = new System.Windows.Forms.Panel();
            this.pnl_MailLeft = new System.Windows.Forms.Panel();
            this.tooltip_mail = new System.Windows.Forms.ToolTip(this.components);
            this.pnl_Mail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Gmail)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Subject
            // 
            this.lbl_Subject.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_Subject.AutoSize = true;
            this.lbl_Subject.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subject.ForeColor = System.Drawing.Color.Black;
            this.lbl_Subject.Location = new System.Drawing.Point(216, 292);
            this.lbl_Subject.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Subject.Name = "lbl_Subject";
            this.lbl_Subject.Size = new System.Drawing.Size(86, 24);
            this.lbl_Subject.TabIndex = 126;
            this.lbl_Subject.Text = "Subject:";
            // 
            // rtxt_message
            // 
            this.rtxt_message.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rtxt_message.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxt_message.Location = new System.Drawing.Point(321, 343);
            this.rtxt_message.Name = "rtxt_message";
            this.rtxt_message.Size = new System.Drawing.Size(412, 142);
            this.rtxt_message.TabIndex = 123;
            this.rtxt_message.Text = "Please return the borrowed book otherwise you will pay fine\n";
            this.tooltip_mail.SetToolTip(this.rtxt_message, "Enter the message");
            // 
            // txt_To
            // 
            this.txt_To.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_To.BackColor = System.Drawing.SystemColors.Window;
            this.txt_To.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_To.Location = new System.Drawing.Point(321, 181);
            this.txt_To.Name = "txt_To";
            this.txt_To.Size = new System.Drawing.Size(412, 29);
            this.txt_To.TabIndex = 121;
            this.tooltip_mail.SetToolTip(this.txt_To, "Enter the Email ID");
            // 
            // lbl_To
            // 
            this.lbl_To.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_To.AutoSize = true;
            this.lbl_To.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_To.ForeColor = System.Drawing.Color.Black;
            this.lbl_To.Location = new System.Drawing.Point(261, 184);
            this.lbl_To.Name = "lbl_To";
            this.lbl_To.Size = new System.Drawing.Size(41, 24);
            this.lbl_To.TabIndex = 125;
            this.lbl_To.Text = "To:";
            // 
            // txt_CC
            // 
            this.txt_CC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_CC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CC.Location = new System.Drawing.Point(321, 235);
            this.txt_CC.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CC.Name = "txt_CC";
            this.txt_CC.Size = new System.Drawing.Size(412, 29);
            this.txt_CC.TabIndex = 122;
            this.tooltip_mail.SetToolTip(this.txt_CC, "Enter optional Email ID");
            // 
            // lbl_CC
            // 
            this.lbl_CC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_CC.AutoSize = true;
            this.lbl_CC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CC.ForeColor = System.Drawing.Color.Black;
            this.lbl_CC.Location = new System.Drawing.Point(258, 238);
            this.lbl_CC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_CC.Name = "lbl_CC";
            this.lbl_CC.Size = new System.Drawing.Size(44, 24);
            this.lbl_CC.TabIndex = 124;
            this.lbl_CC.Text = "CC:";
            // 
            // txt_subject
            // 
            this.txt_subject.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_subject.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_subject.Location = new System.Drawing.Point(321, 289);
            this.txt_subject.Margin = new System.Windows.Forms.Padding(4);
            this.txt_subject.Name = "txt_subject";
            this.txt_subject.Size = new System.Drawing.Size(412, 29);
            this.txt_subject.TabIndex = 127;
            this.txt_subject.Text = "Alert!! Return Your Books";
            this.tooltip_mail.SetToolTip(this.txt_subject, "Enter the subject title");
            // 
            // lbl_message
            // 
            this.lbl_message.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_message.AutoSize = true;
            this.lbl_message.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_message.ForeColor = System.Drawing.Color.Black;
            this.lbl_message.Location = new System.Drawing.Point(202, 346);
            this.lbl_message.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_message.Name = "lbl_message";
            this.lbl_message.Size = new System.Drawing.Size(100, 24);
            this.lbl_message.TabIndex = 128;
            this.lbl_message.Text = "Message:";
            // 
            // bunifu_SSL
            // 
            this.bunifu_SSL.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifu_SSL.ChechedOffColor = System.Drawing.Color.Gray;
            this.bunifu_SSL.Checked = true;
            this.bunifu_SSL.CheckedOnColor = System.Drawing.Color.SeaGreen;
            this.bunifu_SSL.ForeColor = System.Drawing.Color.White;
            this.bunifu_SSL.Location = new System.Drawing.Point(321, 508);
            this.bunifu_SSL.Margin = new System.Windows.Forms.Padding(20);
            this.bunifu_SSL.Name = "bunifu_SSL";
            this.bunifu_SSL.Size = new System.Drawing.Size(20, 20);
            this.bunifu_SSL.TabIndex = 133;
            this.tooltip_mail.SetToolTip(this.bunifu_SSL, "SSL Certificate");
            // 
            // pnl_Mail
            // 
            this.pnl_Mail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_Mail.Controls.Add(this.pb_Gmail);
            this.pnl_Mail.Controls.Add(this.lbl_head);
            this.pnl_Mail.Controls.Add(this.label1);
            this.pnl_Mail.Controls.Add(this.bunifu_SSL);
            this.pnl_Mail.Controls.Add(this.pnl_MailBottom);
            this.pnl_Mail.Controls.Add(this.btn_send);
            this.pnl_Mail.Controls.Add(this.pnl_MailTop);
            this.pnl_Mail.Controls.Add(this.pnl_MailRight);
            this.pnl_Mail.Controls.Add(this.lbl_message);
            this.pnl_Mail.Controls.Add(this.pnl_MailLeft);
            this.pnl_Mail.Controls.Add(this.txt_subject);
            this.pnl_Mail.Controls.Add(this.rtxt_message);
            this.pnl_Mail.Controls.Add(this.lbl_Subject);
            this.pnl_Mail.Controls.Add(this.lbl_CC);
            this.pnl_Mail.Controls.Add(this.txt_CC);
            this.pnl_Mail.Controls.Add(this.txt_To);
            this.pnl_Mail.Controls.Add(this.lbl_To);
            this.pnl_Mail.Location = new System.Drawing.Point(30, 26);
            this.pnl_Mail.Name = "pnl_Mail";
            this.pnl_Mail.Size = new System.Drawing.Size(989, 584);
            this.pnl_Mail.TabIndex = 133;
            // 
            // pb_Gmail
            // 
            this.pb_Gmail.Image = global::Library.Properties.Resources.Gmail_max;
            this.pb_Gmail.Location = new System.Drawing.Point(444, 65);
            this.pb_Gmail.Name = "pb_Gmail";
            this.pb_Gmail.Size = new System.Drawing.Size(100, 100);
            this.pb_Gmail.TabIndex = 136;
            this.pb_Gmail.TabStop = false;
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(398, 22);
            this.lbl_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(192, 40);
            this.lbl_head.TabIndex = 135;
            this.lbl_head.Text = "Mail Service";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(249, 506);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 24);
            this.label1.TabIndex = 134;
            this.label1.Text = "SSL:";
            // 
            // pnl_MailBottom
            // 
            this.pnl_MailBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_MailBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_MailBottom.Location = new System.Drawing.Point(3, 581);
            this.pnl_MailBottom.Name = "pnl_MailBottom";
            this.pnl_MailBottom.Size = new System.Drawing.Size(983, 3);
            this.pnl_MailBottom.TabIndex = 124;
            // 
            // btn_send
            // 
            this.btn_send.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_send.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_send.FlatAppearance.BorderSize = 0;
            this.btn_send.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_send.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_send.ForeColor = System.Drawing.Color.White;
            this.btn_send.Image = global::Library.Properties.Resources.Send;
            this.btn_send.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_send.Location = new System.Drawing.Point(631, 505);
            this.btn_send.Name = "btn_send";
            this.btn_send.Size = new System.Drawing.Size(91, 29);
            this.btn_send.TabIndex = 132;
            this.btn_send.Text = "    Send";
            this.btn_send.UseVisualStyleBackColor = false;
            this.btn_send.Click += new System.EventHandler(this.btn_send_Click);
            // 
            // pnl_MailTop
            // 
            this.pnl_MailTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_MailTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_MailTop.Location = new System.Drawing.Point(3, 0);
            this.pnl_MailTop.Name = "pnl_MailTop";
            this.pnl_MailTop.Size = new System.Drawing.Size(983, 3);
            this.pnl_MailTop.TabIndex = 123;
            // 
            // pnl_MailRight
            // 
            this.pnl_MailRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_MailRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_MailRight.Location = new System.Drawing.Point(986, 0);
            this.pnl_MailRight.Name = "pnl_MailRight";
            this.pnl_MailRight.Size = new System.Drawing.Size(3, 584);
            this.pnl_MailRight.TabIndex = 121;
            // 
            // pnl_MailLeft
            // 
            this.pnl_MailLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_MailLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_MailLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_MailLeft.Name = "pnl_MailLeft";
            this.pnl_MailLeft.Size = new System.Drawing.Size(3, 584);
            this.pnl_MailLeft.TabIndex = 120;
            // 
            // UC_Mail
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnl_Mail);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "UC_Mail";
            this.Size = new System.Drawing.Size(1048, 637);
            this.pnl_Mail.ResumeLayout(false);
            this.pnl_Mail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Gmail)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lbl_Subject;
        private System.Windows.Forms.RichTextBox rtxt_message;
        private System.Windows.Forms.TextBox txt_To;
        private System.Windows.Forms.Label lbl_To;
        private System.Windows.Forms.TextBox txt_CC;
        private System.Windows.Forms.Label lbl_CC;
        private System.Windows.Forms.TextBox txt_subject;
        private System.Windows.Forms.Label lbl_message;
        private Bunifu.Framework.UI.BunifuCheckbox bunifu_SSL;
        private System.Windows.Forms.Button btn_send;
        private System.Windows.Forms.Panel pnl_Mail;
        private System.Windows.Forms.Panel pnl_MailBottom;
        private System.Windows.Forms.Panel pnl_MailTop;
        private System.Windows.Forms.Panel pnl_MailRight;
        private System.Windows.Forms.Panel pnl_MailLeft;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.PictureBox pb_Gmail;
        private System.Windows.Forms.ToolTip tooltip_mail;
    }
}
