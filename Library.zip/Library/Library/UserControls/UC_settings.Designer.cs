﻿namespace Library
{
    partial class UC_settings
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_browse = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.lbl_saveinfo = new System.Windows.Forms.Label();
            this.pnl_PB = new System.Windows.Forms.Panel();
            this.pnl_PBbottom = new System.Windows.Forms.Panel();
            this.pnl_PBtop = new System.Windows.Forms.Panel();
            this.pnl_PBleft = new System.Windows.Forms.Panel();
            this.pnl_PBright = new System.Windows.Forms.Panel();
            this.pb_student = new System.Windows.Forms.PictureBox();
            this.pnl_PB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_browse
            // 
            this.btn_browse.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_browse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.btn_browse.FlatAppearance.BorderSize = 0;
            this.btn_browse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_browse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_browse.ForeColor = System.Drawing.Color.White;
            this.btn_browse.Location = new System.Drawing.Point(850, 348);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(92, 32);
            this.btn_browse.TabIndex = 116;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = false;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            // 
            // btn_save
            // 
            this.btn_save.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_save.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Location = new System.Drawing.Point(844, 408);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(100, 35);
            this.btn_save.TabIndex = 118;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // lbl_saveinfo
            // 
            this.lbl_saveinfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_saveinfo.AutoSize = true;
            this.lbl_saveinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saveinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_saveinfo.Location = new System.Drawing.Point(773, 483);
            this.lbl_saveinfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_saveinfo.Name = "lbl_saveinfo";
            this.lbl_saveinfo.Size = new System.Drawing.Size(18, 24);
            this.lbl_saveinfo.TabIndex = 119;
            this.lbl_saveinfo.Text = "*";
            // 
            // pnl_PB
            // 
            this.pnl_PB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_PB.Controls.Add(this.pnl_PBbottom);
            this.pnl_PB.Controls.Add(this.pnl_PBtop);
            this.pnl_PB.Controls.Add(this.pnl_PBleft);
            this.pnl_PB.Controls.Add(this.pnl_PBright);
            this.pnl_PB.Controls.Add(this.pb_student);
            this.pnl_PB.Location = new System.Drawing.Point(794, 106);
            this.pnl_PB.Name = "pnl_PB";
            this.pnl_PB.Size = new System.Drawing.Size(195, 236);
            this.pnl_PB.TabIndex = 120;
            // 
            // pnl_PBbottom
            // 
            this.pnl_PBbottom.BackColor = System.Drawing.Color.White;
            this.pnl_PBbottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_PBbottom.Location = new System.Drawing.Point(10, 226);
            this.pnl_PBbottom.Name = "pnl_PBbottom";
            this.pnl_PBbottom.Size = new System.Drawing.Size(175, 10);
            this.pnl_PBbottom.TabIndex = 3;
            // 
            // pnl_PBtop
            // 
            this.pnl_PBtop.BackColor = System.Drawing.Color.White;
            this.pnl_PBtop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_PBtop.Location = new System.Drawing.Point(10, 0);
            this.pnl_PBtop.Name = "pnl_PBtop";
            this.pnl_PBtop.Size = new System.Drawing.Size(175, 10);
            this.pnl_PBtop.TabIndex = 2;
            // 
            // pnl_PBleft
            // 
            this.pnl_PBleft.BackColor = System.Drawing.Color.White;
            this.pnl_PBleft.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_PBleft.Location = new System.Drawing.Point(185, 0);
            this.pnl_PBleft.Name = "pnl_PBleft";
            this.pnl_PBleft.Size = new System.Drawing.Size(10, 236);
            this.pnl_PBleft.TabIndex = 1;
            // 
            // pnl_PBright
            // 
            this.pnl_PBright.BackColor = System.Drawing.Color.White;
            this.pnl_PBright.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_PBright.Location = new System.Drawing.Point(0, 0);
            this.pnl_PBright.Name = "pnl_PBright";
            this.pnl_PBright.Size = new System.Drawing.Size(10, 236);
            this.pnl_PBright.TabIndex = 0;
            // 
            // pb_student
            // 
            this.pb_student.Image = global::Library.Properties.Resources.No;
            this.pb_student.Location = new System.Drawing.Point(10, 8);
            this.pb_student.Name = "pb_student";
            this.pb_student.Size = new System.Drawing.Size(176, 230);
            this.pb_student.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_student.TabIndex = 95;
            this.pb_student.TabStop = false;
            // 
            // UC_settings
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnl_PB);
            this.Controls.Add(this.lbl_saveinfo);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_browse);
            this.Name = "UC_settings";
            this.Size = new System.Drawing.Size(1048, 637);
            this.pnl_PB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Label lbl_saveinfo;
        private System.Windows.Forms.Panel pnl_PB;
        private System.Windows.Forms.Panel pnl_PBbottom;
        private System.Windows.Forms.Panel pnl_PBtop;
        private System.Windows.Forms.Panel pnl_PBleft;
        private System.Windows.Forms.Panel pnl_PBright;
        private System.Windows.Forms.PictureBox pb_student;
    }
}
