﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library
{
    public partial class UC_Reports : UserControl
    {
        public UC_Reports()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;
        private void UC_Reports_Load(object sender, EventArgs e)
        {
           
        }

        private void btn_student_Click(object sender, EventArgs e)
        {
            Reports.Student_details crpt = new Reports.Student_details();
            cmd = new SqlCommand("select * from Users", con);
            da = new SqlDataAdapter(cmd);
            DataSet.LibraryDataSet ds = new DataSet.LibraryDataSet();
            da.Fill(ds, "Users");
            crpt.SetDataSource(ds);
            crpt_viewer.ReportSource = null;
            crpt_viewer.ReportSource = crpt;
        }

        private void btn_Book_Click(object sender, EventArgs e)
        {
            Reports.Book_details crpt = new Reports.Book_details();
            cmd = new SqlCommand("select * from Book", con);
            da = new SqlDataAdapter(cmd);
            DataSet.LibraryDataSet ds = new DataSet.LibraryDataSet();
            da.Fill(ds, "Book");
            crpt.SetDataSource(ds);
            crpt_viewer.ReportSource = null;
            crpt_viewer.ReportSource = crpt;
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            Reports.Book_withraw crpt = new Reports.Book_withraw();
            cmd = new SqlCommand("select * from Withdraw", con);
            da = new SqlDataAdapter(cmd);
            DataSet.LibraryDataSet ds = new DataSet.LibraryDataSet();
            da.Fill(ds, "Withdraw");
            crpt.SetDataSource(ds);
            crpt_viewer.ReportSource = null;
            crpt_viewer.ReportSource = crpt;
        }

        private void btn_logs_Click(object sender, EventArgs e)
        {
            Reports.Book_Logs crpt = new Reports.Book_Logs();
            cmd = new SqlCommand("select * from Logs", con);
            da = new SqlDataAdapter(cmd);
            DataSet.LibraryDataSet ds = new DataSet.LibraryDataSet();
            da.Fill(ds, "Logs");
            crpt.SetDataSource(ds);
            crpt_viewer.ReportSource = null;
            crpt_viewer.ReportSource = crpt;
        }
    }
}
