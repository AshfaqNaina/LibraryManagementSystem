﻿namespace Library.UserControls
{
    partial class UC_logs
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv = new System.Windows.Forms.DataGridView();
            this.lbl_head = new System.Windows.Forms.Label();
            this.btn_clearlogs = new System.Windows.Forms.Button();
            this.lbl_saveinfo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(19, 84);
            this.dgv.Margin = new System.Windows.Forms.Padding(6);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.RowHeadersWidth = 51;
            this.dgv.Size = new System.Drawing.Size(1163, 573);
            this.dgv.TabIndex = 93;
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(523, 28);
            this.lbl_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(165, 40);
            this.lbl_head.TabIndex = 117;
            this.lbl_head.Text = "Book Logs";
            // 
            // btn_clearlogs
            // 
            this.btn_clearlogs.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btn_clearlogs.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_clearlogs.FlatAppearance.BorderSize = 0;
            this.btn_clearlogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clearlogs.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clearlogs.ForeColor = System.Drawing.Color.White;
            this.btn_clearlogs.Location = new System.Drawing.Point(1003, 666);
            this.btn_clearlogs.Name = "btn_clearlogs";
            this.btn_clearlogs.Size = new System.Drawing.Size(179, 35);
            this.btn_clearlogs.TabIndex = 118;
            this.btn_clearlogs.Text = "Clear Logs";
            this.btn_clearlogs.UseVisualStyleBackColor = false;
            this.btn_clearlogs.Click += new System.EventHandler(this.btn_clearlogs_Click);
            // 
            // lbl_saveinfo
            // 
            this.lbl_saveinfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_saveinfo.AutoSize = true;
            this.lbl_saveinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saveinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_saveinfo.Location = new System.Drawing.Point(354, 675);
            this.lbl_saveinfo.Name = "lbl_saveinfo";
            this.lbl_saveinfo.Size = new System.Drawing.Size(15, 18);
            this.lbl_saveinfo.TabIndex = 119;
            this.lbl_saveinfo.Text = "*";
            // 
            // UC_logs
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.lbl_saveinfo);
            this.Controls.Add(this.btn_clearlogs);
            this.Controls.Add(this.lbl_head);
            this.Controls.Add(this.dgv);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "UC_logs";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_logs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.Button btn_clearlogs;
        private System.Windows.Forms.Label lbl_saveinfo;
    }
}
