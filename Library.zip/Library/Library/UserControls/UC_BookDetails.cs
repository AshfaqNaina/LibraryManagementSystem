﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Library
{
    public partial class UC_BookDetails : UserControl
    {
        public UC_BookDetails()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;
        DataTable dt;
        private void btn_category_Click(object sender, EventArgs e)
        {

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_bname.Text != "" && txt_author.Text != "" && txt_isbn.Text != "" && txt_price.Text != "" && txt_publisher.Text != "" && cb_category.SelectedIndex != -1)
                {
                    if (MessageBox.Show("Do you want to save the book details", "Library Project", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.No)
                    {       
                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into Book(Book_ID,Book_Name,Author,Publisher,ISBN_No,Category,Price,Quantity,Barcode,Remarks) values('" + txt_bookID.Text + "','" + txt_bname.Text + "','" + txt_author.Text + "','" + txt_publisher.Text + "','" + txt_isbn.Text + "','" + cb_category.Text + "','" + txt_price.Text + "','" + txt_quantity.Text + "','"+txt_barcode.Text+"','" + rtxt_remarks.Text + "')", con);
                        cmd.ExecuteNonQuery();
                        lbl_saveinfo.Text = "You added a new Book!!!";
                        con.Close();
                    }
                }
                else
                {
                    lbl_saveinfo.ForeColor = Color.Red;
                    lbl_saveinfo.Text = "Please fill all the Details";
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Invalid price details please check", "Library Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select Book_ID,Book_Name,Author,Publisher,ISBN_No,Category,Price,Quantity,Barcode,Remarks from Book", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void UC_BookDetails_Load(object sender, EventArgs e)
        {
            User_ID();
        }

        string User_ID()
        {
            con.Open();
            cmd = new SqlCommand("select count(*) from Book", con);
            int a = 101 + (Int32)cmd.ExecuteScalar();
            string reg = "B" + a.ToString();
            txt_bookID.Text = reg;
            con.Close();
            return (reg);
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do you want to update the book details", "Library Project", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.No)
                {
                    con.Open();
                    cmd = new SqlCommand("update Book Set Book_Name='" + txt_bname.Text + "',Author='" + txt_author.Text + "',Publisher='" + txt_publisher.Text + "',ISBN_No='" + txt_isbn.Text + "',Category='" + cb_category.Text + "',Price='" + txt_price.Text + "',Quantity='" + txt_quantity.Text + "',Barcode='" + txt_barcode.Text + "',Remarks='" + rtxt_remarks.Text + "' where Book_ID='" + txt_bookID.Text + "'", con);
                    dr = cmd.ExecuteReader();
                    lbl_saveinfo.Text = "Update Successfully";
                    con.Close();
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do you want to delete the book details", "Library Project", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.No)
                {
                    con.Open();
                    cmd = new SqlCommand("delete from Book where Book_ID='" + txt_bookID.Text + "'", con);
                    dr = cmd.ExecuteReader();
                    con.Close();
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_bookID.Clear();
            txt_bname.Clear();
            txt_isbn.Clear();
            txt_price.Clear();
            txt_publisher.Clear();
            txt_author.Clear();
            cb_category.SelectedIndex = -1;
            lbl_saveinfo.Text = "";
            txt_quantity.Clear();
            txt_search.Clear();
            rtxt_remarks.Clear();
            txt_barcode.Clear();
            txt_bookID.Focus();

            con.Open();
            cmd = new SqlCommand("select * from Res_Images where Id=4", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            byte[] image = (byte[])dt.Rows[0][1];
            MemoryStream ms = new MemoryStream(image);
            pb_bar.Image = Image.FromStream(ms);
            con.Close();
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgv.Rows[e.RowIndex];
                txt_bookID.Text = row.Cells["Book_ID"].Value.ToString();
                txt_bname.Text = row.Cells["Book_Name"].Value.ToString();
                txt_author.Text = row.Cells["Author"].Value.ToString();
                txt_publisher.Text = row.Cells["Publisher"].Value.ToString();
                txt_isbn.Text = row.Cells["ISBN_No"].Value.ToString();
                cb_category.Text = row.Cells["Category"].Value.ToString();
                txt_price.Text = row.Cells["Price"].Value.ToString();
                txt_quantity.Text = row.Cells["Quantity"].Value.ToString();
                txt_barcode.Text = row.Cells["Barcode"].Value.ToString();
                rtxt_remarks.Text = row.Cells["Remarks"].Value.ToString();
                string barCode = txt_barcode.Text;
                try
                {
                    Zen.Barcode.Code128BarcodeDraw brCode = Zen.Barcode.BarcodeDrawFactory.Code128WithChecksum;
                    pb_bar.Image = brCode.Draw(barCode, 60);
                }
                catch (Exception x)
                {
                    MessageBox.Show(x.Message, "Library Project", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                }
            }

        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select Book_ID,Book_Name,Author,Publisher,ISBN_No,Category,Price,Quantity,Barcode,Remarks from Book where Book_ID like '%" + txt_search.Text + "%' or Book_Name like '%" + txt_search.Text + "%' or Author like '%" + txt_search.Text + "%' or Publisher like '%" + txt_search.Text + "%' or ISBN_No  like '%" + txt_search.Text + "%' or Category like '%" + txt_search.Text + "%' or Price  like '%" + txt_search.Text + "%' or Quantity like  '%" + txt_search.Text + "%' or Barcode like  '%" + txt_search.Text + "%' or Remarks like  '%" + txt_search.Text + "%'", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void chb_bar_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                txt_barcode.Text= "Book_ID=" + txt_bookID.Text + "%" + txt_bname.Text + "";
                Zen.Barcode.Code128BarcodeDraw brCode = Zen.Barcode.BarcodeDrawFactory.Code128WithChecksum;
                pb_bar.BackColor = Color.Transparent;
                pb_bar.Image = brCode.Draw(txt_barcode.Text, 60);
            }
            catch(Exception x)
            {
                MessageBox.Show(x.Message,"Library Project",MessageBoxButtons.OK,MessageBoxIcon.Information);
                con.Close();
            }
        }
    }
}
