﻿namespace Library
{
    partial class UC_Student
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_mobile = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.lbl_course = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_age = new System.Windows.Forms.Label();
            this.lbl_mobile = new System.Windows.Forms.Label();
            this.lbl_head = new System.Windows.Forms.Label();
            this.lbl_name = new System.Windows.Forms.Label();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_view = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_browse = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.cb_age = new System.Windows.Forms.ComboBox();
            this.lbl_saveinfo = new System.Windows.Forms.Label();
            this.txt_UserID = new System.Windows.Forms.TextBox();
            this.lbl_uid = new System.Windows.Forms.Label();
            this.rtxt_address = new System.Windows.Forms.RichTextBox();
            this.cb_course = new System.Windows.Forms.ComboBox();
            this.cb_dept = new System.Windows.Forms.ComboBox();
            this.lbl_address = new System.Windows.Forms.Label();
            this.lbl_dept = new System.Windows.Forms.Label();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.lbl_search = new System.Windows.Forms.Label();
            this.pnl_dgv = new System.Windows.Forms.Panel();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.lbl_Role = new System.Windows.Forms.Label();
            this.lbl_qr = new System.Windows.Forms.Label();
            this.btn_qrcode = new System.Windows.Forms.Button();
            this.pb_qrcode = new System.Windows.Forms.PictureBox();
            this.cb_role = new System.Windows.Forms.ComboBox();
            this.txt_qrcode = new System.Windows.Forms.TextBox();
            this.lbl_qrcode = new System.Windows.Forms.Label();
            this.pnl_PB = new System.Windows.Forms.Panel();
            this.pnl_PBbottom = new System.Windows.Forms.Panel();
            this.pnl_PBtop = new System.Windows.Forms.Panel();
            this.pnl_PBleft = new System.Windows.Forms.Panel();
            this.pnl_PBright = new System.Windows.Forms.Panel();
            this.pb_student = new System.Windows.Forms.PictureBox();
            this.btn_cam = new System.Windows.Forms.Button();
            this.pnl_dgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_qrcode)).BeginInit();
            this.pnl_PB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_email
            // 
            this.txt_email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.Location = new System.Drawing.Point(603, 198);
            this.txt_email.Margin = new System.Windows.Forms.Padding(4);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(237, 29);
            this.txt_email.TabIndex = 6;
            this.txt_email.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_email_KeyDown);
            // 
            // txt_mobile
            // 
            this.txt_mobile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_mobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mobile.Location = new System.Drawing.Point(603, 247);
            this.txt_mobile.Margin = new System.Windows.Forms.Padding(4);
            this.txt_mobile.Name = "txt_mobile";
            this.txt_mobile.Size = new System.Drawing.Size(237, 29);
            this.txt_mobile.TabIndex = 7;
            this.txt_mobile.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_mobile_KeyDown);
            // 
            // txt_name
            // 
            this.txt_name.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name.Location = new System.Drawing.Point(187, 143);
            this.txt_name.Margin = new System.Windows.Forms.Padding(4);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(236, 29);
            this.txt_name.TabIndex = 1;
            this.txt_name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_name_KeyDown);
            // 
            // lbl_course
            // 
            this.lbl_course.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_course.AutoSize = true;
            this.lbl_course.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course.ForeColor = System.Drawing.Color.Black;
            this.lbl_course.Location = new System.Drawing.Point(509, 97);
            this.lbl_course.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_course.Name = "lbl_course";
            this.lbl_course.Size = new System.Drawing.Size(83, 24);
            this.lbl_course.TabIndex = 29;
            this.lbl_course.Text = "Course:";
            // 
            // lbl_email
            // 
            this.lbl_email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_email.AutoSize = true;
            this.lbl_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.ForeColor = System.Drawing.Color.Black;
            this.lbl_email.Location = new System.Drawing.Point(524, 201);
            this.lbl_email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(68, 24);
            this.lbl_email.TabIndex = 28;
            this.lbl_email.Text = "Email:";
            // 
            // lbl_age
            // 
            this.lbl_age.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_age.AutoSize = true;
            this.lbl_age.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_age.ForeColor = System.Drawing.Color.Black;
            this.lbl_age.Location = new System.Drawing.Point(117, 305);
            this.lbl_age.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_age.Name = "lbl_age";
            this.lbl_age.Size = new System.Drawing.Size(54, 24);
            this.lbl_age.TabIndex = 27;
            this.lbl_age.Text = "Age:";
            // 
            // lbl_mobile
            // 
            this.lbl_mobile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_mobile.AutoSize = true;
            this.lbl_mobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mobile.ForeColor = System.Drawing.Color.Black;
            this.lbl_mobile.Location = new System.Drawing.Point(513, 250);
            this.lbl_mobile.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_mobile.Name = "lbl_mobile";
            this.lbl_mobile.Size = new System.Drawing.Size(79, 24);
            this.lbl_mobile.TabIndex = 26;
            this.lbl_mobile.Text = "Mobile:";
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(502, 27);
            this.lbl_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(220, 40);
            this.lbl_head.TabIndex = 33;
            this.lbl_head.Text = "Manage Users";
            // 
            // lbl_name
            // 
            this.lbl_name.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.ForeColor = System.Drawing.Color.Black;
            this.lbl_name.Location = new System.Drawing.Point(101, 146);
            this.lbl_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(71, 24);
            this.lbl_name.TabIndex = 25;
            this.lbl_name.Text = "Name:";
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_clear.BackColor = System.Drawing.Color.Gray;
            this.btn_clear.FlatAppearance.BorderSize = 0;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.White;
            this.btn_clear.Location = new System.Drawing.Point(712, 410);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(100, 35);
            this.btn_clear.TabIndex = 16;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_update
            // 
            this.btn_update.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_update.BackColor = System.Drawing.Color.Orange;
            this.btn_update.FlatAppearance.BorderSize = 0;
            this.btn_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.ForeColor = System.Drawing.Color.White;
            this.btn_update.Location = new System.Drawing.Point(338, 409);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(105, 35);
            this.btn_update.TabIndex = 13;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_view
            // 
            this.btn_view.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_view.BackColor = System.Drawing.Color.Navy;
            this.btn_view.FlatAppearance.BorderSize = 0;
            this.btn_view.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_view.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_view.ForeColor = System.Drawing.Color.White;
            this.btn_view.Location = new System.Drawing.Point(589, 409);
            this.btn_view.Name = "btn_view";
            this.btn_view.Size = new System.Drawing.Size(100, 35);
            this.btn_view.TabIndex = 15;
            this.btn_view.Text = "View";
            this.btn_view.UseVisualStyleBackColor = false;
            this.btn_view.Click += new System.EventHandler(this.btn_view_Click);
            // 
            // btn_save
            // 
            this.btn_save.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_save.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Location = new System.Drawing.Point(215, 409);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(100, 35);
            this.btn_save.TabIndex = 12;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_browse
            // 
            this.btn_browse.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_browse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.btn_browse.FlatAppearance.BorderSize = 0;
            this.btn_browse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_browse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_browse.ForeColor = System.Drawing.Color.White;
            this.btn_browse.Location = new System.Drawing.Point(928, 351);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(92, 32);
            this.btn_browse.TabIndex = 10;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = false;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_delete.BackColor = System.Drawing.Color.Red;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Location = new System.Drawing.Point(466, 409);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(100, 35);
            this.btn_delete.TabIndex = 14;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // cb_age
            // 
            this.cb_age.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_age.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_age.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_age.FormattingEnabled = true;
            this.cb_age.Items.AddRange(new object[] {
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this.cb_age.Location = new System.Drawing.Point(188, 302);
            this.cb_age.Margin = new System.Windows.Forms.Padding(4);
            this.cb_age.Name = "cb_age";
            this.cb_age.Size = new System.Drawing.Size(235, 32);
            this.cb_age.TabIndex = 3;
            this.cb_age.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cb_age_KeyDown);
            // 
            // lbl_saveinfo
            // 
            this.lbl_saveinfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_saveinfo.AutoSize = true;
            this.lbl_saveinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saveinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_saveinfo.Location = new System.Drawing.Point(334, 469);
            this.lbl_saveinfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_saveinfo.Name = "lbl_saveinfo";
            this.lbl_saveinfo.Size = new System.Drawing.Size(18, 24);
            this.lbl_saveinfo.TabIndex = 99;
            this.lbl_saveinfo.Text = "*";
            // 
            // txt_UserID
            // 
            this.txt_UserID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_UserID.BackColor = System.Drawing.SystemColors.Window;
            this.txt_UserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_UserID.Location = new System.Drawing.Point(187, 94);
            this.txt_UserID.Name = "txt_UserID";
            this.txt_UserID.Size = new System.Drawing.Size(235, 29);
            this.txt_UserID.TabIndex = 0;
            this.txt_UserID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_UserID_KeyDown);
            // 
            // lbl_uid
            // 
            this.lbl_uid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_uid.AutoSize = true;
            this.lbl_uid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uid.ForeColor = System.Drawing.Color.Black;
            this.lbl_uid.Location = new System.Drawing.Point(73, 97);
            this.lbl_uid.Name = "lbl_uid";
            this.lbl_uid.Size = new System.Drawing.Size(99, 24);
            this.lbl_uid.TabIndex = 100;
            this.lbl_uid.Text = "User\'s ID:";
            // 
            // rtxt_address
            // 
            this.rtxt_address.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rtxt_address.Location = new System.Drawing.Point(187, 192);
            this.rtxt_address.Name = "rtxt_address";
            this.rtxt_address.Size = new System.Drawing.Size(235, 90);
            this.rtxt_address.TabIndex = 2;
            this.rtxt_address.Text = "";
            this.rtxt_address.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rtxt_address_KeyDown);
            // 
            // cb_course
            // 
            this.cb_course.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_course.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_course.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_course.FormattingEnabled = true;
            this.cb_course.Items.AddRange(new object[] {
            "BCA",
            "BSc",
            "BA",
            "BCom",
            "BBA"});
            this.cb_course.Location = new System.Drawing.Point(603, 94);
            this.cb_course.Margin = new System.Windows.Forms.Padding(4);
            this.cb_course.Name = "cb_course";
            this.cb_course.Size = new System.Drawing.Size(237, 32);
            this.cb_course.TabIndex = 4;
            this.cb_course.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cb_course_KeyDown);
            // 
            // cb_dept
            // 
            this.cb_dept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_dept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_dept.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_dept.FormattingEnabled = true;
            this.cb_dept.Items.AddRange(new object[] {
            "Information Technology",
            "Computer Science",
            "Mathematics",
            "Chemistry",
            "Physics",
            "Commerce",
            "Business Administration",
            "Visual Communication",
            "English",
            "Tamil",
            "Arabic",
            "Economics",
            "Nutrition",
            "Fashion Designing"});
            this.cb_dept.Location = new System.Drawing.Point(603, 146);
            this.cb_dept.Margin = new System.Windows.Forms.Padding(4);
            this.cb_dept.Name = "cb_dept";
            this.cb_dept.Size = new System.Drawing.Size(237, 32);
            this.cb_dept.TabIndex = 5;
            this.cb_dept.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cb_dept_KeyDown);
            // 
            // lbl_address
            // 
            this.lbl_address.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_address.AutoSize = true;
            this.lbl_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address.ForeColor = System.Drawing.Color.Black;
            this.lbl_address.Location = new System.Drawing.Point(79, 196);
            this.lbl_address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(93, 24);
            this.lbl_address.TabIndex = 105;
            this.lbl_address.Text = "Address:";
            // 
            // lbl_dept
            // 
            this.lbl_dept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_dept.AutoSize = true;
            this.lbl_dept.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dept.ForeColor = System.Drawing.Color.Black;
            this.lbl_dept.Location = new System.Drawing.Point(533, 149);
            this.lbl_dept.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_dept.Name = "lbl_dept";
            this.lbl_dept.Size = new System.Drawing.Size(59, 24);
            this.lbl_dept.TabIndex = 106;
            this.lbl_dept.Text = "Dept:";
            // 
            // txt_search
            // 
            this.txt_search.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(187, 509);
            this.txt_search.Margin = new System.Windows.Forms.Padding(4);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(653, 29);
            this.txt_search.TabIndex = 17;
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // lbl_search
            // 
            this.lbl_search.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.ForeColor = System.Drawing.Color.Black;
            this.lbl_search.Location = new System.Drawing.Point(89, 512);
            this.lbl_search.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(82, 24);
            this.lbl_search.TabIndex = 110;
            this.lbl_search.Text = "Search:";
            // 
            // pnl_dgv
            // 
            this.pnl_dgv.Controls.Add(this.dgv);
            this.pnl_dgv.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_dgv.Location = new System.Drawing.Point(0, 557);
            this.pnl_dgv.Name = "pnl_dgv";
            this.pnl_dgv.Size = new System.Drawing.Size(1200, 163);
            this.pnl_dgv.TabIndex = 111;
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.Location = new System.Drawing.Point(0, 0);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.Size = new System.Drawing.Size(1200, 163);
            this.dgv.TabIndex = 0;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // lbl_Role
            // 
            this.lbl_Role.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_Role.AutoSize = true;
            this.lbl_Role.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Role.ForeColor = System.Drawing.Color.Black;
            this.lbl_Role.Location = new System.Drawing.Point(533, 299);
            this.lbl_Role.Name = "lbl_Role";
            this.lbl_Role.Size = new System.Drawing.Size(59, 24);
            this.lbl_Role.TabIndex = 113;
            this.lbl_Role.Text = "Role:";
            // 
            // lbl_qr
            // 
            this.lbl_qr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_qr.AutoSize = true;
            this.lbl_qr.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_qr.ForeColor = System.Drawing.Color.Crimson;
            this.lbl_qr.Location = new System.Drawing.Point(964, 517);
            this.lbl_qr.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_qr.Name = "lbl_qr";
            this.lbl_qr.Size = new System.Drawing.Size(104, 24);
            this.lbl_qr.TabIndex = 116;
            this.lbl_qr.Text = "User\'s QR";
            // 
            // btn_qrcode
            // 
            this.btn_qrcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_qrcode.BackColor = System.Drawing.Color.Crimson;
            this.btn_qrcode.FlatAppearance.BorderSize = 0;
            this.btn_qrcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_qrcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_qrcode.ForeColor = System.Drawing.Color.White;
            this.btn_qrcode.Image = global::Library.Properties.Resources.QRcode;
            this.btn_qrcode.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_qrcode.Location = new System.Drawing.Point(603, 354);
            this.btn_qrcode.Name = "btn_qrcode";
            this.btn_qrcode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_qrcode.Size = new System.Drawing.Size(237, 29);
            this.btn_qrcode.TabIndex = 9;
            this.btn_qrcode.Text = "     Generate QR Code                             ";
            this.btn_qrcode.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btn_qrcode.UseVisualStyleBackColor = false;
            this.btn_qrcode.Click += new System.EventHandler(this.btn_qrcode_Click);
            this.btn_qrcode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btn_qrcode_KeyDown);
            // 
            // pb_qrcode
            // 
            this.pb_qrcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_qrcode.BackColor = System.Drawing.Color.Crimson;
            this.pb_qrcode.Image = global::Library.Properties.Resources.QR_pb_box;
            this.pb_qrcode.Location = new System.Drawing.Point(954, 396);
            this.pb_qrcode.Name = "pb_qrcode";
            this.pb_qrcode.Size = new System.Drawing.Size(120, 120);
            this.pb_qrcode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_qrcode.TabIndex = 112;
            this.pb_qrcode.TabStop = false;
            // 
            // cb_role
            // 
            this.cb_role.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_role.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_role.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_role.FormattingEnabled = true;
            this.cb_role.Items.AddRange(new object[] {
            "Admin",
            "Student",
            "User",
            "Other"});
            this.cb_role.Location = new System.Drawing.Point(603, 296);
            this.cb_role.Margin = new System.Windows.Forms.Padding(4);
            this.cb_role.Name = "cb_role";
            this.cb_role.Size = new System.Drawing.Size(237, 32);
            this.cb_role.TabIndex = 8;
            this.cb_role.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cb_role_KeyDown);
            // 
            // txt_qrcode
            // 
            this.txt_qrcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_qrcode.BackColor = System.Drawing.SystemColors.Window;
            this.txt_qrcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_qrcode.ForeColor = System.Drawing.Color.Black;
            this.txt_qrcode.Location = new System.Drawing.Point(188, 354);
            this.txt_qrcode.Margin = new System.Windows.Forms.Padding(4);
            this.txt_qrcode.Name = "txt_qrcode";
            this.txt_qrcode.Size = new System.Drawing.Size(415, 29);
            this.txt_qrcode.TabIndex = 119;
            // 
            // lbl_qrcode
            // 
            this.lbl_qrcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_qrcode.AutoSize = true;
            this.lbl_qrcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_qrcode.ForeColor = System.Drawing.Color.Black;
            this.lbl_qrcode.Location = new System.Drawing.Point(70, 360);
            this.lbl_qrcode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_qrcode.Name = "lbl_qrcode";
            this.lbl_qrcode.Size = new System.Drawing.Size(102, 24);
            this.lbl_qrcode.TabIndex = 120;
            this.lbl_qrcode.Text = "QR Code:";
            // 
            // pnl_PB
            // 
            this.pnl_PB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_PB.Controls.Add(this.pnl_PBbottom);
            this.pnl_PB.Controls.Add(this.pnl_PBtop);
            this.pnl_PB.Controls.Add(this.pnl_PBleft);
            this.pnl_PB.Controls.Add(this.pnl_PBright);
            this.pnl_PB.Controls.Add(this.pb_student);
            this.pnl_PB.Location = new System.Drawing.Point(909, 94);
            this.pnl_PB.Name = "pnl_PB";
            this.pnl_PB.Size = new System.Drawing.Size(205, 250);
            this.pnl_PB.TabIndex = 121;
            // 
            // pnl_PBbottom
            // 
            this.pnl_PBbottom.BackColor = System.Drawing.Color.White;
            this.pnl_PBbottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_PBbottom.Location = new System.Drawing.Point(10, 240);
            this.pnl_PBbottom.Name = "pnl_PBbottom";
            this.pnl_PBbottom.Size = new System.Drawing.Size(185, 10);
            this.pnl_PBbottom.TabIndex = 3;
            // 
            // pnl_PBtop
            // 
            this.pnl_PBtop.BackColor = System.Drawing.Color.White;
            this.pnl_PBtop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_PBtop.Location = new System.Drawing.Point(10, 0);
            this.pnl_PBtop.Name = "pnl_PBtop";
            this.pnl_PBtop.Size = new System.Drawing.Size(185, 10);
            this.pnl_PBtop.TabIndex = 2;
            // 
            // pnl_PBleft
            // 
            this.pnl_PBleft.BackColor = System.Drawing.Color.White;
            this.pnl_PBleft.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_PBleft.Location = new System.Drawing.Point(195, 0);
            this.pnl_PBleft.Name = "pnl_PBleft";
            this.pnl_PBleft.Size = new System.Drawing.Size(10, 250);
            this.pnl_PBleft.TabIndex = 1;
            // 
            // pnl_PBright
            // 
            this.pnl_PBright.BackColor = System.Drawing.Color.White;
            this.pnl_PBright.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_PBright.Location = new System.Drawing.Point(0, 0);
            this.pnl_PBright.Name = "pnl_PBright";
            this.pnl_PBright.Size = new System.Drawing.Size(10, 250);
            this.pnl_PBright.TabIndex = 0;
            // 
            // pb_student
            // 
            this.pb_student.Image = global::Library.Properties.Resources.No;
            this.pb_student.Location = new System.Drawing.Point(10, 8);
            this.pb_student.Name = "pb_student";
            this.pb_student.Size = new System.Drawing.Size(190, 232);
            this.pb_student.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_student.TabIndex = 95;
            this.pb_student.TabStop = false;
            // 
            // btn_cam
            // 
            this.btn_cam.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_cam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.btn_cam.FlatAppearance.BorderSize = 0;
            this.btn_cam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cam.ForeColor = System.Drawing.Color.White;
            this.btn_cam.Location = new System.Drawing.Point(1026, 350);
            this.btn_cam.Name = "btn_cam";
            this.btn_cam.Size = new System.Drawing.Size(72, 32);
            this.btn_cam.TabIndex = 11;
            this.btn_cam.Text = "Cam";
            this.btn_cam.UseVisualStyleBackColor = false;
            this.btn_cam.Click += new System.EventHandler(this.btn_cam_Click);
            // 
            // UC_Student
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.btn_cam);
            this.Controls.Add(this.pnl_PB);
            this.Controls.Add(this.lbl_qrcode);
            this.Controls.Add(this.cb_role);
            this.Controls.Add(this.lbl_qr);
            this.Controls.Add(this.lbl_Role);
            this.Controls.Add(this.pb_qrcode);
            this.Controls.Add(this.pnl_dgv);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.lbl_dept);
            this.Controls.Add(this.lbl_address);
            this.Controls.Add(this.cb_dept);
            this.Controls.Add(this.cb_course);
            this.Controls.Add(this.rtxt_address);
            this.Controls.Add(this.txt_UserID);
            this.Controls.Add(this.lbl_uid);
            this.Controls.Add(this.lbl_saveinfo);
            this.Controls.Add(this.cb_age);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_browse);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_view);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_mobile);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.lbl_course);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_age);
            this.Controls.Add(this.lbl_mobile);
            this.Controls.Add(this.lbl_head);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.btn_qrcode);
            this.Controls.Add(this.txt_qrcode);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UC_Student";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_Student_Load);
            this.pnl_dgv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_qrcode)).EndInit();
            this.pnl_PB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_mobile;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label lbl_course;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_age;
        private System.Windows.Forms.Label lbl_mobile;
        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_view;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.ComboBox cb_age;
        private System.Windows.Forms.Label lbl_saveinfo;
        private System.Windows.Forms.TextBox txt_UserID;
        private System.Windows.Forms.Label lbl_uid;
        private System.Windows.Forms.RichTextBox rtxt_address;
        private System.Windows.Forms.ComboBox cb_course;
        private System.Windows.Forms.ComboBox cb_dept;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label lbl_dept;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.Panel pnl_dgv;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.PictureBox pb_qrcode;
        private System.Windows.Forms.Label lbl_Role;
        private System.Windows.Forms.Button btn_qrcode;
        private System.Windows.Forms.Label lbl_qr;
        private System.Windows.Forms.ComboBox cb_role;
        private System.Windows.Forms.TextBox txt_qrcode;
        private System.Windows.Forms.Label lbl_qrcode;
        private System.Windows.Forms.Panel pnl_PB;
        private System.Windows.Forms.Panel pnl_PBbottom;
        private System.Windows.Forms.Panel pnl_PBtop;
        private System.Windows.Forms.Panel pnl_PBleft;
        private System.Windows.Forms.Panel pnl_PBright;
        private System.Windows.Forms.PictureBox pb_student;
        private System.Windows.Forms.Button btn_cam;
    }
}
