﻿namespace Library
{
    partial class Main_Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            BunifuAnimatorNS.Animation animation4 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation2 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation1 = new BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Dashboard));
            BunifuAnimatorNS.Animation animation3 = new BunifuAnimatorNS.Animation();
            this.tm_Time = new System.Windows.Forms.Timer(this.components);
            this.lbl_usertype = new System.Windows.Forms.Label();
            this.lbl_role = new System.Windows.Forms.Label();
            this.lbl_time = new System.Windows.Forms.Label();
            this.lbl_user = new System.Windows.Forms.Label();
            this.lbl_welcome = new System.Windows.Forms.Label();
            this.pnl_admin = new System.Windows.Forms.Panel();
            this.pnl_outTime = new System.Windows.Forms.Panel();
            this.pnl_inTime = new System.Windows.Forms.Panel();
            this.lbl_day = new System.Windows.Forms.Label();
            this.lbl_headAsh = new System.Windows.Forms.Label();
            this.pnl_title = new System.Windows.Forms.Panel();
            this.btn_min = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.lbl_ash = new System.Windows.Forms.Label();
            this.lbl_soft = new System.Windows.Forms.Label();
            this.pnl_slide = new System.Windows.Forms.Panel();
            this.pnl_Left = new System.Windows.Forms.Panel();
            this.btn_mail = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.btn_BookReturn = new System.Windows.Forms.Button();
            this.btn_StudentDetails = new System.Windows.Forms.Button();
            this.btn_BookIssue = new System.Windows.Forms.Button();
            this.btn_reports = new System.Windows.Forms.Button();
            this.btn_BookDetails = new System.Windows.Forms.Button();
            this.pnl_Lefttop = new System.Windows.Forms.Panel();
            this.btn_slide = new System.Windows.Forms.Button();
            this.pb_logo = new System.Windows.Forms.PictureBox();
            this.pnl_main = new System.Windows.Forms.Panel();
            this.Bunifu_Slide = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.Bunifu_Logo = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.Bunifu_Sname = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.bunifu_Ash = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.pnl_admin.SuspendLayout();
            this.pnl_outTime.SuspendLayout();
            this.pnl_inTime.SuspendLayout();
            this.pnl_title.SuspendLayout();
            this.pnl_Left.SuspendLayout();
            this.pnl_Lefttop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // tm_Time
            // 
            this.tm_Time.Tick += new System.EventHandler(this.tm_Time_Tick);
            // 
            // lbl_usertype
            // 
            this.lbl_usertype.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_usertype, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_usertype, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_usertype, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_usertype, BunifuAnimatorNS.DecorationType.None);
            this.lbl_usertype.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_usertype.ForeColor = System.Drawing.Color.White;
            this.lbl_usertype.Location = new System.Drawing.Point(170, 56);
            this.lbl_usertype.Name = "lbl_usertype";
            this.lbl_usertype.Size = new System.Drawing.Size(88, 37);
            this.lbl_usertype.TabIndex = 0;
            this.lbl_usertype.Text = "Admin";
            // 
            // lbl_role
            // 
            this.lbl_role.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_role, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_role, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_role, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_role, BunifuAnimatorNS.DecorationType.None);
            this.lbl_role.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_role.ForeColor = System.Drawing.Color.White;
            this.lbl_role.Location = new System.Drawing.Point(105, 63);
            this.lbl_role.Name = "lbl_role";
            this.lbl_role.Size = new System.Drawing.Size(67, 25);
            this.lbl_role.TabIndex = 0;
            this.lbl_role.Text = "Role:";
            // 
            // lbl_time
            // 
            this.lbl_time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_time.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_time, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_time, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_time, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_time, BunifuAnimatorNS.DecorationType.None);
            this.lbl_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_time.ForeColor = System.Drawing.Color.Red;
            this.lbl_time.Location = new System.Drawing.Point(61, 30);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(144, 24);
            this.lbl_time.TabIndex = 0;
            this.lbl_time.Text = "HH:MM:SS TT";
            // 
            // lbl_user
            // 
            this.lbl_user.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_user, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_user, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_user, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_user, BunifuAnimatorNS.DecorationType.None);
            this.lbl_user.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_user.ForeColor = System.Drawing.Color.White;
            this.lbl_user.Location = new System.Drawing.Point(170, 24);
            this.lbl_user.Name = "lbl_user";
            this.lbl_user.Size = new System.Drawing.Size(170, 37);
            this.lbl_user.TabIndex = 0;
            this.lbl_user.Text = "AsHfaQ NaInA";
            // 
            // lbl_welcome
            // 
            this.lbl_welcome.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_welcome, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_welcome, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_welcome, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_welcome, BunifuAnimatorNS.DecorationType.None);
            this.lbl_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_welcome.ForeColor = System.Drawing.Color.White;
            this.lbl_welcome.Location = new System.Drawing.Point(60, 28);
            this.lbl_welcome.Name = "lbl_welcome";
            this.lbl_welcome.Size = new System.Drawing.Size(115, 25);
            this.lbl_welcome.TabIndex = 0;
            this.lbl_welcome.Text = "Welcome:";
            // 
            // pnl_admin
            // 
            this.pnl_admin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.pnl_admin.Controls.Add(this.pnl_outTime);
            this.pnl_admin.Controls.Add(this.lbl_usertype);
            this.pnl_admin.Controls.Add(this.lbl_role);
            this.pnl_admin.Controls.Add(this.lbl_user);
            this.pnl_admin.Controls.Add(this.lbl_welcome);
            this.bunifu_Ash.SetDecoration(this.pnl_admin, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_admin, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_admin, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_admin, BunifuAnimatorNS.DecorationType.None);
            this.pnl_admin.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_admin.Location = new System.Drawing.Point(282, 42);
            this.pnl_admin.Name = "pnl_admin";
            this.pnl_admin.Size = new System.Drawing.Size(1200, 116);
            this.pnl_admin.TabIndex = 5;
            // 
            // pnl_outTime
            // 
            this.pnl_outTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_outTime.BackColor = System.Drawing.Color.Gray;
            this.pnl_outTime.Controls.Add(this.pnl_inTime);
            this.bunifu_Ash.SetDecoration(this.pnl_outTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_outTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_outTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_outTime, BunifuAnimatorNS.DecorationType.None);
            this.pnl_outTime.Location = new System.Drawing.Point(899, 13);
            this.pnl_outTime.Name = "pnl_outTime";
            this.pnl_outTime.Size = new System.Drawing.Size(289, 90);
            this.pnl_outTime.TabIndex = 2;
            // 
            // pnl_inTime
            // 
            this.pnl_inTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_inTime.BackColor = System.Drawing.Color.Black;
            this.pnl_inTime.Controls.Add(this.lbl_day);
            this.pnl_inTime.Controls.Add(this.lbl_time);
            this.bunifu_Ash.SetDecoration(this.pnl_inTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_inTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_inTime, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_inTime, BunifuAnimatorNS.DecorationType.None);
            this.pnl_inTime.Location = new System.Drawing.Point(17, 13);
            this.pnl_inTime.Name = "pnl_inTime";
            this.pnl_inTime.Size = new System.Drawing.Size(257, 64);
            this.pnl_inTime.TabIndex = 0;
            // 
            // lbl_day
            // 
            this.lbl_day.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_day.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_day, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_day, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_day, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_day, BunifuAnimatorNS.DecorationType.None);
            this.lbl_day.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_day.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_day.Location = new System.Drawing.Point(9, 6);
            this.lbl_day.Name = "lbl_day";
            this.lbl_day.Size = new System.Drawing.Size(212, 24);
            this.lbl_day.TabIndex = 1;
            this.lbl_day.Text = "DDDDD DD/MM/YYYY";
            // 
            // lbl_headAsh
            // 
            this.lbl_headAsh.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_headAsh, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_headAsh, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_headAsh, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_headAsh, BunifuAnimatorNS.DecorationType.None);
            this.lbl_headAsh.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_headAsh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_headAsh.Location = new System.Drawing.Point(6, 11);
            this.lbl_headAsh.Name = "lbl_headAsh";
            this.lbl_headAsh.Size = new System.Drawing.Size(338, 25);
            this.lbl_headAsh.TabIndex = 0;
            this.lbl_headAsh.Text = "Ash Developers Pvt.Ltd, Trichy";
            // 
            // pnl_title
            // 
            this.pnl_title.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_title.Controls.Add(this.btn_min);
            this.pnl_title.Controls.Add(this.lbl_headAsh);
            this.pnl_title.Controls.Add(this.btn_exit);
            this.bunifu_Ash.SetDecoration(this.pnl_title, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_title, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_title, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_title, BunifuAnimatorNS.DecorationType.None);
            this.pnl_title.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_title.Location = new System.Drawing.Point(282, 0);
            this.pnl_title.Name = "pnl_title";
            this.pnl_title.Size = new System.Drawing.Size(1200, 42);
            this.pnl_title.TabIndex = 3;
            // 
            // btn_min
            // 
            this.btn_min.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_min.BackColor = System.Drawing.Color.Gray;
            this.Bunifu_Sname.SetDecoration(this.btn_min, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_min, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_min, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_min, BunifuAnimatorNS.DecorationType.None);
            this.btn_min.FlatAppearance.BorderSize = 0;
            this.btn_min.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_min.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.btn_min.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_min.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_min.ForeColor = System.Drawing.Color.White;
            this.btn_min.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_min.Location = new System.Drawing.Point(1119, 1);
            this.btn_min.Name = "btn_min";
            this.btn_min.Size = new System.Drawing.Size(40, 40);
            this.btn_min.TabIndex = 4;
            this.btn_min.Text = "_";
            this.btn_min.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_min.UseVisualStyleBackColor = false;
            this.btn_min.Click += new System.EventHandler(this.btn_min_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_exit.BackColor = System.Drawing.Color.Red;
            this.Bunifu_Sname.SetDecoration(this.btn_exit, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_exit, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_exit, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_exit, BunifuAnimatorNS.DecorationType.None);
            this.btn_exit.FlatAppearance.BorderSize = 0;
            this.btn_exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.White;
            this.btn_exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_exit.Location = new System.Drawing.Point(1159, 1);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(40, 40);
            this.btn_exit.TabIndex = 2;
            this.btn_exit.Text = "X";
            this.btn_exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // lbl_ash
            // 
            this.lbl_ash.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_ash, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_ash, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_ash, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_ash, BunifuAnimatorNS.DecorationType.None);
            this.lbl_ash.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ash.ForeColor = System.Drawing.Color.White;
            this.lbl_ash.Location = new System.Drawing.Point(78, 121);
            this.lbl_ash.Name = "lbl_ash";
            this.lbl_ash.Size = new System.Drawing.Size(126, 18);
            this.lbl_ash.TabIndex = 0;
            this.lbl_ash.Text = "Ash Developers";
            // 
            // lbl_soft
            // 
            this.lbl_soft.AutoSize = true;
            this.Bunifu_Sname.SetDecoration(this.lbl_soft, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.lbl_soft, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.lbl_soft, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.lbl_soft, BunifuAnimatorNS.DecorationType.None);
            this.lbl_soft.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_soft.ForeColor = System.Drawing.Color.White;
            this.lbl_soft.Location = new System.Drawing.Point(84, 92);
            this.lbl_soft.Name = "lbl_soft";
            this.lbl_soft.Size = new System.Drawing.Size(114, 24);
            this.lbl_soft.TabIndex = 0;
            this.lbl_soft.Text = "Library Soft";
            // 
            // pnl_slide
            // 
            this.pnl_slide.BackColor = System.Drawing.Color.White;
            this.bunifu_Ash.SetDecoration(this.pnl_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_slide, BunifuAnimatorNS.DecorationType.None);
            this.pnl_slide.Location = new System.Drawing.Point(1, 160);
            this.pnl_slide.Name = "pnl_slide";
            this.pnl_slide.Size = new System.Drawing.Size(8, 68);
            this.pnl_slide.TabIndex = 1;
            // 
            // pnl_Left
            // 
            this.pnl_Left.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_Left.Controls.Add(this.btn_mail);
            this.pnl_Left.Controls.Add(this.btn_home);
            this.pnl_Left.Controls.Add(this.btn_BookReturn);
            this.pnl_Left.Controls.Add(this.pnl_slide);
            this.pnl_Left.Controls.Add(this.btn_StudentDetails);
            this.pnl_Left.Controls.Add(this.btn_BookIssue);
            this.pnl_Left.Controls.Add(this.btn_reports);
            this.pnl_Left.Controls.Add(this.btn_BookDetails);
            this.pnl_Left.Controls.Add(this.pnl_Lefttop);
            this.bunifu_Ash.SetDecoration(this.pnl_Left, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_Left, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_Left, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_Left, BunifuAnimatorNS.DecorationType.None);
            this.pnl_Left.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_Left.Location = new System.Drawing.Point(0, 0);
            this.pnl_Left.Name = "pnl_Left";
            this.pnl_Left.Size = new System.Drawing.Size(282, 858);
            this.pnl_Left.TabIndex = 4;
            // 
            // btn_mail
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_mail, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_mail, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_mail, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_mail, BunifuAnimatorNS.DecorationType.None);
            this.btn_mail.FlatAppearance.BorderSize = 0;
            this.btn_mail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mail.ForeColor = System.Drawing.Color.White;
            this.btn_mail.Image = global::Library.Properties.Resources.gmail;
            this.btn_mail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_mail.Location = new System.Drawing.Point(9, 596);
            this.btn_mail.Name = "btn_mail";
            this.btn_mail.Size = new System.Drawing.Size(273, 68);
            this.btn_mail.TabIndex = 4;
            this.btn_mail.Text = "     Mail Service";
            this.btn_mail.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_mail.UseVisualStyleBackColor = true;
            this.btn_mail.Click += new System.EventHandler(this.btn_mail_Click);
            // 
            // btn_home
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_home, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_home, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_home, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_home, BunifuAnimatorNS.DecorationType.None);
            this.btn_home.FlatAppearance.BorderSize = 0;
            this.btn_home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_home.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_home.ForeColor = System.Drawing.Color.White;
            this.btn_home.Image = global::Library.Properties.Resources.Home;
            this.btn_home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_home.Location = new System.Drawing.Point(9, 160);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(273, 68);
            this.btn_home.TabIndex = 3;
            this.btn_home.Text = "     Home";
            this.btn_home.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_home.UseVisualStyleBackColor = true;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // btn_BookReturn
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_BookReturn, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_BookReturn, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_BookReturn, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_BookReturn, BunifuAnimatorNS.DecorationType.None);
            this.btn_BookReturn.FlatAppearance.BorderSize = 0;
            this.btn_BookReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_BookReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BookReturn.ForeColor = System.Drawing.Color.White;
            this.btn_BookReturn.Image = global::Library.Properties.Resources.Return_book;
            this.btn_BookReturn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_BookReturn.Location = new System.Drawing.Point(9, 522);
            this.btn_BookReturn.Name = "btn_BookReturn";
            this.btn_BookReturn.Size = new System.Drawing.Size(273, 68);
            this.btn_BookReturn.TabIndex = 2;
            this.btn_BookReturn.Text = "     Book Return";
            this.btn_BookReturn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_BookReturn.UseVisualStyleBackColor = true;
            this.btn_BookReturn.Click += new System.EventHandler(this.btn_BookReturn_Click);
            // 
            // btn_StudentDetails
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_StudentDetails, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_StudentDetails, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_StudentDetails, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_StudentDetails, BunifuAnimatorNS.DecorationType.None);
            this.btn_StudentDetails.FlatAppearance.BorderSize = 0;
            this.btn_StudentDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_StudentDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_StudentDetails.ForeColor = System.Drawing.Color.White;
            this.btn_StudentDetails.Image = global::Library.Properties.Resources.Students;
            this.btn_StudentDetails.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_StudentDetails.Location = new System.Drawing.Point(9, 229);
            this.btn_StudentDetails.Name = "btn_StudentDetails";
            this.btn_StudentDetails.Size = new System.Drawing.Size(273, 68);
            this.btn_StudentDetails.TabIndex = 2;
            this.btn_StudentDetails.Text = "     Student Details";
            this.btn_StudentDetails.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_StudentDetails.UseVisualStyleBackColor = true;
            this.btn_StudentDetails.Click += new System.EventHandler(this.btn_StudentDetails_Click);
            // 
            // btn_BookIssue
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_BookIssue, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_BookIssue, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_BookIssue, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_BookIssue, BunifuAnimatorNS.DecorationType.None);
            this.btn_BookIssue.FlatAppearance.BorderSize = 0;
            this.btn_BookIssue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_BookIssue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BookIssue.ForeColor = System.Drawing.Color.White;
            this.btn_BookIssue.Image = global::Library.Properties.Resources.Book_withdraw;
            this.btn_BookIssue.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_BookIssue.Location = new System.Drawing.Point(9, 448);
            this.btn_BookIssue.Name = "btn_BookIssue";
            this.btn_BookIssue.Size = new System.Drawing.Size(273, 68);
            this.btn_BookIssue.TabIndex = 2;
            this.btn_BookIssue.Text = "     Book Withdraw";
            this.btn_BookIssue.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_BookIssue.UseVisualStyleBackColor = true;
            this.btn_BookIssue.Click += new System.EventHandler(this.btn_BookIssue_Click);
            // 
            // btn_reports
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_reports, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_reports, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_reports, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_reports, BunifuAnimatorNS.DecorationType.None);
            this.btn_reports.FlatAppearance.BorderSize = 0;
            this.btn_reports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_reports.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reports.ForeColor = System.Drawing.Color.White;
            this.btn_reports.Image = global::Library.Properties.Resources.Magazine;
            this.btn_reports.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_reports.Location = new System.Drawing.Point(9, 377);
            this.btn_reports.Name = "btn_reports";
            this.btn_reports.Size = new System.Drawing.Size(273, 68);
            this.btn_reports.TabIndex = 2;
            this.btn_reports.Text = "     Reports";
            this.btn_reports.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_reports.UseVisualStyleBackColor = true;
            this.btn_reports.Click += new System.EventHandler(this.btn_reports_Click);
            // 
            // btn_BookDetails
            // 
            this.Bunifu_Sname.SetDecoration(this.btn_BookDetails, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_BookDetails, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_BookDetails, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_BookDetails, BunifuAnimatorNS.DecorationType.None);
            this.btn_BookDetails.FlatAppearance.BorderSize = 0;
            this.btn_BookDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_BookDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BookDetails.ForeColor = System.Drawing.Color.White;
            this.btn_BookDetails.Image = global::Library.Properties.Resources.Open_book;
            this.btn_BookDetails.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_BookDetails.Location = new System.Drawing.Point(9, 303);
            this.btn_BookDetails.Name = "btn_BookDetails";
            this.btn_BookDetails.Size = new System.Drawing.Size(273, 68);
            this.btn_BookDetails.TabIndex = 2;
            this.btn_BookDetails.Text = "     Book Details";
            this.btn_BookDetails.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_BookDetails.UseVisualStyleBackColor = true;
            this.btn_BookDetails.Click += new System.EventHandler(this.btn_BookDetails_Click);
            // 
            // pnl_Lefttop
            // 
            this.pnl_Lefttop.Controls.Add(this.lbl_ash);
            this.pnl_Lefttop.Controls.Add(this.btn_slide);
            this.pnl_Lefttop.Controls.Add(this.lbl_soft);
            this.pnl_Lefttop.Controls.Add(this.pb_logo);
            this.bunifu_Ash.SetDecoration(this.pnl_Lefttop, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_Lefttop, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_Lefttop, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_Lefttop, BunifuAnimatorNS.DecorationType.None);
            this.pnl_Lefttop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Lefttop.Location = new System.Drawing.Point(0, 0);
            this.pnl_Lefttop.Name = "pnl_Lefttop";
            this.pnl_Lefttop.Size = new System.Drawing.Size(282, 158);
            this.pnl_Lefttop.TabIndex = 0;
            // 
            // btn_slide
            // 
            this.btn_slide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Bunifu_Sname.SetDecoration(this.btn_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.btn_slide, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.btn_slide, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.btn_slide, BunifuAnimatorNS.DecorationType.None);
            this.btn_slide.FlatAppearance.BorderSize = 0;
            this.btn_slide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_slide.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_slide.ForeColor = System.Drawing.Color.White;
            this.btn_slide.Image = ((System.Drawing.Image)(resources.GetObject("btn_slide.Image")));
            this.btn_slide.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_slide.Location = new System.Drawing.Point(235, 9);
            this.btn_slide.Name = "btn_slide";
            this.btn_slide.Size = new System.Drawing.Size(41, 33);
            this.btn_slide.TabIndex = 2;
            this.btn_slide.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_slide.UseVisualStyleBackColor = true;
            this.btn_slide.Click += new System.EventHandler(this.btn_slide_Click);
            // 
            // pb_logo
            // 
            this.Bunifu_Sname.SetDecoration(this.pb_logo, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this.pb_logo, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pb_logo, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pb_logo, BunifuAnimatorNS.DecorationType.None);
            this.pb_logo.Image = global::Library.Properties.Resources.Ash;
            this.pb_logo.Location = new System.Drawing.Point(107, 20);
            this.pb_logo.Name = "pb_logo";
            this.pb_logo.Size = new System.Drawing.Size(70, 70);
            this.pb_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_logo.TabIndex = 2;
            this.pb_logo.TabStop = false;
            // 
            // pnl_main
            // 
            this.bunifu_Ash.SetDecoration(this.pnl_main, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this.pnl_main, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this.pnl_main, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Sname.SetDecoration(this.pnl_main, BunifuAnimatorNS.DecorationType.None);
            this.pnl_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_main.Location = new System.Drawing.Point(282, 158);
            this.pnl_main.Name = "pnl_main";
            this.pnl_main.Size = new System.Drawing.Size(1200, 700);
            this.pnl_main.TabIndex = 6;
            // 
            // Bunifu_Slide
            // 
            this.Bunifu_Slide.AnimationType = BunifuAnimatorNS.AnimationType.Scale;
            this.Bunifu_Slide.Cursor = null;
            animation4.AnimateOnlyDifferences = true;
            animation4.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.BlindCoeff")));
            animation4.LeafCoeff = 0F;
            animation4.MaxTime = 1F;
            animation4.MinTime = 0F;
            animation4.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.MosaicCoeff")));
            animation4.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation4.MosaicShift")));
            animation4.MosaicSize = 0;
            animation4.Padding = new System.Windows.Forms.Padding(0);
            animation4.RotateCoeff = 0F;
            animation4.RotateLimit = 0F;
            animation4.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.ScaleCoeff")));
            animation4.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.SlideCoeff")));
            animation4.TimeCoeff = 0F;
            animation4.TransparencyCoeff = 0F;
            this.Bunifu_Slide.DefaultAnimation = animation4;
            // 
            // Bunifu_Logo
            // 
            this.Bunifu_Logo.AnimationType = BunifuAnimatorNS.AnimationType.ScaleAndRotate;
            this.Bunifu_Logo.Cursor = null;
            animation2.AnimateOnlyDifferences = true;
            animation2.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.BlindCoeff")));
            animation2.LeafCoeff = 0F;
            animation2.MaxTime = 1F;
            animation2.MinTime = 0F;
            animation2.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicCoeff")));
            animation2.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicShift")));
            animation2.MosaicSize = 0;
            animation2.Padding = new System.Windows.Forms.Padding(30);
            animation2.RotateCoeff = 0.5F;
            animation2.RotateLimit = 0.2F;
            animation2.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.ScaleCoeff")));
            animation2.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.SlideCoeff")));
            animation2.TimeCoeff = 0F;
            animation2.TransparencyCoeff = 0F;
            this.Bunifu_Logo.DefaultAnimation = animation2;
            // 
            // Bunifu_Sname
            // 
            this.Bunifu_Sname.AnimationType = BunifuAnimatorNS.AnimationType.ScaleAndRotate;
            this.Bunifu_Sname.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(30);
            animation1.RotateCoeff = 0.5F;
            animation1.RotateLimit = 0.2F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.Bunifu_Sname.DefaultAnimation = animation1;
            // 
            // bunifu_Ash
            // 
            this.bunifu_Ash.AnimationType = BunifuAnimatorNS.AnimationType.Leaf;
            this.bunifu_Ash.Cursor = null;
            animation3.AnimateOnlyDifferences = true;
            animation3.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.BlindCoeff")));
            animation3.LeafCoeff = 1F;
            animation3.MaxTime = 1F;
            animation3.MinTime = 0F;
            animation3.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicCoeff")));
            animation3.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicShift")));
            animation3.MosaicSize = 0;
            animation3.Padding = new System.Windows.Forms.Padding(0);
            animation3.RotateCoeff = 0F;
            animation3.RotateLimit = 0F;
            animation3.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.ScaleCoeff")));
            animation3.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.SlideCoeff")));
            animation3.TimeCoeff = 0F;
            animation3.TransparencyCoeff = 0F;
            this.bunifu_Ash.DefaultAnimation = animation3;
            // 
            // Main_Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1482, 858);
            this.Controls.Add(this.pnl_main);
            this.Controls.Add(this.pnl_admin);
            this.Controls.Add(this.pnl_title);
            this.Controls.Add(this.pnl_Left);
            this.Bunifu_Sname.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.bunifu_Ash.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Slide.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.Bunifu_Logo.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(1150, 610);
            this.Name = "Main_Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main_Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Main_Dashboard_Load);
            this.pnl_admin.ResumeLayout(false);
            this.pnl_admin.PerformLayout();
            this.pnl_outTime.ResumeLayout(false);
            this.pnl_inTime.ResumeLayout(false);
            this.pnl_inTime.PerformLayout();
            this.pnl_title.ResumeLayout(false);
            this.pnl_title.PerformLayout();
            this.pnl_Left.ResumeLayout(false);
            this.pnl_Lefttop.ResumeLayout(false);
            this.pnl_Lefttop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer tm_Time;
        private System.Windows.Forms.Label lbl_usertype;
        private System.Windows.Forms.Label lbl_role;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.Label lbl_user;
        private System.Windows.Forms.Label lbl_welcome;
        private System.Windows.Forms.Panel pnl_admin;
        private System.Windows.Forms.Label lbl_headAsh;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Panel pnl_title;
        private System.Windows.Forms.Label lbl_ash;
        private System.Windows.Forms.Button btn_slide;
        private System.Windows.Forms.Label lbl_soft;
        private System.Windows.Forms.PictureBox pb_logo;
        private System.Windows.Forms.Panel pnl_slide;
        private System.Windows.Forms.Button btn_StudentDetails;
        private System.Windows.Forms.Button btn_BookIssue;
        private System.Windows.Forms.Button btn_reports;
        private System.Windows.Forms.Button btn_BookDetails;
        private System.Windows.Forms.Button btn_BookReturn;
        private System.Windows.Forms.Panel pnl_Left;
        private System.Windows.Forms.Panel pnl_Lefttop;
        private System.Windows.Forms.Panel pnl_main;
        private System.Windows.Forms.Label lbl_day;
        private System.Windows.Forms.Panel pnl_outTime;
        private System.Windows.Forms.Panel pnl_inTime;
        private System.Windows.Forms.Button btn_home;
        private BunifuAnimatorNS.BunifuTransition Bunifu_Slide;
        private BunifuAnimatorNS.BunifuTransition Bunifu_Logo;
        private BunifuAnimatorNS.BunifuTransition Bunifu_Sname;
        private BunifuAnimatorNS.BunifuTransition bunifu_Ash;
        private System.Windows.Forms.Button btn_mail;
        private System.Windows.Forms.Button btn_min;
    }
}