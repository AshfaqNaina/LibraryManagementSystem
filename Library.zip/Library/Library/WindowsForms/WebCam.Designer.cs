﻿namespace Library.WindowsForms
{
    partial class WebCam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pb_webcam = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_selectCam = new System.Windows.Forms.ComboBox();
            this.btn_click = new System.Windows.Forms.Button();
            this.pb_webCamCap = new System.Windows.Forms.PictureBox();
            this.btn_decline = new System.Windows.Forms.Button();
            this.btn_accept = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pb_webcam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_webCamCap)).BeginInit();
            this.SuspendLayout();
            // 
            // pb_webcam
            // 
            this.pb_webcam.Location = new System.Drawing.Point(75, 76);
            this.pb_webcam.Margin = new System.Windows.Forms.Padding(6);
            this.pb_webcam.Name = "pb_webcam";
            this.pb_webcam.Size = new System.Drawing.Size(300, 300);
            this.pb_webcam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_webcam.TabIndex = 0;
            this.pb_webcam.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Camera:";
            // 
            // cb_selectCam
            // 
            this.cb_selectCam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_selectCam.FormattingEnabled = true;
            this.cb_selectCam.Location = new System.Drawing.Point(88, 6);
            this.cb_selectCam.Margin = new System.Windows.Forms.Padding(6);
            this.cb_selectCam.Name = "cb_selectCam";
            this.cb_selectCam.Size = new System.Drawing.Size(316, 28);
            this.cb_selectCam.TabIndex = 2;
            // 
            // btn_click
            // 
            this.btn_click.BackColor = System.Drawing.Color.Indigo;
            this.btn_click.FlatAppearance.BorderSize = 0;
            this.btn_click.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_click.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_click.Location = new System.Drawing.Point(184, 385);
            this.btn_click.Name = "btn_click";
            this.btn_click.Size = new System.Drawing.Size(87, 35);
            this.btn_click.TabIndex = 3;
            this.btn_click.Text = "Capture";
            this.btn_click.UseVisualStyleBackColor = false;
            this.btn_click.Click += new System.EventHandler(this.btn_click_Click);
            // 
            // pb_webCamCap
            // 
            this.pb_webCamCap.Location = new System.Drawing.Point(75, 76);
            this.pb_webCamCap.Margin = new System.Windows.Forms.Padding(6);
            this.pb_webCamCap.Name = "pb_webCamCap";
            this.pb_webCamCap.Size = new System.Drawing.Size(300, 300);
            this.pb_webCamCap.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_webCamCap.TabIndex = 4;
            this.pb_webCamCap.TabStop = false;
            // 
            // btn_decline
            // 
            this.btn_decline.BackColor = System.Drawing.Color.Tomato;
            this.btn_decline.FlatAppearance.BorderSize = 0;
            this.btn_decline.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_decline.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_decline.Location = new System.Drawing.Point(75, 385);
            this.btn_decline.Name = "btn_decline";
            this.btn_decline.Size = new System.Drawing.Size(87, 35);
            this.btn_decline.TabIndex = 5;
            this.btn_decline.Text = "Decline";
            this.btn_decline.UseVisualStyleBackColor = false;
            this.btn_decline.Click += new System.EventHandler(this.btn_decline_Click);
            // 
            // btn_accept
            // 
            this.btn_accept.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_accept.FlatAppearance.BorderSize = 0;
            this.btn_accept.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_accept.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_accept.Location = new System.Drawing.Point(288, 385);
            this.btn_accept.Name = "btn_accept";
            this.btn_accept.Size = new System.Drawing.Size(87, 35);
            this.btn_accept.TabIndex = 7;
            this.btn_accept.Text = "Accept";
            this.btn_accept.UseVisualStyleBackColor = false;
            this.btn_accept.Click += new System.EventHandler(this.btn_accept_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Tomato;
            this.btn_close.FlatAppearance.BorderSize = 0;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_close.Location = new System.Drawing.Point(413, 3);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(34, 35);
            this.btn_close.TabIndex = 8;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel1.Location = new System.Drawing.Point(0, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(450, 10);
            this.panel1.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(3, 450);
            this.panel2.TabIndex = 10;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(447, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 450);
            this.panel3.TabIndex = 11;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(3, 447);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(444, 3);
            this.panel4.TabIndex = 12;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(3, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(444, 3);
            this.panel5.TabIndex = 13;
            // 
            // WebCam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 450);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.btn_accept);
            this.Controls.Add(this.btn_decline);
            this.Controls.Add(this.btn_click);
            this.Controls.Add(this.cb_selectCam);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pb_webcam);
            this.Controls.Add(this.pb_webCamCap);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "WebCam";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WebCam";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.WebCam_FormClosing);
            this.Load += new System.EventHandler(this.WebCam_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_webcam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_webCamCap)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_webcam;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_selectCam;
        private System.Windows.Forms.Button btn_click;
        private System.Windows.Forms.PictureBox pb_webCamCap;
        private System.Windows.Forms.Button btn_decline;
        private System.Windows.Forms.Button btn_accept;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
    }
}