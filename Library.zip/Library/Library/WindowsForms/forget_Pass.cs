﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;

namespace Library.WindowsForms
{
    public partial class forget_Pass : Form
    {
        public forget_Pass()
        {
            InitializeComponent();
        }

        string randomCode;
        public static string to;

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void btn_sendOTP_Click(object sender, EventArgs e)
        {
            string from, pass, messageBody;
            Random rand = new Random();
            randomCode = (rand.Next(999999)).ToString();
            MailMessage message = new MailMessage();
            to = (txt_email.Text).ToString();
            from = "libraryalertnotification@gmail.com";
            pass = "#Developers";
            messageBody = "*Your Reset code is:" + randomCode;
            message.To.Add(to);
            message.From = new MailAddress(from);
            message.Body = messageBody;
            message.Subject = "Library User's Password Reset";
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.EnableSsl = true;
            smtp.Port = 587;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Credentials = new NetworkCredential(from, pass);
            try
            {
                smtp.Send(message);
                lbl_info.ForeColor = Color.SeaGreen;
                lbl_info.Text = "OTP send successfully";
            }
            catch(Exception x)
            {
                MessageBox.Show("Network problem" + x.Message,"Library Soft");
            }
        }

        private void btn_verifyOTP_Click(object sender, EventArgs e)
        {
            if(randomCode == (txt_verifyOTP.Text).ToString())
            {
                to = txt_email.Text;
                lbl_info.ForeColor = Color.SeaGreen;
                lbl_info.Text = "OTP verified successfully";
                btn_next.Visible = true;
            }
            else
            {
                lbl_info.ForeColor = Color.Red;
                lbl_info.Text="Invalid OTP";
                btn_next.Visible = false;
                pnl_forgetpass.Show();
                pnl_resetpass.Hide();
            }
        }

       

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_email.Clear();
            txt_username.Clear();
            txt_verifyOTP.Clear();
            this.Refresh();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            if(txt_newpass.Text==txt_conpass.Text)
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
                SqlCommand cmd = new SqlCommand("update Login Set Password='"+txt_conpass.Text+"' where Username='"+txt_username.Text+"' or Email='"+txt_email.Text+"'",con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_resetinfo.Text = "Password Reset Successfully";
            }
            else
            {
                MessageBox.Show("Password Doesn't Match","Library Soft");
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void btn_resetclear_Click(object sender, EventArgs e)
        {
            txt_conpass.Text = "";
            txt_newpass.Clear();
            this.Refresh();
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            pnl_forgetpass.Hide();
            pnl_resetpass.Show();
        }
    }
}
