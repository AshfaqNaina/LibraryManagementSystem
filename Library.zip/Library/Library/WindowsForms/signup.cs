﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library.WindowsForms
{
    public partial class signup : Form
    {
        public signup()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Admin_Username,Admin_Password from Admin where Admin_Password='"+txt_adminpass.Text+"'",con);
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.Read())
            {
                con.Close();
                if (txt_name.Text != "" && txt_email.Text != "" && txt_adminpass.Text != "" && txt_password.Text != "" && txt_username.Text!="")
                {
                        if (MessageBox.Show("Do you want to save the User's details", "Library Soft", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.No)
                        {
                            con.Open();
                            SqlCommand cmd1 = new SqlCommand("insert into Login(Name,Email,Username,Password) values('" + txt_name.Text + "','"+txt_email.Text+"','" + txt_username.Text + "','" + txt_password.Text + "')", con);
                            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                            cmd1.ExecuteNonQuery();
                            lbl_saveinfo.Text = "You added a new User!!!";
                            lbl_saveinfo.ForeColor = Color.Green;
                            con.Close();
                        }
                }
                else
                {
                    lbl_saveinfo.Text = "Please fill all The datas";
                    lbl_saveinfo.ForeColor = Color.Red;
                    dr.Close();
                    con.Close();
                }
            }
            else
            {
                    MessageBox.Show("Admin Password is Incorrect", "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_adminpass.Text = "";
            txt_name.Clear();
            txt_email.Clear();
            txt_username.Text = "";
            txt_password.Text = "";
            this.Refresh();
        }
    }
}
