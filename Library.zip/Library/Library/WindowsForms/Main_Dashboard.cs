﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library
{
    public partial class Main_Dashboard : Form
    {
        SqlConnection con;
        public Main_Dashboard()
        {
            InitializeComponent();
            tm_Time.Start();
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_StudentDetails_Click(object sender, EventArgs e)
        {
            UC_Student ucs = new UC_Student();
            ucs.Dock = DockStyle.Fill;
            pnl_slide.Top = btn_StudentDetails.Top;
            pnl_slide.Height = btn_StudentDetails.Height;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucs);
        }

        private void btn_BookDetails_Click(object sender, EventArgs e)
        {
            UC_BookDetails ucb = new UC_BookDetails();
            ucb.Dock = DockStyle.Fill;
            pnl_slide.Top = btn_BookDetails.Top;
            pnl_slide.Height = btn_BookDetails.Height;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucb);

        }

        private void btn_reports_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_reports.Height;
            pnl_slide.Top = btn_reports.Top;
            UC_Reports ucr = new UC_Reports();
            ucr.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucr);
        }

        private void tm_Time_Tick(object sender, EventArgs e)
        {
            lbl_time.Text = System.DateTime.Now.ToString("hh:mm:ss tt");
            lbl_day.Text = System.DateTime.Now.ToString("dddd  dd/MMM/yyyy ");
        }

        private void Main_Dashboard_Load(object sender, EventArgs e)
        {
            UC_Home uch = new UC_Home();
            uch.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(uch);
        }

        private void btn_BookIssue_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_BookIssue.Height;
            pnl_slide.Top = btn_BookIssue.Top;
            UC_withdraw ucw = new UC_withdraw();
            ucw.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucw);
        }

        private void btn_BookReturn_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_BookReturn.Height;
            pnl_slide.Top = btn_BookReturn.Top;
            UC_return ucr = new UC_return();
            ucr.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucr);
        }

        private void btn_Settings_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_Settings.Height;
            pnl_slide.Top = btn_Settings.Top;
            UC_settings ucse = new UC_settings();
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucse);
        }

        private void btn_slide_Click(object sender, EventArgs e)
        {
            if (pnl_Left.Width == 64)
            {
                pnl_Left.Visible = false;
                pnl_Left.Width = 282;
                Bunifu_Slide.ShowSync(pnl_Left);
                Bunifu_Logo.ShowSync(pb_logo);
                Bunifu_Sname.ShowSync(lbl_soft);
                bunifu_Ash.ShowSync(lbl_ash);
            }
            else
            {
                Bunifu_Sname.Hide(lbl_soft);
                bunifu_Ash.Hide(lbl_ash);
                Bunifu_Sname.Hide(lbl_soft);
                Bunifu_Logo.Hide(pb_logo);
                pnl_Left.Visible = false;
                pnl_Left.Width = 64;
                Bunifu_Slide.ShowSync(pnl_Left);

            }
        }

        private void btn_max_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_home.Height;
            pnl_slide.Top = btn_home.Top;
            UC_Home uch = new UC_Home();
            uch.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(uch);
        }
    }
}
