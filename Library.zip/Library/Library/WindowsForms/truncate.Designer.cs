﻿namespace Library.WindowsForms
{
    partial class truncate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pnl_Top = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_DStudent = new System.Windows.Forms.Button();
            this.lbl_ash = new System.Windows.Forms.Label();
            this.lbl_soft = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_bid = new System.Windows.Forms.Label();
            this.lbl_bname = new System.Windows.Forms.Label();
            this.pb_logo = new System.Windows.Forms.PictureBox();
            this.btn_Dbook = new System.Windows.Forms.Button();
            this.btn_DWithdraw = new System.Windows.Forms.Button();
            this.btn_DLogs = new System.Windows.Forms.Button();
            this.btn_DLogin = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.lbl_saveinfo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(115, 477);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 20);
            this.label5.TabIndex = 177;
            this.label5.Text = "Login Details";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.label4.Location = new System.Drawing.Point(101, 149);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(430, 40);
            this.label4.TabIndex = 176;
            this.label4.Text = "Library Management System";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel8.Location = new System.Drawing.Point(0, 10);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 590);
            this.panel8.TabIndex = 174;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 600);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(622, 10);
            this.panel7.TabIndex = 173;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(622, 10);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 600);
            this.panel6.TabIndex = 172;
            // 
            // pnl_Top
            // 
            this.pnl_Top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Top.Location = new System.Drawing.Point(0, 0);
            this.pnl_Top.Name = "pnl_Top";
            this.pnl_Top.Size = new System.Drawing.Size(632, 10);
            this.pnl_Top.TabIndex = 171;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(115, 300);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 20);
            this.label3.TabIndex = 169;
            this.label3.Text = "Student Details";
            // 
            // btn_DStudent
            // 
            this.btn_DStudent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DStudent.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_DStudent.FlatAppearance.BorderSize = 0;
            this.btn_DStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DStudent.ForeColor = System.Drawing.Color.White;
            this.btn_DStudent.Location = new System.Drawing.Point(382, 289);
            this.btn_DStudent.Name = "btn_DStudent";
            this.btn_DStudent.Size = new System.Drawing.Size(148, 31);
            this.btn_DStudent.TabIndex = 158;
            this.btn_DStudent.Text = "Delete Data";
            this.btn_DStudent.UseVisualStyleBackColor = false;
            this.btn_DStudent.Click += new System.EventHandler(this.btn_DStudent_Click);
            // 
            // lbl_ash
            // 
            this.lbl_ash.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_ash.AutoSize = true;
            this.lbl_ash.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ash.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_ash.Location = new System.Drawing.Point(251, 107);
            this.lbl_ash.Name = "lbl_ash";
            this.lbl_ash.Size = new System.Drawing.Size(126, 18);
            this.lbl_ash.TabIndex = 166;
            this.lbl_ash.Text = "Ash Developers";
            // 
            // lbl_soft
            // 
            this.lbl_soft.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_soft.AutoSize = true;
            this.lbl_soft.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_soft.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_soft.Location = new System.Drawing.Point(257, 78);
            this.lbl_soft.Name = "lbl_soft";
            this.lbl_soft.Size = new System.Drawing.Size(114, 24);
            this.lbl_soft.TabIndex = 167;
            this.lbl_soft.Text = "Library Soft";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(113, 241);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 20);
            this.label1.TabIndex = 164;
            this.label1.Text = "Book Details";
            // 
            // lbl_bid
            // 
            this.lbl_bid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bid.AutoSize = true;
            this.lbl_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_bid.Location = new System.Drawing.Point(115, 418);
            this.lbl_bid.Name = "lbl_bid";
            this.lbl_bid.Size = new System.Drawing.Size(48, 20);
            this.lbl_bid.TabIndex = 160;
            this.lbl_bid.Text = "Logs";
            // 
            // lbl_bname
            // 
            this.lbl_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bname.AutoSize = true;
            this.lbl_bname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_bname.Location = new System.Drawing.Point(115, 359);
            this.lbl_bname.Name = "lbl_bname";
            this.lbl_bname.Size = new System.Drawing.Size(147, 20);
            this.lbl_bname.TabIndex = 161;
            this.lbl_bname.Text = "WithDraw Details";
            // 
            // pb_logo
            // 
            this.pb_logo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_logo.Image = global::Library.Properties.Resources.icons8_avengers_50px;
            this.pb_logo.Location = new System.Drawing.Point(292, 25);
            this.pb_logo.Name = "pb_logo";
            this.pb_logo.Size = new System.Drawing.Size(50, 50);
            this.pb_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_logo.TabIndex = 168;
            this.pb_logo.TabStop = false;
            // 
            // btn_Dbook
            // 
            this.btn_Dbook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Dbook.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_Dbook.FlatAppearance.BorderSize = 0;
            this.btn_Dbook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Dbook.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dbook.ForeColor = System.Drawing.Color.White;
            this.btn_Dbook.Location = new System.Drawing.Point(382, 235);
            this.btn_Dbook.Name = "btn_Dbook";
            this.btn_Dbook.Size = new System.Drawing.Size(148, 31);
            this.btn_Dbook.TabIndex = 180;
            this.btn_Dbook.Text = "Delete Data";
            this.btn_Dbook.UseVisualStyleBackColor = false;
            this.btn_Dbook.Click += new System.EventHandler(this.btn_Dbook_Click);
            // 
            // btn_DWithdraw
            // 
            this.btn_DWithdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DWithdraw.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_DWithdraw.FlatAppearance.BorderSize = 0;
            this.btn_DWithdraw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DWithdraw.ForeColor = System.Drawing.Color.White;
            this.btn_DWithdraw.Location = new System.Drawing.Point(382, 353);
            this.btn_DWithdraw.Name = "btn_DWithdraw";
            this.btn_DWithdraw.Size = new System.Drawing.Size(148, 31);
            this.btn_DWithdraw.TabIndex = 181;
            this.btn_DWithdraw.Text = "Delete Data";
            this.btn_DWithdraw.UseVisualStyleBackColor = false;
            this.btn_DWithdraw.Click += new System.EventHandler(this.btn_DWithdraw_Click);
            // 
            // btn_DLogs
            // 
            this.btn_DLogs.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DLogs.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_DLogs.FlatAppearance.BorderSize = 0;
            this.btn_DLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DLogs.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DLogs.ForeColor = System.Drawing.Color.White;
            this.btn_DLogs.Location = new System.Drawing.Point(382, 412);
            this.btn_DLogs.Name = "btn_DLogs";
            this.btn_DLogs.Size = new System.Drawing.Size(148, 31);
            this.btn_DLogs.TabIndex = 182;
            this.btn_DLogs.Text = "Delete Data";
            this.btn_DLogs.UseVisualStyleBackColor = false;
            this.btn_DLogs.Click += new System.EventHandler(this.btn_DLogs_Click);
            // 
            // btn_DLogin
            // 
            this.btn_DLogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DLogin.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_DLogin.FlatAppearance.BorderSize = 0;
            this.btn_DLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DLogin.ForeColor = System.Drawing.Color.White;
            this.btn_DLogin.Location = new System.Drawing.Point(382, 471);
            this.btn_DLogin.Name = "btn_DLogin";
            this.btn_DLogin.Size = new System.Drawing.Size(148, 31);
            this.btn_DLogin.TabIndex = 183;
            this.btn_DLogin.Text = "Delete Data";
            this.btn_DLogin.UseVisualStyleBackColor = false;
            this.btn_DLogin.Click += new System.EventHandler(this.btn_DLogin_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_exit.BackColor = System.Drawing.SystemColors.Control;
            this.btn_exit.FlatAppearance.BorderSize = 0;
            this.btn_exit.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_exit.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.Red;
            this.btn_exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_exit.Location = new System.Drawing.Point(577, 16);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(39, 38);
            this.btn_exit.TabIndex = 184;
            this.btn_exit.Text = "X";
            this.btn_exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // lbl_saveinfo
            // 
            this.lbl_saveinfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_saveinfo.AutoSize = true;
            this.lbl_saveinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saveinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_saveinfo.Location = new System.Drawing.Point(145, 548);
            this.lbl_saveinfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_saveinfo.Name = "lbl_saveinfo";
            this.lbl_saveinfo.Size = new System.Drawing.Size(18, 24);
            this.lbl_saveinfo.TabIndex = 185;
            this.lbl_saveinfo.Text = "*";
            // 
            // truncate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 610);
            this.Controls.Add(this.lbl_saveinfo);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_DLogin);
            this.Controls.Add(this.btn_DLogs);
            this.Controls.Add(this.btn_DWithdraw);
            this.Controls.Add(this.btn_Dbook);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.pnl_Top);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_DStudent);
            this.Controls.Add(this.lbl_ash);
            this.Controls.Add(this.lbl_soft);
            this.Controls.Add(this.pb_logo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_bid);
            this.Controls.Add(this.lbl_bname);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "truncate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "truncate";
            this.Load += new System.EventHandler(this.truncate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel pnl_Top;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_DStudent;
        private System.Windows.Forms.Label lbl_ash;
        private System.Windows.Forms.Label lbl_soft;
        private System.Windows.Forms.PictureBox pb_logo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_bid;
        private System.Windows.Forms.Label lbl_bname;
        private System.Windows.Forms.Button btn_Dbook;
        private System.Windows.Forms.Button btn_DWithdraw;
        private System.Windows.Forms.Button btn_DLogs;
        private System.Windows.Forms.Button btn_DLogin;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Label lbl_saveinfo;
    }
}