﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library.WindowsForms
{
    public partial class truncate : Form
    {
        public truncate()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;

        private void btn_exit_Click(object sender, EventArgs e)
        {
            UserControls.UC_stock ucs = new UserControls.UC_stock();
            this.Hide();
            ucs.Show();
        }

        private void btn_Dbook_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Book", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Book Data has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_DStudent_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Users", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Student Data has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_DWithdraw_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Withdraw", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Books Withdraw Data has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_DLogs_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Logs", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Logs Data has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_DLogin_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Login", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Login Data has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void truncate_Load(object sender, EventArgs e)
        {
            lbl_saveinfo.Text = "";
        }
    }
}
