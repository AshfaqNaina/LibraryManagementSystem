﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video.DirectShow;
using AForge.Video;
using AForge.Imaging;
using AForge.Imaging.Filters;
using System.Drawing.Imaging;
using AForge;

namespace Library.WindowsForms
{
    public partial class WebCam : Form
    {
        public WebCam()
        {
            InitializeComponent();
        }
        FilterInfoCollection filterInfoCollection;
        VideoCaptureDevice videoCaptureDevice;

        private void WebCam_Load(object sender, EventArgs e)
        {
            
            filterInfoCollection = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo Device in filterInfoCollection)
                cb_selectCam.Items.Add(Device.Name);
            cb_selectCam.SelectedIndex = 0;
            videoCaptureDevice = new VideoCaptureDevice();

            videoCaptureDevice = new VideoCaptureDevice(filterInfoCollection[cb_selectCam.SelectedIndex].MonikerString);
            videoCaptureDevice.NewFrame += FinalFrame_NewFrame;
            videoCaptureDevice.Start();
        }

        private void btn_click_Click(object sender, EventArgs e)
        {
            pb_webcam.Hide();
            pb_webCamCap.Show();
            pb_webCamCap.Image = (Bitmap)pb_webcam.Image.Clone();
        }
        private void FinalFrame_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            pb_webcam.Image = (Bitmap)eventArgs.Frame.Clone();
        }
        private void btn_decline_Click(object sender, EventArgs e)
        {
            pb_webcam.Show();
            pb_webCamCap.Hide();
        }

        private void WebCam_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (videoCaptureDevice.IsRunning == true) videoCaptureDevice.Stop();
        }

        private void btn_accept_Click(object sender, EventArgs e)
        {
            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "JPG(*.jpg)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                pb_webCamCap.Image.Save(f.FileName);
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
