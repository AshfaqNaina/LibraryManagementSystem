﻿namespace Library.WindowsForms
{
    partial class forget_Pass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_info = new System.Windows.Forms.Label();
            this.lbl_head = new System.Windows.Forms.Label();
            this.btn_exit = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pnl_Top = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_sendOTP = new System.Windows.Forms.Button();
            this.lbl_ash = new System.Windows.Forms.Label();
            this.lbl_soft = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txt_verifyOTP = new System.Windows.Forms.TextBox();
            this.txt_username = new System.Windows.Forms.TextBox();
            this.lbl_username = new System.Windows.Forms.Label();
            this.lbl_enterCode = new System.Windows.Forms.Label();
            this.btn_verifyOTP = new System.Windows.Forms.Button();
            this.pb_logo = new System.Windows.Forms.PictureBox();
            this.pnl_forgetpass = new System.Windows.Forms.Panel();
            this.btn_next = new System.Windows.Forms.Button();
            this.pnl_resetpass = new System.Windows.Forms.Panel();
            this.btn_resetclear = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.lbl_resetinfo = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_conpass = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txt_newpass = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).BeginInit();
            this.pnl_forgetpass.SuspendLayout();
            this.pnl_resetpass.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_info
            // 
            this.lbl_info.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_info.AutoSize = true;
            this.lbl_info.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_info.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_info.Location = new System.Drawing.Point(179, 353);
            this.lbl_info.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_info.Name = "lbl_info";
            this.lbl_info.Size = new System.Drawing.Size(18, 24);
            this.lbl_info.TabIndex = 181;
            this.lbl_info.Text = "*";
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(49, 188);
            this.lbl_head.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(430, 40);
            this.lbl_head.TabIndex = 177;
            this.lbl_head.Text = "Library Management System";
            // 
            // btn_exit
            // 
            this.btn_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_exit.BackColor = System.Drawing.SystemColors.Control;
            this.btn_exit.FlatAppearance.BorderSize = 0;
            this.btn_exit.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_exit.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.Red;
            this.btn_exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_exit.Location = new System.Drawing.Point(463, 16);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(39, 38);
            this.btn_exit.TabIndex = 0;
            this.btn_exit.Text = "X";
            this.btn_exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel8.Location = new System.Drawing.Point(0, 10);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 664);
            this.panel8.TabIndex = 175;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 674);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(508, 10);
            this.panel7.TabIndex = 174;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(508, 10);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 674);
            this.panel6.TabIndex = 173;
            // 
            // pnl_Top
            // 
            this.pnl_Top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Top.Location = new System.Drawing.Point(0, 0);
            this.pnl_Top.Name = "pnl_Top";
            this.pnl_Top.Size = new System.Drawing.Size(518, 10);
            this.pnl_Top.TabIndex = 172;
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel3.Location = new System.Drawing.Point(176, 141);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(254, 3);
            this.panel3.TabIndex = 171;
            // 
            // txt_email
            // 
            this.txt_email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_email.BackColor = System.Drawing.SystemColors.Control;
            this.txt_email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.Location = new System.Drawing.Point(176, 118);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(254, 19);
            this.txt_email.TabIndex = 1;
            // 
            // lbl_email
            // 
            this.lbl_email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_email.AutoSize = true;
            this.lbl_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_email.Location = new System.Drawing.Point(20, 117);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(58, 20);
            this.lbl_email.TabIndex = 169;
            this.lbl_email.Text = "Email:";
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_clear.BackColor = System.Drawing.Color.Red;
            this.btn_clear.FlatAppearance.BorderSize = 0;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.White;
            this.btn_clear.Location = new System.Drawing.Point(318, 170);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(112, 31);
            this.btn_clear.TabIndex = 4;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_sendOTP
            // 
            this.btn_sendOTP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_sendOTP.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_sendOTP.FlatAppearance.BorderSize = 0;
            this.btn_sendOTP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sendOTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sendOTP.ForeColor = System.Drawing.Color.White;
            this.btn_sendOTP.Location = new System.Drawing.Point(178, 170);
            this.btn_sendOTP.Name = "btn_sendOTP";
            this.btn_sendOTP.Size = new System.Drawing.Size(124, 31);
            this.btn_sendOTP.TabIndex = 2;
            this.btn_sendOTP.Text = "Send OTP";
            this.btn_sendOTP.UseVisualStyleBackColor = false;
            this.btn_sendOTP.Click += new System.EventHandler(this.btn_sendOTP_Click);
            // 
            // lbl_ash
            // 
            this.lbl_ash.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_ash.AutoSize = true;
            this.lbl_ash.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ash.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_ash.Location = new System.Drawing.Point(193, 169);
            this.lbl_ash.Name = "lbl_ash";
            this.lbl_ash.Size = new System.Drawing.Size(126, 18);
            this.lbl_ash.TabIndex = 164;
            this.lbl_ash.Text = "Ash Developers";
            // 
            // lbl_soft
            // 
            this.lbl_soft.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_soft.AutoSize = true;
            this.lbl_soft.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_soft.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_soft.Location = new System.Drawing.Point(199, 140);
            this.lbl_soft.Name = "lbl_soft";
            this.lbl_soft.Size = new System.Drawing.Size(114, 24);
            this.lbl_soft.TabIndex = 165;
            this.lbl_soft.Text = "Library Soft";
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel5.Location = new System.Drawing.Point(177, 92);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(254, 3);
            this.panel5.TabIndex = 159;
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel4.Location = new System.Drawing.Point(178, 277);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(254, 3);
            this.panel4.TabIndex = 158;
            // 
            // txt_verifyOTP
            // 
            this.txt_verifyOTP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_verifyOTP.BackColor = System.Drawing.SystemColors.Control;
            this.txt_verifyOTP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_verifyOTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_verifyOTP.Location = new System.Drawing.Point(178, 254);
            this.txt_verifyOTP.Name = "txt_verifyOTP";
            this.txt_verifyOTP.PasswordChar = '*';
            this.txt_verifyOTP.Size = new System.Drawing.Size(254, 19);
            this.txt_verifyOTP.TabIndex = 3;
            // 
            // txt_username
            // 
            this.txt_username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_username.BackColor = System.Drawing.SystemColors.Control;
            this.txt_username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_username.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_username.Location = new System.Drawing.Point(177, 69);
            this.txt_username.Name = "txt_username";
            this.txt_username.Size = new System.Drawing.Size(254, 19);
            this.txt_username.TabIndex = 0;
            // 
            // lbl_username
            // 
            this.lbl_username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_username.AutoSize = true;
            this.lbl_username.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_username.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_username.Location = new System.Drawing.Point(18, 68);
            this.lbl_username.Name = "lbl_username";
            this.lbl_username.Size = new System.Drawing.Size(96, 20);
            this.lbl_username.TabIndex = 154;
            this.lbl_username.Text = "Username:";
            // 
            // lbl_enterCode
            // 
            this.lbl_enterCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_enterCode.AutoSize = true;
            this.lbl_enterCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_enterCode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_enterCode.Location = new System.Drawing.Point(20, 253);
            this.lbl_enterCode.Name = "lbl_enterCode";
            this.lbl_enterCode.Size = new System.Drawing.Size(105, 20);
            this.lbl_enterCode.TabIndex = 155;
            this.lbl_enterCode.Text = "Enter Code:";
            // 
            // btn_verifyOTP
            // 
            this.btn_verifyOTP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_verifyOTP.BackColor = System.Drawing.Color.Red;
            this.btn_verifyOTP.FlatAppearance.BorderSize = 0;
            this.btn_verifyOTP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_verifyOTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_verifyOTP.ForeColor = System.Drawing.Color.White;
            this.btn_verifyOTP.Location = new System.Drawing.Point(178, 299);
            this.btn_verifyOTP.Name = "btn_verifyOTP";
            this.btn_verifyOTP.Size = new System.Drawing.Size(124, 31);
            this.btn_verifyOTP.TabIndex = 5;
            this.btn_verifyOTP.Text = "Verify OTP";
            this.btn_verifyOTP.UseVisualStyleBackColor = false;
            this.btn_verifyOTP.Click += new System.EventHandler(this.btn_verifyOTP_Click);
            // 
            // pb_logo
            // 
            this.pb_logo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_logo.Image = global::Library.Properties.Resources.icons8_avengers_50px;
            this.pb_logo.Location = new System.Drawing.Point(234, 87);
            this.pb_logo.Name = "pb_logo";
            this.pb_logo.Size = new System.Drawing.Size(50, 50);
            this.pb_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_logo.TabIndex = 166;
            this.pb_logo.TabStop = false;
            // 
            // pnl_forgetpass
            // 
            this.pnl_forgetpass.Controls.Add(this.btn_next);
            this.pnl_forgetpass.Controls.Add(this.lbl_username);
            this.pnl_forgetpass.Controls.Add(this.lbl_enterCode);
            this.pnl_forgetpass.Controls.Add(this.btn_verifyOTP);
            this.pnl_forgetpass.Controls.Add(this.txt_username);
            this.pnl_forgetpass.Controls.Add(this.lbl_info);
            this.pnl_forgetpass.Controls.Add(this.txt_verifyOTP);
            this.pnl_forgetpass.Controls.Add(this.panel4);
            this.pnl_forgetpass.Controls.Add(this.panel5);
            this.pnl_forgetpass.Controls.Add(this.btn_sendOTP);
            this.pnl_forgetpass.Controls.Add(this.btn_clear);
            this.pnl_forgetpass.Controls.Add(this.lbl_email);
            this.pnl_forgetpass.Controls.Add(this.txt_email);
            this.pnl_forgetpass.Controls.Add(this.panel3);
            this.pnl_forgetpass.Location = new System.Drawing.Point(33, 231);
            this.pnl_forgetpass.Name = "pnl_forgetpass";
            this.pnl_forgetpass.Size = new System.Drawing.Size(452, 437);
            this.pnl_forgetpass.TabIndex = 184;
            // 
            // btn_next
            // 
            this.btn_next.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_next.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_next.FlatAppearance.BorderSize = 0;
            this.btn_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_next.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_next.ForeColor = System.Drawing.Color.White;
            this.btn_next.Location = new System.Drawing.Point(177, 391);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(124, 31);
            this.btn_next.TabIndex = 6;
            this.btn_next.Text = "Next";
            this.btn_next.UseVisualStyleBackColor = false;
            this.btn_next.Visible = false;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // pnl_resetpass
            // 
            this.pnl_resetpass.Controls.Add(this.btn_resetclear);
            this.pnl_resetpass.Controls.Add(this.btn_back);
            this.pnl_resetpass.Controls.Add(this.btn_reset);
            this.pnl_resetpass.Controls.Add(this.lbl_resetinfo);
            this.pnl_resetpass.Controls.Add(this.panel2);
            this.pnl_resetpass.Controls.Add(this.txt_conpass);
            this.pnl_resetpass.Controls.Add(this.label2);
            this.pnl_resetpass.Controls.Add(this.panel9);
            this.pnl_resetpass.Controls.Add(this.txt_newpass);
            this.pnl_resetpass.Controls.Add(this.label3);
            this.pnl_resetpass.Location = new System.Drawing.Point(34, 246);
            this.pnl_resetpass.Name = "pnl_resetpass";
            this.pnl_resetpass.Size = new System.Drawing.Size(451, 376);
            this.pnl_resetpass.TabIndex = 185;
            // 
            // btn_resetclear
            // 
            this.btn_resetclear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_resetclear.BackColor = System.Drawing.Color.Red;
            this.btn_resetclear.FlatAppearance.BorderSize = 0;
            this.btn_resetclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_resetclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_resetclear.ForeColor = System.Drawing.Color.White;
            this.btn_resetclear.Location = new System.Drawing.Point(316, 156);
            this.btn_resetclear.Name = "btn_resetclear";
            this.btn_resetclear.Size = new System.Drawing.Size(112, 31);
            this.btn_resetclear.TabIndex = 215;
            this.btn_resetclear.Text = "Clear";
            this.btn_resetclear.UseVisualStyleBackColor = false;
            this.btn_resetclear.Click += new System.EventHandler(this.btn_resetclear_Click);
            // 
            // btn_back
            // 
            this.btn_back.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_back.FlatAppearance.BorderSize = 0;
            this.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.ForeColor = System.Drawing.Color.White;
            this.btn_back.Location = new System.Drawing.Point(177, 326);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(112, 31);
            this.btn_back.TabIndex = 214;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_reset.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_reset.FlatAppearance.BorderSize = 0;
            this.btn_reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.ForeColor = System.Drawing.Color.White;
            this.btn_reset.Location = new System.Drawing.Point(174, 156);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(124, 31);
            this.btn_reset.TabIndex = 213;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // lbl_resetinfo
            // 
            this.lbl_resetinfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_resetinfo.AutoSize = true;
            this.lbl_resetinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_resetinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_resetinfo.Location = new System.Drawing.Point(178, 225);
            this.lbl_resetinfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_resetinfo.Name = "lbl_resetinfo";
            this.lbl_resetinfo.Size = new System.Drawing.Size(18, 24);
            this.lbl_resetinfo.TabIndex = 212;
            this.lbl_resetinfo.Text = "*";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel2.Location = new System.Drawing.Point(176, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(254, 3);
            this.panel2.TabIndex = 211;
            // 
            // txt_conpass
            // 
            this.txt_conpass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_conpass.BackColor = System.Drawing.SystemColors.Control;
            this.txt_conpass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_conpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_conpass.Location = new System.Drawing.Point(174, 94);
            this.txt_conpass.Name = "txt_conpass";
            this.txt_conpass.PasswordChar = '*';
            this.txt_conpass.Size = new System.Drawing.Size(254, 19);
            this.txt_conpass.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(8, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 20);
            this.label2.TabIndex = 209;
            this.label2.Text = "Confrim Password:";
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel9.Location = new System.Drawing.Point(176, 69);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(254, 3);
            this.panel9.TabIndex = 206;
            // 
            // txt_newpass
            // 
            this.txt_newpass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_newpass.BackColor = System.Drawing.SystemColors.Control;
            this.txt_newpass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_newpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_newpass.Location = new System.Drawing.Point(176, 44);
            this.txt_newpass.Name = "txt_newpass";
            this.txt_newpass.Size = new System.Drawing.Size(254, 19);
            this.txt_newpass.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(8, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 20);
            this.label3.TabIndex = 204;
            this.label3.Text = "New Password:";
            // 
            // forget_Pass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 684);
            this.Controls.Add(this.pnl_forgetpass);
            this.Controls.Add(this.lbl_head);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.pnl_Top);
            this.Controls.Add(this.lbl_ash);
            this.Controls.Add(this.lbl_soft);
            this.Controls.Add(this.pb_logo);
            this.Controls.Add(this.pnl_resetpass);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "forget_Pass";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "forget_Pass";
            ((System.ComponentModel.ISupportInitialize)(this.pb_logo)).EndInit();
            this.pnl_forgetpass.ResumeLayout(false);
            this.pnl_forgetpass.PerformLayout();
            this.pnl_resetpass.ResumeLayout(false);
            this.pnl_resetpass.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_info;
        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel pnl_Top;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_sendOTP;
        private System.Windows.Forms.Label lbl_ash;
        private System.Windows.Forms.Label lbl_soft;
        private System.Windows.Forms.PictureBox pb_logo;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txt_verifyOTP;
        private System.Windows.Forms.TextBox txt_username;
        private System.Windows.Forms.Label lbl_username;
        private System.Windows.Forms.Label lbl_enterCode;
        private System.Windows.Forms.Button btn_verifyOTP;
        private System.Windows.Forms.Panel pnl_forgetpass;
        private System.Windows.Forms.Panel pnl_resetpass;
        private System.Windows.Forms.Label lbl_resetinfo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_conpass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txt_newpass;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_resetclear;
        private System.Windows.Forms.Button btn_next;
    }
}