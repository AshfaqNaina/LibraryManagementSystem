﻿namespace Library
{
    partial class UC_withdraw
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_barcode = new System.Windows.Forms.TextBox();
            this.lbl_barcode = new System.Windows.Forms.Label();
            this.txt_category = new System.Windows.Forms.TextBox();
            this.btn_issue = new System.Windows.Forms.Button();
            this.lbl_Bookreturn = new System.Windows.Forms.Label();
            this.txt_return = new System.Windows.Forms.TextBox();
            this.txt_BookID = new System.Windows.Forms.TextBox();
            this.lbl_category = new System.Windows.Forms.Label();
            this.lbl_bid = new System.Windows.Forms.Label();
            this.txt_author = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.lbl_price = new System.Windows.Forms.Label();
            this.txt_publisher = new System.Windows.Forms.TextBox();
            this.lbl_isbn = new System.Windows.Forms.Label();
            this.lbl_publisher = new System.Windows.Forms.Label();
            this.txt_isbn = new System.Windows.Forms.TextBox();
            this.lbl_author = new System.Windows.Forms.Label();
            this.lbl_bname = new System.Windows.Forms.Label();
            this.txt_bname = new System.Windows.Forms.TextBox();
            this.txt_UserID = new System.Windows.Forms.TextBox();
            this.lbl_sid = new System.Windows.Forms.Label();
            this.pnl_PB = new System.Windows.Forms.Panel();
            this.pnl_PBbottom = new System.Windows.Forms.Panel();
            this.pnl_PBtop = new System.Windows.Forms.Panel();
            this.pnl_PBleft = new System.Windows.Forms.Panel();
            this.pnl_PBright = new System.Windows.Forms.Panel();
            this.pb_student = new System.Windows.Forms.PictureBox();
            this.txt_stu_id = new System.Windows.Forms.TextBox();
            this.lbl_user = new System.Windows.Forms.Label();
            this.txt_course = new System.Windows.Forms.TextBox();
            this.txt_dept = new System.Windows.Forms.TextBox();
            this.lbl_course = new System.Windows.Forms.Label();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.lbl_smobile = new System.Windows.Forms.Label();
            this.lbl_semail = new System.Windows.Forms.Label();
            this.txt_mobile = new System.Windows.Forms.TextBox();
            this.lbl_sdept = new System.Windows.Forms.Label();
            this.lbl_sname = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.lbl_head = new System.Windows.Forms.Label();
            this.lbl_QR = new System.Windows.Forms.Label();
            this.lbl_bar = new System.Windows.Forms.Label();
            this.pnl_Student = new System.Windows.Forms.Panel();
            this.pnl_StudentTop = new System.Windows.Forms.Panel();
            this.pnl_StudentBottom = new System.Windows.Forms.Panel();
            this.pnl_StudentRight = new System.Windows.Forms.Panel();
            this.pnl_StudentLeft = new System.Windows.Forms.Panel();
            this.pnl_Search = new System.Windows.Forms.Panel();
            this.btn_clear = new System.Windows.Forms.Button();
            this.pnl_SearchBottom = new System.Windows.Forms.Panel();
            this.pnl_SearchRight = new System.Windows.Forms.Panel();
            this.pnl_SearchTop = new System.Windows.Forms.Panel();
            this.pnl_SearchLeft = new System.Windows.Forms.Panel();
            this.btn_usearch = new System.Windows.Forms.Button();
            this.pnl_book = new System.Windows.Forms.Panel();
            this.lbl_sendmail = new System.Windows.Forms.Label();
            this.bunifuSend = new Bunifu.Framework.UI.BunifuCheckbox();
            this.pnl_BookBottom = new System.Windows.Forms.Panel();
            this.pnl_BookTop = new System.Windows.Forms.Panel();
            this.pnl_BookRight = new System.Windows.Forms.Panel();
            this.pnl_BookLeft = new System.Windows.Forms.Panel();
            this.btn_bsearch = new System.Windows.Forms.Button();
            this.pnl_QR_Bar = new System.Windows.Forms.Panel();
            this.pb_qrcode = new System.Windows.Forms.PictureBox();
            this.rtxt_address = new System.Windows.Forms.RichTextBox();
            this.txt_qrcode = new System.Windows.Forms.TextBox();
            this.lbl_saveinfo = new System.Windows.Forms.Label();
            this.pnl_QRbottom = new System.Windows.Forms.Panel();
            this.pnl_QRright = new System.Windows.Forms.Panel();
            this.pnl_QRtop = new System.Windows.Forms.Panel();
            this.pnl_QRleft = new System.Windows.Forms.Panel();
            this.pb_bar = new System.Windows.Forms.PictureBox();
            this.pnl_PB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).BeginInit();
            this.pnl_Student.SuspendLayout();
            this.pnl_Search.SuspendLayout();
            this.pnl_book.SuspendLayout();
            this.pnl_QR_Bar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_qrcode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bar)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_barcode
            // 
            this.txt_barcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_barcode.BackColor = System.Drawing.SystemColors.Window;
            this.txt_barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_barcode.Location = new System.Drawing.Point(184, 436);
            this.txt_barcode.Name = "txt_barcode";
            this.txt_barcode.ReadOnly = true;
            this.txt_barcode.Size = new System.Drawing.Size(242, 29);
            this.txt_barcode.TabIndex = 114;
            // 
            // lbl_barcode
            // 
            this.lbl_barcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_barcode.AutoSize = true;
            this.lbl_barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_barcode.ForeColor = System.Drawing.Color.Black;
            this.lbl_barcode.Location = new System.Drawing.Point(17, 439);
            this.lbl_barcode.Name = "lbl_barcode";
            this.lbl_barcode.Size = new System.Drawing.Size(103, 24);
            this.lbl_barcode.TabIndex = 113;
            this.lbl_barcode.Text = "Bar Code:";
            // 
            // txt_category
            // 
            this.txt_category.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_category.BackColor = System.Drawing.SystemColors.Window;
            this.txt_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_category.Location = new System.Drawing.Point(184, 348);
            this.txt_category.Name = "txt_category";
            this.txt_category.ReadOnly = true;
            this.txt_category.Size = new System.Drawing.Size(242, 29);
            this.txt_category.TabIndex = 112;
            // 
            // btn_issue
            // 
            this.btn_issue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_issue.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_issue.FlatAppearance.BorderSize = 0;
            this.btn_issue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_issue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_issue.ForeColor = System.Drawing.Color.White;
            this.btn_issue.Location = new System.Drawing.Point(241, 527);
            this.btn_issue.Name = "btn_issue";
            this.btn_issue.Size = new System.Drawing.Size(185, 35);
            this.btn_issue.TabIndex = 92;
            this.btn_issue.Text = "Issue Book";
            this.btn_issue.UseVisualStyleBackColor = false;
            this.btn_issue.Click += new System.EventHandler(this.btn_issue_Click);
            // 
            // lbl_Bookreturn
            // 
            this.lbl_Bookreturn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_Bookreturn.AutoSize = true;
            this.lbl_Bookreturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bookreturn.ForeColor = System.Drawing.Color.Black;
            this.lbl_Bookreturn.Location = new System.Drawing.Point(17, 484);
            this.lbl_Bookreturn.Name = "lbl_Bookreturn";
            this.lbl_Bookreturn.Size = new System.Drawing.Size(126, 24);
            this.lbl_Bookreturn.TabIndex = 96;
            this.lbl_Bookreturn.Text = "Return Date:";
            // 
            // txt_return
            // 
            this.txt_return.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_return.BackColor = System.Drawing.SystemColors.Window;
            this.txt_return.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_return.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txt_return.Location = new System.Drawing.Point(184, 481);
            this.txt_return.Name = "txt_return";
            this.txt_return.ReadOnly = true;
            this.txt_return.Size = new System.Drawing.Size(242, 29);
            this.txt_return.TabIndex = 95;
            // 
            // txt_BookID
            // 
            this.txt_BookID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_BookID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_BookID.Location = new System.Drawing.Point(184, 64);
            this.txt_BookID.Name = "txt_BookID";
            this.txt_BookID.Size = new System.Drawing.Size(242, 29);
            this.txt_BookID.TabIndex = 92;
            this.txt_BookID.Text = "B10";
            // 
            // lbl_category
            // 
            this.lbl_category.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_category.AutoSize = true;
            this.lbl_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_category.ForeColor = System.Drawing.Color.Black;
            this.lbl_category.Location = new System.Drawing.Point(17, 351);
            this.lbl_category.Name = "lbl_category";
            this.lbl_category.Size = new System.Drawing.Size(99, 24);
            this.lbl_category.TabIndex = 90;
            this.lbl_category.Text = "Category:";
            // 
            // lbl_bid
            // 
            this.lbl_bid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bid.AutoSize = true;
            this.lbl_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bid.ForeColor = System.Drawing.Color.Black;
            this.lbl_bid.Location = new System.Drawing.Point(17, 67);
            this.lbl_bid.Name = "lbl_bid";
            this.lbl_bid.Size = new System.Drawing.Size(88, 24);
            this.lbl_bid.TabIndex = 87;
            this.lbl_bid.Text = "Book ID:";
            // 
            // txt_author
            // 
            this.txt_author.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_author.BackColor = System.Drawing.SystemColors.Window;
            this.txt_author.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_author.Location = new System.Drawing.Point(184, 216);
            this.txt_author.Name = "txt_author";
            this.txt_author.ReadOnly = true;
            this.txt_author.Size = new System.Drawing.Size(242, 29);
            this.txt_author.TabIndex = 86;
            // 
            // txt_price
            // 
            this.txt_price.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_price.BackColor = System.Drawing.SystemColors.Window;
            this.txt_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_price.Location = new System.Drawing.Point(184, 392);
            this.txt_price.Name = "txt_price";
            this.txt_price.ReadOnly = true;
            this.txt_price.Size = new System.Drawing.Size(242, 29);
            this.txt_price.TabIndex = 85;
            // 
            // lbl_price
            // 
            this.lbl_price.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_price.AutoSize = true;
            this.lbl_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_price.ForeColor = System.Drawing.Color.Black;
            this.lbl_price.Location = new System.Drawing.Point(17, 395);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(64, 24);
            this.lbl_price.TabIndex = 83;
            this.lbl_price.Text = "Price:";
            // 
            // txt_publisher
            // 
            this.txt_publisher.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_publisher.BackColor = System.Drawing.SystemColors.Window;
            this.txt_publisher.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_publisher.Location = new System.Drawing.Point(184, 304);
            this.txt_publisher.Name = "txt_publisher";
            this.txt_publisher.ReadOnly = true;
            this.txt_publisher.Size = new System.Drawing.Size(242, 29);
            this.txt_publisher.TabIndex = 80;
            // 
            // lbl_isbn
            // 
            this.lbl_isbn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_isbn.AutoSize = true;
            this.lbl_isbn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_isbn.ForeColor = System.Drawing.Color.Black;
            this.lbl_isbn.Location = new System.Drawing.Point(17, 263);
            this.lbl_isbn.Name = "lbl_isbn";
            this.lbl_isbn.Size = new System.Drawing.Size(95, 24);
            this.lbl_isbn.TabIndex = 82;
            this.lbl_isbn.Text = "ISBN No:";
            // 
            // lbl_publisher
            // 
            this.lbl_publisher.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_publisher.AutoSize = true;
            this.lbl_publisher.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_publisher.ForeColor = System.Drawing.Color.Black;
            this.lbl_publisher.Location = new System.Drawing.Point(17, 307);
            this.lbl_publisher.Name = "lbl_publisher";
            this.lbl_publisher.Size = new System.Drawing.Size(104, 24);
            this.lbl_publisher.TabIndex = 81;
            this.lbl_publisher.Text = "Publisher:";
            // 
            // txt_isbn
            // 
            this.txt_isbn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_isbn.BackColor = System.Drawing.SystemColors.Window;
            this.txt_isbn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_isbn.Location = new System.Drawing.Point(184, 260);
            this.txt_isbn.Name = "txt_isbn";
            this.txt_isbn.ReadOnly = true;
            this.txt_isbn.Size = new System.Drawing.Size(242, 29);
            this.txt_isbn.TabIndex = 79;
            // 
            // lbl_author
            // 
            this.lbl_author.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_author.AutoSize = true;
            this.lbl_author.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_author.ForeColor = System.Drawing.Color.Black;
            this.lbl_author.Location = new System.Drawing.Point(17, 219);
            this.lbl_author.Name = "lbl_author";
            this.lbl_author.Size = new System.Drawing.Size(139, 24);
            this.lbl_author.TabIndex = 77;
            this.lbl_author.Text = "Author Name:";
            // 
            // lbl_bname
            // 
            this.lbl_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bname.AutoSize = true;
            this.lbl_bname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bname.ForeColor = System.Drawing.Color.Black;
            this.lbl_bname.Location = new System.Drawing.Point(17, 175);
            this.lbl_bname.Name = "lbl_bname";
            this.lbl_bname.Size = new System.Drawing.Size(124, 24);
            this.lbl_bname.TabIndex = 39;
            this.lbl_bname.Text = "Book Name:";
            // 
            // txt_bname
            // 
            this.txt_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_bname.BackColor = System.Drawing.SystemColors.Window;
            this.txt_bname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_bname.Location = new System.Drawing.Point(184, 172);
            this.txt_bname.Name = "txt_bname";
            this.txt_bname.ReadOnly = true;
            this.txt_bname.Size = new System.Drawing.Size(242, 29);
            this.txt_bname.TabIndex = 38;
            // 
            // txt_UserID
            // 
            this.txt_UserID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_UserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_UserID.Location = new System.Drawing.Point(120, 29);
            this.txt_UserID.Name = "txt_UserID";
            this.txt_UserID.Size = new System.Drawing.Size(133, 29);
            this.txt_UserID.TabIndex = 41;
            this.txt_UserID.Text = "A10";
            // 
            // lbl_sid
            // 
            this.lbl_sid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sid.AutoSize = true;
            this.lbl_sid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sid.ForeColor = System.Drawing.Color.Black;
            this.lbl_sid.Location = new System.Drawing.Point(16, 32);
            this.lbl_sid.Name = "lbl_sid";
            this.lbl_sid.Size = new System.Drawing.Size(99, 24);
            this.lbl_sid.TabIndex = 40;
            this.lbl_sid.Text = "User\'s ID:";
            // 
            // pnl_PB
            // 
            this.pnl_PB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_PB.Controls.Add(this.pnl_PBbottom);
            this.pnl_PB.Controls.Add(this.pnl_PBtop);
            this.pnl_PB.Controls.Add(this.pnl_PBleft);
            this.pnl_PB.Controls.Add(this.pnl_PBright);
            this.pnl_PB.Controls.Add(this.pb_student);
            this.pnl_PB.Location = new System.Drawing.Point(115, 29);
            this.pnl_PB.Name = "pnl_PB";
            this.pnl_PB.Size = new System.Drawing.Size(205, 250);
            this.pnl_PB.TabIndex = 116;
            // 
            // pnl_PBbottom
            // 
            this.pnl_PBbottom.BackColor = System.Drawing.Color.White;
            this.pnl_PBbottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_PBbottom.Location = new System.Drawing.Point(10, 240);
            this.pnl_PBbottom.Name = "pnl_PBbottom";
            this.pnl_PBbottom.Size = new System.Drawing.Size(185, 10);
            this.pnl_PBbottom.TabIndex = 3;
            // 
            // pnl_PBtop
            // 
            this.pnl_PBtop.BackColor = System.Drawing.Color.White;
            this.pnl_PBtop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_PBtop.Location = new System.Drawing.Point(10, 0);
            this.pnl_PBtop.Name = "pnl_PBtop";
            this.pnl_PBtop.Size = new System.Drawing.Size(185, 10);
            this.pnl_PBtop.TabIndex = 2;
            // 
            // pnl_PBleft
            // 
            this.pnl_PBleft.BackColor = System.Drawing.Color.White;
            this.pnl_PBleft.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_PBleft.Location = new System.Drawing.Point(195, 0);
            this.pnl_PBleft.Name = "pnl_PBleft";
            this.pnl_PBleft.Size = new System.Drawing.Size(10, 250);
            this.pnl_PBleft.TabIndex = 1;
            // 
            // pnl_PBright
            // 
            this.pnl_PBright.BackColor = System.Drawing.Color.White;
            this.pnl_PBright.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_PBright.Location = new System.Drawing.Point(0, 0);
            this.pnl_PBright.Name = "pnl_PBright";
            this.pnl_PBright.Size = new System.Drawing.Size(10, 250);
            this.pnl_PBright.TabIndex = 0;
            // 
            // pb_student
            // 
            this.pb_student.Image = global::Library.Properties.Resources.No;
            this.pb_student.Location = new System.Drawing.Point(10, 8);
            this.pb_student.Name = "pb_student";
            this.pb_student.Size = new System.Drawing.Size(190, 232);
            this.pb_student.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_student.TabIndex = 95;
            this.pb_student.TabStop = false;
            // 
            // txt_stu_id
            // 
            this.txt_stu_id.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_stu_id.BackColor = System.Drawing.SystemColors.Window;
            this.txt_stu_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_stu_id.Location = new System.Drawing.Point(213, 307);
            this.txt_stu_id.Name = "txt_stu_id";
            this.txt_stu_id.ReadOnly = true;
            this.txt_stu_id.Size = new System.Drawing.Size(197, 29);
            this.txt_stu_id.TabIndex = 89;
            // 
            // lbl_user
            // 
            this.lbl_user.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_user.AutoSize = true;
            this.lbl_user.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_user.ForeColor = System.Drawing.Color.Black;
            this.lbl_user.Location = new System.Drawing.Point(16, 310);
            this.lbl_user.Name = "lbl_user";
            this.lbl_user.Size = new System.Drawing.Size(161, 24);
            this.lbl_user.TabIndex = 88;
            this.lbl_user.Text = "User/Student ID:";
            // 
            // txt_course
            // 
            this.txt_course.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_course.BackColor = System.Drawing.SystemColors.Window;
            this.txt_course.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_course.Location = new System.Drawing.Point(213, 522);
            this.txt_course.Name = "txt_course";
            this.txt_course.ReadOnly = true;
            this.txt_course.Size = new System.Drawing.Size(197, 29);
            this.txt_course.TabIndex = 87;
            // 
            // txt_dept
            // 
            this.txt_dept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_dept.BackColor = System.Drawing.SystemColors.Window;
            this.txt_dept.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dept.Location = new System.Drawing.Point(213, 393);
            this.txt_dept.Name = "txt_dept";
            this.txt_dept.ReadOnly = true;
            this.txt_dept.Size = new System.Drawing.Size(197, 29);
            this.txt_dept.TabIndex = 86;
            // 
            // lbl_course
            // 
            this.lbl_course.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_course.AutoSize = true;
            this.lbl_course.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course.ForeColor = System.Drawing.Color.Black;
            this.lbl_course.Location = new System.Drawing.Point(16, 525);
            this.lbl_course.Name = "lbl_course";
            this.lbl_course.Size = new System.Drawing.Size(83, 24);
            this.lbl_course.TabIndex = 84;
            this.lbl_course.Text = "Course:";
            // 
            // txt_email
            // 
            this.txt_email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_email.BackColor = System.Drawing.SystemColors.Window;
            this.txt_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.Location = new System.Drawing.Point(213, 436);
            this.txt_email.Name = "txt_email";
            this.txt_email.ReadOnly = true;
            this.txt_email.Size = new System.Drawing.Size(199, 29);
            this.txt_email.TabIndex = 80;
            // 
            // lbl_smobile
            // 
            this.lbl_smobile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_smobile.AutoSize = true;
            this.lbl_smobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_smobile.ForeColor = System.Drawing.Color.Black;
            this.lbl_smobile.Location = new System.Drawing.Point(16, 482);
            this.lbl_smobile.Name = "lbl_smobile";
            this.lbl_smobile.Size = new System.Drawing.Size(143, 24);
            this.lbl_smobile.TabIndex = 82;
            this.lbl_smobile.Text = "User\'s Mobile:";
            // 
            // lbl_semail
            // 
            this.lbl_semail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_semail.AutoSize = true;
            this.lbl_semail.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_semail.ForeColor = System.Drawing.Color.Black;
            this.lbl_semail.Location = new System.Drawing.Point(16, 439);
            this.lbl_semail.Name = "lbl_semail";
            this.lbl_semail.Size = new System.Drawing.Size(132, 24);
            this.lbl_semail.TabIndex = 81;
            this.lbl_semail.Text = "User\'s Email:";
            // 
            // txt_mobile
            // 
            this.txt_mobile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_mobile.BackColor = System.Drawing.SystemColors.Window;
            this.txt_mobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mobile.Location = new System.Drawing.Point(213, 479);
            this.txt_mobile.Name = "txt_mobile";
            this.txt_mobile.ReadOnly = true;
            this.txt_mobile.Size = new System.Drawing.Size(199, 29);
            this.txt_mobile.TabIndex = 79;
            // 
            // lbl_sdept
            // 
            this.lbl_sdept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sdept.AutoSize = true;
            this.lbl_sdept.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sdept.ForeColor = System.Drawing.Color.Black;
            this.lbl_sdept.Location = new System.Drawing.Point(16, 397);
            this.lbl_sdept.Name = "lbl_sdept";
            this.lbl_sdept.Size = new System.Drawing.Size(108, 24);
            this.lbl_sdept.TabIndex = 77;
            this.lbl_sdept.Text = "User Dept:";
            // 
            // lbl_sname
            // 
            this.lbl_sname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sname.AutoSize = true;
            this.lbl_sname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sname.ForeColor = System.Drawing.Color.Black;
            this.lbl_sname.Location = new System.Drawing.Point(16, 353);
            this.lbl_sname.Name = "lbl_sname";
            this.lbl_sname.Size = new System.Drawing.Size(197, 24);
            this.lbl_sname.TabIndex = 39;
            this.lbl_sname.Text = "User/Student Name:";
            // 
            // txt_name
            // 
            this.txt_name.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_name.BackColor = System.Drawing.SystemColors.Window;
            this.txt_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name.Location = new System.Drawing.Point(213, 350);
            this.txt_name.Name = "txt_name";
            this.txt_name.ReadOnly = true;
            this.txt_name.Size = new System.Drawing.Size(197, 29);
            this.txt_name.TabIndex = 38;
            // 
            // lbl_head
            // 
            this.lbl_head.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_head.AutoSize = true;
            this.lbl_head.Font = new System.Drawing.Font("Segoe UI Black", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.lbl_head.Location = new System.Drawing.Point(502, 27);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(224, 37);
            this.lbl_head.TabIndex = 110;
            this.lbl_head.Text = "Book Withdraw";
            // 
            // lbl_QR
            // 
            this.lbl_QR.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_QR.AutoSize = true;
            this.lbl_QR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_QR.ForeColor = System.Drawing.Color.Black;
            this.lbl_QR.Location = new System.Drawing.Point(67, 183);
            this.lbl_QR.Name = "lbl_QR";
            this.lbl_QR.Size = new System.Drawing.Size(138, 20);
            this.lbl_QR.TabIndex = 116;
            this.lbl_QR.Text = "User\'s QR Code";
            // 
            // lbl_bar
            // 
            this.lbl_bar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bar.AutoSize = true;
            this.lbl_bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bar.ForeColor = System.Drawing.Color.Black;
            this.lbl_bar.Location = new System.Drawing.Point(71, 311);
            this.lbl_bar.Name = "lbl_bar";
            this.lbl_bar.Size = new System.Drawing.Size(130, 20);
            this.lbl_bar.TabIndex = 114;
            this.lbl_bar.Text = "Book Bar Code";
            // 
            // pnl_Student
            // 
            this.pnl_Student.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_Student.Controls.Add(this.pnl_StudentTop);
            this.pnl_Student.Controls.Add(this.pnl_StudentBottom);
            this.pnl_Student.Controls.Add(this.pnl_StudentRight);
            this.pnl_Student.Controls.Add(this.pnl_StudentLeft);
            this.pnl_Student.Controls.Add(this.txt_stu_id);
            this.pnl_Student.Controls.Add(this.txt_name);
            this.pnl_Student.Controls.Add(this.lbl_sname);
            this.pnl_Student.Controls.Add(this.lbl_sdept);
            this.pnl_Student.Controls.Add(this.pnl_PB);
            this.pnl_Student.Controls.Add(this.txt_mobile);
            this.pnl_Student.Controls.Add(this.lbl_semail);
            this.pnl_Student.Controls.Add(this.lbl_user);
            this.pnl_Student.Controls.Add(this.lbl_smobile);
            this.pnl_Student.Controls.Add(this.txt_course);
            this.pnl_Student.Controls.Add(this.txt_email);
            this.pnl_Student.Controls.Add(this.txt_dept);
            this.pnl_Student.Controls.Add(this.lbl_course);
            this.pnl_Student.Location = new System.Drawing.Point(301, 85);
            this.pnl_Student.Name = "pnl_Student";
            this.pnl_Student.Size = new System.Drawing.Size(425, 580);
            this.pnl_Student.TabIndex = 112;
            // 
            // pnl_StudentTop
            // 
            this.pnl_StudentTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_StudentTop.Location = new System.Drawing.Point(3, 0);
            this.pnl_StudentTop.Name = "pnl_StudentTop";
            this.pnl_StudentTop.Size = new System.Drawing.Size(419, 3);
            this.pnl_StudentTop.TabIndex = 122;
            // 
            // pnl_StudentBottom
            // 
            this.pnl_StudentBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_StudentBottom.Location = new System.Drawing.Point(3, 577);
            this.pnl_StudentBottom.Name = "pnl_StudentBottom";
            this.pnl_StudentBottom.Size = new System.Drawing.Size(419, 3);
            this.pnl_StudentBottom.TabIndex = 121;
            // 
            // pnl_StudentRight
            // 
            this.pnl_StudentRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_StudentRight.Location = new System.Drawing.Point(422, 0);
            this.pnl_StudentRight.Name = "pnl_StudentRight";
            this.pnl_StudentRight.Size = new System.Drawing.Size(3, 580);
            this.pnl_StudentRight.TabIndex = 120;
            // 
            // pnl_StudentLeft
            // 
            this.pnl_StudentLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_StudentLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_StudentLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_StudentLeft.Name = "pnl_StudentLeft";
            this.pnl_StudentLeft.Size = new System.Drawing.Size(3, 580);
            this.pnl_StudentLeft.TabIndex = 119;
            // 
            // pnl_Search
            // 
            this.pnl_Search.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_Search.Controls.Add(this.btn_clear);
            this.pnl_Search.Controls.Add(this.pnl_SearchBottom);
            this.pnl_Search.Controls.Add(this.pnl_SearchRight);
            this.pnl_Search.Controls.Add(this.pnl_SearchTop);
            this.pnl_Search.Controls.Add(this.pnl_SearchLeft);
            this.pnl_Search.Controls.Add(this.btn_usearch);
            this.pnl_Search.Controls.Add(this.lbl_sid);
            this.pnl_Search.Controls.Add(this.txt_UserID);
            this.pnl_Search.Location = new System.Drawing.Point(15, 85);
            this.pnl_Search.Name = "pnl_Search";
            this.pnl_Search.Size = new System.Drawing.Size(273, 144);
            this.pnl_Search.TabIndex = 113;
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_clear.BackColor = System.Drawing.Color.Red;
            this.btn_clear.FlatAppearance.BorderSize = 0;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.White;
            this.btn_clear.Image = global::Library.Properties.Resources.Clear;
            this.btn_clear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_clear.Location = new System.Drawing.Point(120, 101);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(96, 29);
            this.btn_clear.TabIndex = 126;
            this.btn_clear.Text = "  Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // pnl_SearchBottom
            // 
            this.pnl_SearchBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_SearchBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_SearchBottom.Location = new System.Drawing.Point(3, 141);
            this.pnl_SearchBottom.Name = "pnl_SearchBottom";
            this.pnl_SearchBottom.Size = new System.Drawing.Size(267, 3);
            this.pnl_SearchBottom.TabIndex = 125;
            // 
            // pnl_SearchRight
            // 
            this.pnl_SearchRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_SearchRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_SearchRight.Location = new System.Drawing.Point(270, 3);
            this.pnl_SearchRight.Name = "pnl_SearchRight";
            this.pnl_SearchRight.Size = new System.Drawing.Size(3, 141);
            this.pnl_SearchRight.TabIndex = 124;
            // 
            // pnl_SearchTop
            // 
            this.pnl_SearchTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_SearchTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_SearchTop.Location = new System.Drawing.Point(3, 0);
            this.pnl_SearchTop.Name = "pnl_SearchTop";
            this.pnl_SearchTop.Size = new System.Drawing.Size(270, 3);
            this.pnl_SearchTop.TabIndex = 123;
            // 
            // pnl_SearchLeft
            // 
            this.pnl_SearchLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_SearchLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_SearchLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_SearchLeft.Name = "pnl_SearchLeft";
            this.pnl_SearchLeft.Size = new System.Drawing.Size(3, 144);
            this.pnl_SearchLeft.TabIndex = 120;
            // 
            // btn_usearch
            // 
            this.btn_usearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_usearch.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_usearch.FlatAppearance.BorderSize = 0;
            this.btn_usearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_usearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_usearch.ForeColor = System.Drawing.Color.White;
            this.btn_usearch.Image = global::Library.Properties.Resources.search;
            this.btn_usearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_usearch.Location = new System.Drawing.Point(120, 66);
            this.btn_usearch.Name = "btn_usearch";
            this.btn_usearch.Size = new System.Drawing.Size(96, 29);
            this.btn_usearch.TabIndex = 110;
            this.btn_usearch.Text = "Search";
            this.btn_usearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_usearch.UseVisualStyleBackColor = false;
            this.btn_usearch.Click += new System.EventHandler(this.btn_usearch_Click);
            // 
            // pnl_book
            // 
            this.pnl_book.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_book.Controls.Add(this.lbl_sendmail);
            this.pnl_book.Controls.Add(this.bunifuSend);
            this.pnl_book.Controls.Add(this.pnl_BookBottom);
            this.pnl_book.Controls.Add(this.pnl_BookTop);
            this.pnl_book.Controls.Add(this.pnl_BookRight);
            this.pnl_book.Controls.Add(this.pnl_BookLeft);
            this.pnl_book.Controls.Add(this.btn_bsearch);
            this.pnl_book.Controls.Add(this.txt_bname);
            this.pnl_book.Controls.Add(this.txt_barcode);
            this.pnl_book.Controls.Add(this.lbl_bname);
            this.pnl_book.Controls.Add(this.lbl_barcode);
            this.pnl_book.Controls.Add(this.lbl_author);
            this.pnl_book.Controls.Add(this.txt_category);
            this.pnl_book.Controls.Add(this.txt_isbn);
            this.pnl_book.Controls.Add(this.lbl_publisher);
            this.pnl_book.Controls.Add(this.btn_issue);
            this.pnl_book.Controls.Add(this.lbl_isbn);
            this.pnl_book.Controls.Add(this.lbl_Bookreturn);
            this.pnl_book.Controls.Add(this.txt_publisher);
            this.pnl_book.Controls.Add(this.txt_return);
            this.pnl_book.Controls.Add(this.lbl_price);
            this.pnl_book.Controls.Add(this.txt_BookID);
            this.pnl_book.Controls.Add(this.lbl_category);
            this.pnl_book.Controls.Add(this.lbl_bid);
            this.pnl_book.Controls.Add(this.txt_price);
            this.pnl_book.Controls.Add(this.txt_author);
            this.pnl_book.Location = new System.Drawing.Point(739, 85);
            this.pnl_book.Name = "pnl_book";
            this.pnl_book.Size = new System.Drawing.Size(445, 580);
            this.pnl_book.TabIndex = 114;
            // 
            // lbl_sendmail
            // 
            this.lbl_sendmail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_sendmail.AutoSize = true;
            this.lbl_sendmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sendmail.ForeColor = System.Drawing.Color.Black;
            this.lbl_sendmail.Location = new System.Drawing.Point(17, 535);
            this.lbl_sendmail.Name = "lbl_sendmail";
            this.lbl_sendmail.Size = new System.Drawing.Size(109, 24);
            this.lbl_sendmail.TabIndex = 126;
            this.lbl_sendmail.Text = "Send Mail:";
            // 
            // bunifuSend
            // 
            this.bunifuSend.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuSend.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuSend.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuSend.Checked = false;
            this.bunifuSend.CheckedOnColor = System.Drawing.Color.SeaGreen;
            this.bunifuSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuSend.ForeColor = System.Drawing.Color.White;
            this.bunifuSend.Location = new System.Drawing.Point(194, 535);
            this.bunifuSend.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuSend.Name = "bunifuSend";
            this.bunifuSend.Size = new System.Drawing.Size(20, 20);
            this.bunifuSend.TabIndex = 125;
            // 
            // pnl_BookBottom
            // 
            this.pnl_BookBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_BookBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_BookBottom.Location = new System.Drawing.Point(3, 577);
            this.pnl_BookBottom.Name = "pnl_BookBottom";
            this.pnl_BookBottom.Size = new System.Drawing.Size(439, 3);
            this.pnl_BookBottom.TabIndex = 124;
            // 
            // pnl_BookTop
            // 
            this.pnl_BookTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_BookTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_BookTop.Location = new System.Drawing.Point(3, 0);
            this.pnl_BookTop.Name = "pnl_BookTop";
            this.pnl_BookTop.Size = new System.Drawing.Size(439, 3);
            this.pnl_BookTop.TabIndex = 123;
            // 
            // pnl_BookRight
            // 
            this.pnl_BookRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_BookRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_BookRight.Location = new System.Drawing.Point(442, 0);
            this.pnl_BookRight.Name = "pnl_BookRight";
            this.pnl_BookRight.Size = new System.Drawing.Size(3, 580);
            this.pnl_BookRight.TabIndex = 121;
            // 
            // pnl_BookLeft
            // 
            this.pnl_BookLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_BookLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_BookLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_BookLeft.Name = "pnl_BookLeft";
            this.pnl_BookLeft.Size = new System.Drawing.Size(3, 580);
            this.pnl_BookLeft.TabIndex = 120;
            // 
            // btn_bsearch
            // 
            this.btn_bsearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_bsearch.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_bsearch.FlatAppearance.BorderSize = 0;
            this.btn_bsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bsearch.ForeColor = System.Drawing.Color.White;
            this.btn_bsearch.Image = global::Library.Properties.Resources.search;
            this.btn_bsearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_bsearch.Location = new System.Drawing.Point(184, 101);
            this.btn_bsearch.Name = "btn_bsearch";
            this.btn_bsearch.Size = new System.Drawing.Size(94, 29);
            this.btn_bsearch.TabIndex = 110;
            this.btn_bsearch.Text = "    Search";
            this.btn_bsearch.UseVisualStyleBackColor = false;
            this.btn_bsearch.Click += new System.EventHandler(this.btn_bsearch_Click);
            // 
            // pnl_QR_Bar
            // 
            this.pnl_QR_Bar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_QR_Bar.Controls.Add(this.pb_qrcode);
            this.pnl_QR_Bar.Controls.Add(this.rtxt_address);
            this.pnl_QR_Bar.Controls.Add(this.txt_qrcode);
            this.pnl_QR_Bar.Controls.Add(this.lbl_saveinfo);
            this.pnl_QR_Bar.Controls.Add(this.pnl_QRbottom);
            this.pnl_QR_Bar.Controls.Add(this.lbl_QR);
            this.pnl_QR_Bar.Controls.Add(this.pnl_QRright);
            this.pnl_QR_Bar.Controls.Add(this.pnl_QRtop);
            this.pnl_QR_Bar.Controls.Add(this.pnl_QRleft);
            this.pnl_QR_Bar.Controls.Add(this.lbl_bar);
            this.pnl_QR_Bar.Controls.Add(this.pb_bar);
            this.pnl_QR_Bar.Location = new System.Drawing.Point(15, 244);
            this.pnl_QR_Bar.Name = "pnl_QR_Bar";
            this.pnl_QR_Bar.Size = new System.Drawing.Size(273, 421);
            this.pnl_QR_Bar.TabIndex = 117;
            // 
            // pb_qrcode
            // 
            this.pb_qrcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_qrcode.BackColor = System.Drawing.Color.Crimson;
            this.pb_qrcode.Image = global::Library.Properties.Resources.QR_pb_box;
            this.pb_qrcode.Location = new System.Drawing.Point(77, 59);
            this.pb_qrcode.Name = "pb_qrcode";
            this.pb_qrcode.Size = new System.Drawing.Size(120, 120);
            this.pb_qrcode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_qrcode.TabIndex = 115;
            this.pb_qrcode.TabStop = false;
            // 
            // rtxt_address
            // 
            this.rtxt_address.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rtxt_address.Location = new System.Drawing.Point(95, 127);
            this.rtxt_address.Name = "rtxt_address";
            this.rtxt_address.Size = new System.Drawing.Size(87, 41);
            this.rtxt_address.TabIndex = 123;
            this.rtxt_address.Text = "";
            // 
            // txt_qrcode
            // 
            this.txt_qrcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_qrcode.BackColor = System.Drawing.SystemColors.Window;
            this.txt_qrcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_qrcode.ForeColor = System.Drawing.Color.Black;
            this.txt_qrcode.Location = new System.Drawing.Point(105, 85);
            this.txt_qrcode.Margin = new System.Windows.Forms.Padding(4);
            this.txt_qrcode.Name = "txt_qrcode";
            this.txt_qrcode.Size = new System.Drawing.Size(67, 29);
            this.txt_qrcode.TabIndex = 123;
            // 
            // lbl_saveinfo
            // 
            this.lbl_saveinfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_saveinfo.AutoSize = true;
            this.lbl_saveinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saveinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_saveinfo.Location = new System.Drawing.Point(9, 373);
            this.lbl_saveinfo.Name = "lbl_saveinfo";
            this.lbl_saveinfo.Size = new System.Drawing.Size(18, 24);
            this.lbl_saveinfo.TabIndex = 118;
            this.lbl_saveinfo.Text = "*";
            // 
            // pnl_QRbottom
            // 
            this.pnl_QRbottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_QRbottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_QRbottom.Location = new System.Drawing.Point(3, 418);
            this.pnl_QRbottom.Name = "pnl_QRbottom";
            this.pnl_QRbottom.Size = new System.Drawing.Size(267, 3);
            this.pnl_QRbottom.TabIndex = 125;
            // 
            // pnl_QRright
            // 
            this.pnl_QRright.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_QRright.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_QRright.Location = new System.Drawing.Point(270, 3);
            this.pnl_QRright.Name = "pnl_QRright";
            this.pnl_QRright.Size = new System.Drawing.Size(3, 418);
            this.pnl_QRright.TabIndex = 124;
            // 
            // pnl_QRtop
            // 
            this.pnl_QRtop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_QRtop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_QRtop.Location = new System.Drawing.Point(3, 0);
            this.pnl_QRtop.Name = "pnl_QRtop";
            this.pnl_QRtop.Size = new System.Drawing.Size(270, 3);
            this.pnl_QRtop.TabIndex = 123;
            // 
            // pnl_QRleft
            // 
            this.pnl_QRleft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_QRleft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_QRleft.Location = new System.Drawing.Point(0, 0);
            this.pnl_QRleft.Name = "pnl_QRleft";
            this.pnl_QRleft.Size = new System.Drawing.Size(3, 421);
            this.pnl_QRleft.TabIndex = 120;
            // 
            // pb_bar
            // 
            this.pb_bar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_bar.Image = global::Library.Properties.Resources.Barcode_70;
            this.pb_bar.Location = new System.Drawing.Point(36, 238);
            this.pb_bar.Name = "pb_bar";
            this.pb_bar.Size = new System.Drawing.Size(200, 70);
            this.pb_bar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_bar.TabIndex = 0;
            this.pb_bar.TabStop = false;
            // 
            // UC_withdraw
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.pnl_QR_Bar);
            this.Controls.Add(this.pnl_book);
            this.Controls.Add(this.pnl_Search);
            this.Controls.Add(this.pnl_Student);
            this.Controls.Add(this.lbl_head);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "UC_withdraw";
            this.Size = new System.Drawing.Size(1200, 700);
            this.Load += new System.EventHandler(this.UC_withdraw_Load);
            this.pnl_PB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_student)).EndInit();
            this.pnl_Student.ResumeLayout(false);
            this.pnl_Student.PerformLayout();
            this.pnl_Search.ResumeLayout(false);
            this.pnl_Search.PerformLayout();
            this.pnl_book.ResumeLayout(false);
            this.pnl_book.PerformLayout();
            this.pnl_QR_Bar.ResumeLayout(false);
            this.pnl_QR_Bar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_qrcode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_Bookreturn;
        private System.Windows.Forms.TextBox txt_return;
        private System.Windows.Forms.TextBox txt_BookID;
        private System.Windows.Forms.Label lbl_category;
        private System.Windows.Forms.Label lbl_bid;
        private System.Windows.Forms.TextBox txt_author;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.TextBox txt_publisher;
        private System.Windows.Forms.Label lbl_isbn;
        private System.Windows.Forms.Label lbl_publisher;
        private System.Windows.Forms.TextBox txt_isbn;
        private System.Windows.Forms.Label lbl_author;
        private System.Windows.Forms.Label lbl_bname;
        private System.Windows.Forms.TextBox txt_bname;
        private System.Windows.Forms.TextBox txt_UserID;
        private System.Windows.Forms.Label lbl_sid;
        private System.Windows.Forms.TextBox txt_stu_id;
        private System.Windows.Forms.Label lbl_user;
        private System.Windows.Forms.TextBox txt_course;
        private System.Windows.Forms.TextBox txt_dept;
        private System.Windows.Forms.Label lbl_course;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Label lbl_smobile;
        private System.Windows.Forms.Label lbl_semail;
        private System.Windows.Forms.TextBox txt_mobile;
        private System.Windows.Forms.Label lbl_sdept;
        private System.Windows.Forms.Label lbl_sname;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Button btn_bsearch;
        private System.Windows.Forms.Button btn_issue;
        private System.Windows.Forms.Button btn_usearch;
        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.PictureBox pb_bar;
        private System.Windows.Forms.TextBox txt_category;
        private System.Windows.Forms.TextBox txt_barcode;
        private System.Windows.Forms.Label lbl_barcode;
        private System.Windows.Forms.Label lbl_bar;
        private System.Windows.Forms.Label lbl_QR;
        private System.Windows.Forms.PictureBox pb_qrcode;
        private System.Windows.Forms.Panel pnl_PB;
        private System.Windows.Forms.Panel pnl_PBbottom;
        private System.Windows.Forms.Panel pnl_PBtop;
        private System.Windows.Forms.Panel pnl_PBleft;
        private System.Windows.Forms.Panel pnl_PBright;
        private System.Windows.Forms.PictureBox pb_student;
        private System.Windows.Forms.Panel pnl_Student;
        private System.Windows.Forms.Panel pnl_StudentTop;
        private System.Windows.Forms.Panel pnl_StudentBottom;
        private System.Windows.Forms.Panel pnl_StudentRight;
        private System.Windows.Forms.Panel pnl_StudentLeft;
        private System.Windows.Forms.Panel pnl_Search;
        private System.Windows.Forms.Panel pnl_SearchBottom;
        private System.Windows.Forms.Panel pnl_SearchRight;
        private System.Windows.Forms.Panel pnl_SearchTop;
        private System.Windows.Forms.Panel pnl_SearchLeft;
        private System.Windows.Forms.Panel pnl_book;
        private System.Windows.Forms.Panel pnl_BookBottom;
        private System.Windows.Forms.Panel pnl_BookTop;
        private System.Windows.Forms.Panel pnl_BookRight;
        private System.Windows.Forms.Panel pnl_BookLeft;
        private System.Windows.Forms.Panel pnl_QR_Bar;
        private System.Windows.Forms.Panel pnl_QRbottom;
        private System.Windows.Forms.Panel pnl_QRright;
        private System.Windows.Forms.Panel pnl_QRtop;
        private System.Windows.Forms.Panel pnl_QRleft;
        private System.Windows.Forms.Label lbl_saveinfo;
        private System.Windows.Forms.TextBox txt_qrcode;
        private System.Windows.Forms.RichTextBox rtxt_address;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Label lbl_sendmail;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuSend;
    }
}
