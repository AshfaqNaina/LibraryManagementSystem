﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;

namespace Library
{
    public partial class UC_withdraw : UserControl
    {
        public UC_withdraw()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        SqlDataReader dr;
        private void btn_issue_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_UserID.Text != "" && txt_BookID.Text != "")
                {
                    if (MessageBox.Show("Do you want to Issue the book", "Library Project", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.No)
                    {
                        con.Open();
                        cmd = new SqlCommand("insert into Withdraw(User_ID,Name,Course,Dept,Book_ID,Book_Name,Author,ISBN_No,Category,Barcode,Price,Issued_Date) values('" + txt_UserID.Text + "','" + txt_name.Text + "','" + txt_course.Text + "','" + txt_dept.Text + "','" + txt_BookID.Text + "','" + txt_bname.Text + "','" + txt_author.Text + "','" + txt_isbn.Text + "','" + txt_category.Text + "','" + txt_barcode.Text + "','" + txt_price.Text + "','" + System.DateTime.Now.ToString() + "')", con);
                        SqlCommand cmd1 = new SqlCommand("insert into Logs(User_ID,Name,Course,Dept,Book_ID,Book_Name,Author,ISBN_No,Category,Price,Issued_Date,Returned_Date) values('" + txt_UserID.Text + "','" + txt_name.Text + "','" + txt_course.Text + "','" + txt_dept.Text + "','" + txt_BookID.Text + "','" + txt_bname.Text + "','" + txt_author.Text + "','" + txt_isbn.Text + "','" + txt_category.Text + "','" + txt_price.Text + "','" +System.DateTime.Now.ToString()+ "','" + txt_return.Text + "')", con);
                        da = new SqlDataAdapter(cmd);
                        SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                        SqlCommand cmd2 = new SqlCommand("update Book set Quantity=Quantity-1 where Book_ID='" + txt_BookID.Text + "'",con);
                        SqlDataReader dr = cmd2.ExecuteReader();
                        dr.Close();
                        cmd.ExecuteNonQuery();
                        cmd1.ExecuteNonQuery();
                        lbl_saveinfo.Text = "Book Issued Successfully";
                        con.Close();
                    }
                    else
                    {
                        lbl_saveinfo.Text = "You Aborted....";
                        con.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter the Student ID and Book ID", "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    con.Close();
                }
            }
            catch (SqlException x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }

            if (bunifuSend.Checked == true)
            {
                string to;
                string from, pass, messageBody;
                MailMessage message = new MailMessage();
                to = (txt_email.Text).ToString();
                from = "libraryalertnotification@gmail.com";
                pass = "#Developers";
                string a = txt_name.Text;
                string b = txt_bname.Text;
                messageBody = "*Dear " + a + " You have taken " + b + " Book from library.... " +System.DateTime.Now.ToString()+ " Kindly return in 10 days, Your Welcome!!!";
                message.To.Add(to);
                message.From = new MailAddress(from);
                message.Body = messageBody;
                message.Subject = "Book take in Library";
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                smtp.EnableSsl = true;
                smtp.Port = 587;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Credentials = new NetworkCredential(from, pass);
                try
                {
                    smtp.Send(message);
                }
                catch (Exception)
                {
                    MessageBox.Show("Network problem contact admin", "Library Soft");
                }
            }
        }
        public void clear()
        {
            txt_name.Clear();
            txt_mobile.Clear();
            txt_UserID.Clear();
            txt_course.Clear();
            txt_dept.Clear();
            txt_email.Clear();
        }

        public void bclear()
        {
            txt_author.Clear();
            txt_BookID.Clear();
            txt_category.Clear();
            txt_isbn.Clear();
            txt_bname.Clear();
            txt_price.Clear();
            txt_publisher.Clear();
        }


        private void btn_usearch_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select * from Users where User_ID='" + txt_UserID.Text + "'", con);
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txt_stu_id.Text = dr.GetValue(1).ToString();
                    txt_name.Text = dr.GetValue(2).ToString();
                    rtxt_address.Text = dr.GetValue(3).ToString();
                    txt_course.Text = dr.GetValue(4).ToString();
                    txt_dept.Text = dr.GetValue(5).ToString();
                    txt_email.Text = dr.GetValue(7).ToString();
                    txt_mobile.Text = dr.GetValue(8).ToString();
                    dr.Close();
                    //image loading code
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    byte[] image = (byte[])dt.Rows[0][11];
                    MemoryStream ms = new MemoryStream(image);
                    pb_student.Image = Image.FromStream(ms);
                    this.Refresh();
                    con.Close();
                    ///
                    txt_qrcode.Text = "User Id=" + txt_UserID.Text + "%" + txt_name.Text + "%" + rtxt_address.Text + "%" + txt_mobile.Text + "%" + txt_email.Text + "";
                    Zen.Barcode.CodeQrBarcodeDraw qrCode = Zen.Barcode.BarcodeDrawFactory.CodeQr;
                    pb_qrcode.BackColor = Color.Transparent;
                    pb_qrcode.Image = qrCode.Draw(txt_qrcode.Text, 60);
                }
                else
                {
                    MessageBox.Show("No Record Found in the Library DataBase", "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    clear();
                    txt_UserID.Focus();
                    con.Close();
                }
            }
            catch(SqlException x)
            {
                MessageBox.Show("Error" + x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
            lbl_saveinfo.Text = "";
        }

        private void btn_bsearch_Click(object sender, EventArgs e)
        {
            try
            { 
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from Book where Book_ID='" + txt_BookID.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txt_bname.Text = dr.GetValue(2).ToString();
                    txt_author.Text = dr.GetValue(3).ToString();
                    txt_publisher.Text = dr.GetValue(4).ToString();
                    txt_isbn.Text = dr.GetValue(5).ToString();
                    txt_barcode.Text = dr.GetValue(9).ToString();
                    txt_category.Text = dr.GetValue(6).ToString();
                    txt_price.Text = dr.GetValue(7).ToString();
                    txt_return.Text = "Return in 10 Days";
                    string barCode = txt_barcode.Text;
                    try
                    {
                        Zen.Barcode.Code128BarcodeDraw brCode = Zen.Barcode.BarcodeDrawFactory.Code128WithChecksum;
                        pb_bar.BackColor = Color.Transparent;
                        pb_bar.Image = brCode.Draw(barCode, 60);
                    }
                    catch (Exception x)
                    {
                        MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("No Record Found in the Library DataBase", "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    bclear();
                    txt_BookID.Focus();
                }
                con.Close();
            }
            catch (SqlException x)
            {
                MessageBox.Show("Error" + x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                con.Close();
            }
            lbl_saveinfo.Text = "";
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_bname.Clear();
            txt_isbn.Clear();
            txt_price.Clear();
            txt_publisher.Clear();
            txt_author.Clear();
            lbl_saveinfo.Text = "";
            txt_barcode.Clear();
            txt_email.Clear();
            txt_mobile.Clear();
            txt_name.Clear();
            txt_qrcode.Clear();
            txt_UserID.Clear();
            rtxt_address.Clear();
            lbl_saveinfo.Text = "";
            txt_course.Clear();
            txt_category.Clear();
            txt_stu_id.Clear();
            txt_dept.Clear();
            txt_return.Clear();
            //
            con.Open();
            cmd = new SqlCommand("select * from Res_Images where Id=4", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            byte[] image = (byte[])dt.Rows[0][1];
            MemoryStream ms = new MemoryStream(image);
            pb_bar.Image = Image.FromStream(ms);

            SqlCommand cmd1 = new SqlCommand("select * from Res_Images  where Id=3", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            byte[] image1 = (byte[])dt1.Rows[0][1];
            MemoryStream ms1 = new MemoryStream(image1);
            pb_qrcode.Image = Image.FromStream(ms1);
            pb_qrcode.BackColor = Color.Crimson;

            SqlCommand cmd2 = new SqlCommand("select * from Res_Images  where Id=1", con);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);
            byte[] image2 = (byte[])dt2.Rows[0][1];
            MemoryStream ms2 = new MemoryStream(image2);
            pb_student.Image = Image.FromStream(ms2);
            con.Close();
        }

        private void UC_withdraw_Load(object sender, EventArgs e)
        {
            lbl_saveinfo.Text = "";
        }
    }
}
