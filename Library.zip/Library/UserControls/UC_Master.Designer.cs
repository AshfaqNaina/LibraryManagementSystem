﻿namespace Library.UserControls
{
    partial class UC_Master
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lbl_data = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txt_adminpass = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txt_username = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btn_DStudent = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_bid = new System.Windows.Forms.Label();
            this.lbl_bname = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Dbook = new System.Windows.Forms.Button();
            this.btn_DLogin = new System.Windows.Forms.Button();
            this.lbl_saveinfo = new System.Windows.Forms.Label();
            this.btn_DLogs = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pnl_book = new System.Windows.Forms.Panel();
            this.btn_Logs = new System.Windows.Forms.Button();
            this.btn_users = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.btn_view = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.txt_Uname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnl_BookRight = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnl_BookTop = new System.Windows.Forms.Panel();
            this.pnl_Database = new System.Windows.Forms.Panel();
            this.pnl_Login = new System.Windows.Forms.Panel();
            this.pnl_truncate = new System.Windows.Forms.Panel();
            this.lbl_admin = new System.Windows.Forms.Label();
            this.btn_cadminpass = new System.Windows.Forms.Button();
            this.btn_DWithdraw = new System.Windows.Forms.Button();
            this.pnl_cadminpass = new System.Windows.Forms.Panel();
            this.txt_nApass = new System.Windows.Forms.TextBox();
            this.btn_exit = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txt_nuser = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_clear1 = new System.Windows.Forms.Button();
            this.lbl_status = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btn_ok = new System.Windows.Forms.Button();
            this.btn_login_logs = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_lock = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.pnl_book.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnl_Database.SuspendLayout();
            this.pnl_Login.SuspendLayout();
            this.pnl_truncate.SuspendLayout();
            this.pnl_cadminpass.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel11.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel11.Location = new System.Drawing.Point(3, 472);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(504, 3);
            this.panel11.TabIndex = 202;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(3, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(507, 3);
            this.panel9.TabIndex = 200;
            // 
            // lbl_data
            // 
            this.lbl_data.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_data.AutoSize = true;
            this.lbl_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_data.ForeColor = System.Drawing.Color.Black;
            this.lbl_data.Location = new System.Drawing.Point(133, 53);
            this.lbl_data.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_data.Name = "lbl_data";
            this.lbl_data.Size = new System.Drawing.Size(235, 29);
            this.lbl_data.TabIndex = 179;
            this.lbl_data.Text = "DataBase Truncate";
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel12.Location = new System.Drawing.Point(237, 265);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(177, 3);
            this.panel12.TabIndex = 178;
            // 
            // txt_adminpass
            // 
            this.txt_adminpass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_adminpass.BackColor = System.Drawing.SystemColors.Control;
            this.txt_adminpass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_adminpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_adminpass.Location = new System.Drawing.Point(237, 239);
            this.txt_adminpass.Name = "txt_adminpass";
            this.txt_adminpass.PasswordChar = '*';
            this.txt_adminpass.Size = new System.Drawing.Size(177, 19);
            this.txt_adminpass.TabIndex = 157;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(75, 239);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 20);
            this.label2.TabIndex = 177;
            this.label2.Text = "Admin Password:";
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_clear.BackColor = System.Drawing.Color.Red;
            this.btn_clear.FlatAppearance.BorderSize = 0;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.White;
            this.btn_clear.Location = new System.Drawing.Point(280, 336);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(79, 42);
            this.btn_clear.TabIndex = 159;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_login
            // 
            this.btn_login.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_login.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_login.FlatAppearance.BorderSize = 0;
            this.btn_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.ForeColor = System.Drawing.Color.White;
            this.btn_login.Location = new System.Drawing.Point(146, 336);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(79, 42);
            this.btn_login.TabIndex = 158;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // panel16
            // 
            this.panel16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel16.Location = new System.Drawing.Point(237, 198);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(177, 3);
            this.panel16.TabIndex = 163;
            // 
            // txt_username
            // 
            this.txt_username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_username.BackColor = System.Drawing.SystemColors.Control;
            this.txt_username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_username.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_username.Location = new System.Drawing.Point(237, 172);
            this.txt_username.Name = "txt_username";
            this.txt_username.Size = new System.Drawing.Size(177, 19);
            this.txt_username.TabIndex = 155;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(75, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 20);
            this.label4.TabIndex = 160;
            this.label4.Text = "Username:";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel10.Location = new System.Drawing.Point(507, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(3, 472);
            this.panel10.TabIndex = 201;
            // 
            // btn_DStudent
            // 
            this.btn_DStudent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DStudent.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_DStudent.FlatAppearance.BorderSize = 0;
            this.btn_DStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DStudent.ForeColor = System.Drawing.Color.White;
            this.btn_DStudent.Location = new System.Drawing.Point(259, 74);
            this.btn_DStudent.Name = "btn_DStudent";
            this.btn_DStudent.Size = new System.Drawing.Size(148, 31);
            this.btn_DStudent.TabIndex = 158;
            this.btn_DStudent.Text = "Delete Data";
            this.btn_DStudent.UseVisualStyleBackColor = false;
            this.btn_DStudent.Click += new System.EventHandler(this.btn_DStudent_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(54, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 20);
            this.label3.TabIndex = 169;
            this.label3.Text = "Student Details";
            // 
            // lbl_bid
            // 
            this.lbl_bid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bid.AutoSize = true;
            this.lbl_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_bid.Location = new System.Drawing.Point(54, 182);
            this.lbl_bid.Name = "lbl_bid";
            this.lbl_bid.Size = new System.Drawing.Size(94, 20);
            this.lbl_bid.TabIndex = 160;
            this.lbl_bid.Text = "Book Logs";
            // 
            // lbl_bname
            // 
            this.lbl_bname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_bname.AutoSize = true;
            this.lbl_bname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_bname.Location = new System.Drawing.Point(54, 131);
            this.lbl_bname.Name = "lbl_bname";
            this.lbl_bname.Size = new System.Drawing.Size(147, 20);
            this.lbl_bname.TabIndex = 161;
            this.lbl_bname.Text = "WithDraw Details";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(54, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 20);
            this.label1.TabIndex = 164;
            this.label1.Text = "Book Details";
            // 
            // btn_Dbook
            // 
            this.btn_Dbook.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Dbook.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_Dbook.FlatAppearance.BorderSize = 0;
            this.btn_Dbook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Dbook.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dbook.ForeColor = System.Drawing.Color.White;
            this.btn_Dbook.Location = new System.Drawing.Point(259, 23);
            this.btn_Dbook.Name = "btn_Dbook";
            this.btn_Dbook.Size = new System.Drawing.Size(148, 31);
            this.btn_Dbook.TabIndex = 180;
            this.btn_Dbook.Text = "Delete Data";
            this.btn_Dbook.UseVisualStyleBackColor = false;
            this.btn_Dbook.Click += new System.EventHandler(this.btn_Dbook_Click);
            // 
            // btn_DLogin
            // 
            this.btn_DLogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DLogin.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_DLogin.FlatAppearance.BorderSize = 0;
            this.btn_DLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DLogin.ForeColor = System.Drawing.Color.White;
            this.btn_DLogin.Location = new System.Drawing.Point(259, 227);
            this.btn_DLogin.Name = "btn_DLogin";
            this.btn_DLogin.Size = new System.Drawing.Size(148, 31);
            this.btn_DLogin.TabIndex = 183;
            this.btn_DLogin.Text = "Delete Data";
            this.btn_DLogin.UseVisualStyleBackColor = false;
            this.btn_DLogin.Click += new System.EventHandler(this.btn_DLogin_Click);
            // 
            // lbl_saveinfo
            // 
            this.lbl_saveinfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_saveinfo.AutoSize = true;
            this.lbl_saveinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saveinfo.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_saveinfo.Location = new System.Drawing.Point(63, 386);
            this.lbl_saveinfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_saveinfo.Name = "lbl_saveinfo";
            this.lbl_saveinfo.Size = new System.Drawing.Size(15, 18);
            this.lbl_saveinfo.TabIndex = 185;
            this.lbl_saveinfo.Text = "*";
            // 
            // btn_DLogs
            // 
            this.btn_DLogs.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DLogs.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_DLogs.FlatAppearance.BorderSize = 0;
            this.btn_DLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DLogs.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DLogs.ForeColor = System.Drawing.Color.White;
            this.btn_DLogs.Location = new System.Drawing.Point(259, 176);
            this.btn_DLogs.Name = "btn_DLogs";
            this.btn_DLogs.Size = new System.Drawing.Size(148, 31);
            this.btn_DLogs.TabIndex = 182;
            this.btn_DLogs.Text = "Delete Data";
            this.btn_DLogs.UseVisualStyleBackColor = false;
            this.btn_DLogs.Click += new System.EventHandler(this.btn_DLogs_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(54, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 20);
            this.label5.TabIndex = 177;
            this.label5.Text = "Login Details";
            // 
            // dgv
            // 
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(50, 92);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(535, 231);
            this.dgv.TabIndex = 206;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(3, 475);
            this.panel8.TabIndex = 199;
            // 
            // pnl_book
            // 
            this.pnl_book.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_book.BackColor = System.Drawing.SystemColors.Control;
            this.pnl_book.Controls.Add(this.dgv);
            this.pnl_book.Controls.Add(this.btn_Logs);
            this.pnl_book.Controls.Add(this.btn_users);
            this.pnl_book.Controls.Add(this.panel15);
            this.pnl_book.Controls.Add(this.panel13);
            this.pnl_book.Controls.Add(this.panel1);
            this.pnl_book.Controls.Add(this.panel3);
            this.pnl_book.Controls.Add(this.pnl_BookRight);
            this.pnl_book.Controls.Add(this.panel2);
            this.pnl_book.Controls.Add(this.pnl_BookTop);
            this.pnl_book.Controls.Add(this.pnl_Database);
            this.pnl_book.Location = new System.Drawing.Point(17, 65);
            this.pnl_book.Name = "pnl_book";
            this.pnl_book.Size = new System.Drawing.Size(1167, 590);
            this.pnl_book.TabIndex = 116;
            // 
            // btn_Logs
            // 
            this.btn_Logs.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Logs.BackColor = System.Drawing.Color.Orange;
            this.btn_Logs.FlatAppearance.BorderSize = 0;
            this.btn_Logs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Logs.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Logs.ForeColor = System.Drawing.Color.White;
            this.btn_Logs.Location = new System.Drawing.Point(334, 341);
            this.btn_Logs.Name = "btn_Logs";
            this.btn_Logs.Size = new System.Drawing.Size(155, 42);
            this.btn_Logs.TabIndex = 205;
            this.btn_Logs.Text = "Login Details";
            this.btn_Logs.UseVisualStyleBackColor = false;
            this.btn_Logs.Click += new System.EventHandler(this.btn_Logs_Click);
            // 
            // btn_users
            // 
            this.btn_users.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_users.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_users.FlatAppearance.BorderSize = 0;
            this.btn_users.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_users.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_users.ForeColor = System.Drawing.Color.White;
            this.btn_users.Location = new System.Drawing.Point(156, 341);
            this.btn_users.Name = "btn_users";
            this.btn_users.Size = new System.Drawing.Size(141, 42);
            this.btn_users.TabIndex = 204;
            this.btn_users.Text = "User Data";
            this.btn_users.UseVisualStyleBackColor = false;
            this.btn_users.Click += new System.EventHandler(this.btn_users_Click);
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.btn_view);
            this.panel15.Controls.Add(this.btn_delete);
            this.panel15.Controls.Add(this.panel21);
            this.panel15.Controls.Add(this.txt_Uname);
            this.panel15.Controls.Add(this.label9);
            this.panel15.Controls.Add(this.panel17);
            this.panel15.Controls.Add(this.panel18);
            this.panel15.Controls.Add(this.panel19);
            this.panel15.Controls.Add(this.panel20);
            this.panel15.Location = new System.Drawing.Point(50, 402);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(538, 165);
            this.panel15.TabIndex = 197;
            // 
            // btn_view
            // 
            this.btn_view.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_view.BackColor = System.Drawing.Color.Navy;
            this.btn_view.FlatAppearance.BorderSize = 0;
            this.btn_view.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_view.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_view.ForeColor = System.Drawing.Color.White;
            this.btn_view.Location = new System.Drawing.Point(283, 98);
            this.btn_view.Name = "btn_view";
            this.btn_view.Size = new System.Drawing.Size(81, 42);
            this.btn_view.TabIndex = 203;
            this.btn_view.Text = "View";
            this.btn_view.UseVisualStyleBackColor = false;
            this.btn_view.Click += new System.EventHandler(this.btn_view_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_delete.BackColor = System.Drawing.Color.Red;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Location = new System.Drawing.Point(176, 98);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(79, 42);
            this.btn_delete.TabIndex = 202;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // panel21
            // 
            this.panel21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel21.Location = new System.Drawing.Point(212, 70);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(226, 3);
            this.panel21.TabIndex = 201;
            // 
            // txt_Uname
            // 
            this.txt_Uname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Uname.BackColor = System.Drawing.SystemColors.Control;
            this.txt_Uname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Uname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Uname.Location = new System.Drawing.Point(212, 44);
            this.txt_Uname.Name = "txt_Uname";
            this.txt_Uname.Size = new System.Drawing.Size(226, 19);
            this.txt_Uname.TabIndex = 199;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label9.Location = new System.Drawing.Point(101, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 20);
            this.label9.TabIndex = 200;
            this.label9.Text = "Username:";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel17.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel17.Location = new System.Drawing.Point(0, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(3, 159);
            this.panel17.TabIndex = 198;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(535, 3);
            this.panel18.TabIndex = 197;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel19.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel19.Location = new System.Drawing.Point(535, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(3, 162);
            this.panel19.TabIndex = 196;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel20.Location = new System.Drawing.Point(0, 162);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(538, 3);
            this.panel20.TabIndex = 195;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel13.Controls.Add(this.label7);
            this.panel13.Location = new System.Drawing.Point(764, 25);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(217, 44);
            this.panel13.TabIndex = 196;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(46, 7);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 29);
            this.label7.TabIndex = 181;
            this.label7.Text = "DataBase";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel1.Controls.Add(this.label6);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(214, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(217, 44);
            this.panel1.TabIndex = 196;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(25, 8);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 29);
            this.label6.TabIndex = 180;
            this.label6.Text = "Login Details";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 584);
            this.panel3.TabIndex = 195;
            // 
            // pnl_BookRight
            // 
            this.pnl_BookRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_BookRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_BookRight.Location = new System.Drawing.Point(1164, 3);
            this.pnl_BookRight.Name = "pnl_BookRight";
            this.pnl_BookRight.Size = new System.Drawing.Size(3, 584);
            this.pnl_BookRight.TabIndex = 194;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 587);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1167, 3);
            this.panel2.TabIndex = 193;
            // 
            // pnl_BookTop
            // 
            this.pnl_BookTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.pnl_BookTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_BookTop.Location = new System.Drawing.Point(0, 0);
            this.pnl_BookTop.Name = "pnl_BookTop";
            this.pnl_BookTop.Size = new System.Drawing.Size(1167, 3);
            this.pnl_BookTop.TabIndex = 192;
            // 
            // pnl_Database
            // 
            this.pnl_Database.Controls.Add(this.panel11);
            this.pnl_Database.Controls.Add(this.panel10);
            this.pnl_Database.Controls.Add(this.panel9);
            this.pnl_Database.Controls.Add(this.panel8);
            this.pnl_Database.Controls.Add(this.pnl_Login);
            this.pnl_Database.Controls.Add(this.pnl_truncate);
            this.pnl_Database.Controls.Add(this.pnl_cadminpass);
            this.pnl_Database.Location = new System.Drawing.Point(607, 92);
            this.pnl_Database.Name = "pnl_Database";
            this.pnl_Database.Size = new System.Drawing.Size(510, 475);
            this.pnl_Database.TabIndex = 190;
            // 
            // pnl_Login
            // 
            this.pnl_Login.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_Login.Controls.Add(this.lbl_data);
            this.pnl_Login.Controls.Add(this.panel12);
            this.pnl_Login.Controls.Add(this.txt_adminpass);
            this.pnl_Login.Controls.Add(this.label2);
            this.pnl_Login.Controls.Add(this.btn_clear);
            this.pnl_Login.Controls.Add(this.btn_login);
            this.pnl_Login.Controls.Add(this.panel16);
            this.pnl_Login.Controls.Add(this.txt_username);
            this.pnl_Login.Controls.Add(this.label4);
            this.pnl_Login.Location = new System.Drawing.Point(15, 10);
            this.pnl_Login.Name = "pnl_Login";
            this.pnl_Login.Size = new System.Drawing.Size(480, 454);
            this.pnl_Login.TabIndex = 204;
            this.pnl_Login.Visible = false;
            // 
            // pnl_truncate
            // 
            this.pnl_truncate.Controls.Add(this.btn_lock);
            this.pnl_truncate.Controls.Add(this.btn_login_logs);
            this.pnl_truncate.Controls.Add(this.label10);
            this.pnl_truncate.Controls.Add(this.btn_DStudent);
            this.pnl_truncate.Controls.Add(this.label3);
            this.pnl_truncate.Controls.Add(this.lbl_bid);
            this.pnl_truncate.Controls.Add(this.lbl_bname);
            this.pnl_truncate.Controls.Add(this.label1);
            this.pnl_truncate.Controls.Add(this.btn_Dbook);
            this.pnl_truncate.Controls.Add(this.btn_DLogin);
            this.pnl_truncate.Controls.Add(this.lbl_saveinfo);
            this.pnl_truncate.Controls.Add(this.btn_DLogs);
            this.pnl_truncate.Controls.Add(this.lbl_admin);
            this.pnl_truncate.Controls.Add(this.label5);
            this.pnl_truncate.Controls.Add(this.btn_cadminpass);
            this.pnl_truncate.Controls.Add(this.btn_DWithdraw);
            this.pnl_truncate.Location = new System.Drawing.Point(28, 26);
            this.pnl_truncate.Name = "pnl_truncate";
            this.pnl_truncate.Size = new System.Drawing.Size(454, 423);
            this.pnl_truncate.TabIndex = 196;
            // 
            // lbl_admin
            // 
            this.lbl_admin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_admin.AutoSize = true;
            this.lbl_admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_admin.Location = new System.Drawing.Point(54, 335);
            this.lbl_admin.Name = "lbl_admin";
            this.lbl_admin.Size = new System.Drawing.Size(153, 20);
            this.lbl_admin.TabIndex = 186;
            this.lbl_admin.Text = "Change Password";
            // 
            // btn_cadminpass
            // 
            this.btn_cadminpass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_cadminpass.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_cadminpass.FlatAppearance.BorderSize = 0;
            this.btn_cadminpass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cadminpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cadminpass.ForeColor = System.Drawing.Color.White;
            this.btn_cadminpass.Location = new System.Drawing.Point(259, 329);
            this.btn_cadminpass.Name = "btn_cadminpass";
            this.btn_cadminpass.Size = new System.Drawing.Size(148, 31);
            this.btn_cadminpass.TabIndex = 187;
            this.btn_cadminpass.Text = "Change";
            this.btn_cadminpass.UseVisualStyleBackColor = false;
            this.btn_cadminpass.Click += new System.EventHandler(this.btn_cadminpass_Click);
            // 
            // btn_DWithdraw
            // 
            this.btn_DWithdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DWithdraw.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_DWithdraw.FlatAppearance.BorderSize = 0;
            this.btn_DWithdraw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DWithdraw.ForeColor = System.Drawing.Color.White;
            this.btn_DWithdraw.Location = new System.Drawing.Point(259, 125);
            this.btn_DWithdraw.Name = "btn_DWithdraw";
            this.btn_DWithdraw.Size = new System.Drawing.Size(148, 31);
            this.btn_DWithdraw.TabIndex = 181;
            this.btn_DWithdraw.Text = "Delete Data";
            this.btn_DWithdraw.UseVisualStyleBackColor = false;
            this.btn_DWithdraw.Click += new System.EventHandler(this.btn_DWithdraw_Click);
            // 
            // pnl_cadminpass
            // 
            this.pnl_cadminpass.Controls.Add(this.txt_nApass);
            this.pnl_cadminpass.Controls.Add(this.btn_exit);
            this.pnl_cadminpass.Controls.Add(this.panel7);
            this.pnl_cadminpass.Controls.Add(this.panel6);
            this.pnl_cadminpass.Controls.Add(this.txt_nuser);
            this.pnl_cadminpass.Controls.Add(this.panel5);
            this.pnl_cadminpass.Controls.Add(this.btn_clear1);
            this.pnl_cadminpass.Controls.Add(this.lbl_status);
            this.pnl_cadminpass.Controls.Add(this.label14);
            this.pnl_cadminpass.Controls.Add(this.label15);
            this.pnl_cadminpass.Controls.Add(this.btn_ok);
            this.pnl_cadminpass.Location = new System.Drawing.Point(61, 59);
            this.pnl_cadminpass.Name = "pnl_cadminpass";
            this.pnl_cadminpass.Size = new System.Drawing.Size(388, 356);
            this.pnl_cadminpass.TabIndex = 208;
            // 
            // txt_nApass
            // 
            this.txt_nApass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_nApass.BackColor = System.Drawing.SystemColors.Control;
            this.txt_nApass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_nApass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nApass.Location = new System.Drawing.Point(184, 173);
            this.txt_nApass.Name = "txt_nApass";
            this.txt_nApass.Size = new System.Drawing.Size(169, 19);
            this.txt_nApass.TabIndex = 208;
            // 
            // btn_exit
            // 
            this.btn_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_exit.BackColor = System.Drawing.SystemColors.Control;
            this.btn_exit.FlatAppearance.BorderSize = 0;
            this.btn_exit.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_exit.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.Red;
            this.btn_exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_exit.Location = new System.Drawing.Point(356, 7);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(25, 28);
            this.btn_exit.TabIndex = 207;
            this.btn_exit.Text = "X";
            this.btn_exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel7.Controls.Add(this.label8);
            this.panel7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel7.Location = new System.Drawing.Point(79, 21);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(231, 33);
            this.panel7.TabIndex = 206;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(11, 6);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 20);
            this.label8.TabIndex = 180;
            this.label8.Text = "Change Admin Password";
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel6.Location = new System.Drawing.Point(184, 133);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(169, 3);
            this.panel6.TabIndex = 205;
            // 
            // txt_nuser
            // 
            this.txt_nuser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_nuser.BackColor = System.Drawing.SystemColors.Control;
            this.txt_nuser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_nuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nuser.Location = new System.Drawing.Point(184, 107);
            this.txt_nuser.Name = "txt_nuser";
            this.txt_nuser.Size = new System.Drawing.Size(169, 19);
            this.txt_nuser.TabIndex = 204;
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(80)))), ((int)(((byte)(141)))));
            this.panel5.Location = new System.Drawing.Point(184, 196);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(169, 3);
            this.panel5.TabIndex = 203;
            // 
            // btn_clear1
            // 
            this.btn_clear1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_clear1.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_clear1.FlatAppearance.BorderSize = 0;
            this.btn_clear1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear1.ForeColor = System.Drawing.Color.White;
            this.btn_clear1.Location = new System.Drawing.Point(226, 234);
            this.btn_clear1.Name = "btn_clear1";
            this.btn_clear1.Size = new System.Drawing.Size(88, 31);
            this.btn_clear1.TabIndex = 183;
            this.btn_clear1.Text = "Clear";
            this.btn_clear1.UseVisualStyleBackColor = false;
            this.btn_clear1.Click += new System.EventHandler(this.btn_clear1_Click);
            // 
            // lbl_status
            // 
            this.lbl_status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_status.AutoSize = true;
            this.lbl_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_status.ForeColor = System.Drawing.Color.SeaGreen;
            this.lbl_status.Location = new System.Drawing.Point(70, 302);
            this.lbl_status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(18, 24);
            this.lbl_status.TabIndex = 185;
            this.lbl_status.Text = "*";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label14.Location = new System.Drawing.Point(35, 170);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(125, 20);
            this.label14.TabIndex = 186;
            this.label14.Text = "New Password";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label15.Location = new System.Drawing.Point(35, 107);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(130, 20);
            this.label15.TabIndex = 177;
            this.label15.Text = "New Username";
            // 
            // btn_ok
            // 
            this.btn_ok.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_ok.BackColor = System.Drawing.Color.SeaGreen;
            this.btn_ok.FlatAppearance.BorderSize = 0;
            this.btn_ok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ok.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ok.ForeColor = System.Drawing.Color.White;
            this.btn_ok.Location = new System.Drawing.Point(96, 234);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(107, 31);
            this.btn_ok.TabIndex = 187;
            this.btn_ok.Text = "OK";
            this.btn_ok.UseVisualStyleBackColor = false;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // btn_login_logs
            // 
            this.btn_login_logs.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_login_logs.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_login_logs.FlatAppearance.BorderSize = 0;
            this.btn_login_logs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_login_logs.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login_logs.ForeColor = System.Drawing.Color.White;
            this.btn_login_logs.Location = new System.Drawing.Point(259, 278);
            this.btn_login_logs.Name = "btn_login_logs";
            this.btn_login_logs.Size = new System.Drawing.Size(148, 31);
            this.btn_login_logs.TabIndex = 189;
            this.btn_login_logs.Text = "Delete Data";
            this.btn_login_logs.UseVisualStyleBackColor = false;
            this.btn_login_logs.Click += new System.EventHandler(this.btn_login_logs_Click);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Location = new System.Drawing.Point(54, 284);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 20);
            this.label10.TabIndex = 188;
            this.label10.Text = "Login Logs";
            // 
            // btn_lock
            // 
            this.btn_lock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_lock.BackColor = System.Drawing.Color.Red;
            this.btn_lock.FlatAppearance.BorderSize = 0;
            this.btn_lock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_lock.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_lock.ForeColor = System.Drawing.Color.White;
            this.btn_lock.Location = new System.Drawing.Point(345, 382);
            this.btn_lock.Name = "btn_lock";
            this.btn_lock.Size = new System.Drawing.Size(62, 27);
            this.btn_lock.TabIndex = 190;
            this.btn_lock.Text = "Lock";
            this.btn_lock.UseVisualStyleBackColor = false;
            this.btn_lock.Click += new System.EventHandler(this.btn_lock_Click);
            // 
            // UC_Master
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnl_book);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "UC_Master";
            this.Size = new System.Drawing.Size(1200, 720);
            this.Load += new System.EventHandler(this.UC_Master_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.pnl_book.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnl_Database.ResumeLayout(false);
            this.pnl_Login.ResumeLayout(false);
            this.pnl_Login.PerformLayout();
            this.pnl_truncate.ResumeLayout(false);
            this.pnl_truncate.PerformLayout();
            this.pnl_cadminpass.ResumeLayout(false);
            this.pnl_cadminpass.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lbl_data;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txt_adminpass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txt_username;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btn_DStudent;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_bid;
        private System.Windows.Forms.Label lbl_bname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Dbook;
        private System.Windows.Forms.Button btn_DLogin;
        private System.Windows.Forms.Label lbl_saveinfo;
        private System.Windows.Forms.Button btn_DLogs;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel pnl_book;
        private System.Windows.Forms.Button btn_Logs;
        private System.Windows.Forms.Button btn_users;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Button btn_view;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.TextBox txt_Uname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel pnl_BookRight;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnl_BookTop;
        private System.Windows.Forms.Panel pnl_Database;
        private System.Windows.Forms.Panel pnl_Login;
        private System.Windows.Forms.Panel pnl_truncate;
        private System.Windows.Forms.Button btn_DWithdraw;
        private System.Windows.Forms.Label lbl_admin;
        private System.Windows.Forms.Button btn_cadminpass;
        private System.Windows.Forms.Panel pnl_cadminpass;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txt_nuser;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_clear1;
        private System.Windows.Forms.Label lbl_status;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.TextBox txt_nApass;
        private System.Windows.Forms.Button btn_login_logs;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_lock;
    }
}
