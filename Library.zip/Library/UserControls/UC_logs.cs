﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library.UserControls
{
    public partial class UC_logs : UserControl
    {
        public UC_logs()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        private void UC_logs_Load(object sender, EventArgs e)
        {
            lbl_saveinfo.Text = "";
            try
            {
                con.Open();
                cmd = new SqlCommand("select * from Logs", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }
    }
}
