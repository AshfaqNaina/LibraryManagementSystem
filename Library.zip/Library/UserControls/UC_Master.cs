﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library.UserControls
{
    public partial class UC_Master : UserControl
    {
        public UC_Master()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataAdapter da;

        private void btn_login_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select Admin_Username,Admin_Password from Admin where Admin_Username='" + txt_username.Text + "' and Admin_Password='" + txt_adminpass.Text + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                pnl_truncate.Visible = true;
                pnl_Login.Visible = false;
                con.Close();

            }
            else
            {
                MessageBox.Show("Username or Password is Incorrect", "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                con.Close();
            }
        }

        private void btn_users_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select Name,Email,Username from Login", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_Logs_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select Name,Username,Login_Time from Login_Logs", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do you want to delete the User details", "Library Project", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.No)
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from Login where Name='" + txt_Uname.Text + "'", con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Close();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgv.DataSource = dt;
                    con.Close();
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select Name,Email,Username from Login", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_Dbook_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Book", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Book Data has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_DStudent_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Users", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Student Data has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_DWithdraw_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
                con1.Open();
                cmd = new SqlCommand("truncate table Withdraw", con1);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con1.Close();
                lbl_saveinfo.Text = "Withdraw Data has been deleted..";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_DLogs_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Logs", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Logs Data has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_DLogin_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Login", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Login Data has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void UC_Master_Load(object sender, EventArgs e)
        {
            lbl_saveinfo.Text = "";
            pnl_Login.Visible = true;
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgv.Rows[e.RowIndex];
                txt_Uname.Text = row.Cells["Name"].Value.ToString();
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_adminpass.Clear();
            txt_username.Clear();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            pnl_cadminpass.Visible = false;
            pnl_truncate.Visible = true;
            pnl_Login.Visible = false;
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            if (txt_nuser.Text!="" && txt_nApass.Text!="")
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
                SqlCommand cmd = new SqlCommand("update Admin Set Admin_Username='" +txt_nuser.Text + "',Admin_Password='" +txt_nApass.Text + "' where Id=1", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_status.Text = "Password Reset Successfully";
            }
            else
            {
                MessageBox.Show("Password Doesn't Match", "Library Soft");
            }
        }

        private void btn_clear1_Click(object sender, EventArgs e)
        {
            txt_nuser.Clear();
            txt_nApass.Clear();
        }

        private void btn_cadminpass_Click(object sender, EventArgs e)
        {
            pnl_cadminpass.Visible = true;
            pnl_Login.Visible = false;
            pnl_truncate.Visible = false;
        }

        private void btn_login_logs_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("truncate table Login_Logs", con);
                da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                lbl_saveinfo.Text = "Login Logs has been deleted...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_lock_Click(object sender, EventArgs e)
        {
            pnl_cadminpass.Visible = false;
            pnl_Login.Visible = true;
            pnl_truncate.Visible = false;
        }
    }
}
