﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library.WindowsForms
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd;
        SqlDataReader dr;

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("Select * from Login where Username='" +txt_username.Text+ "'and Password='" + txt_password.Text + "'", con);
                SqlCommand cmd1 = new SqlCommand("select Name from login where Username='"+txt_username.Text+"'",con);
                SqlDataReader dr1 = cmd1.ExecuteReader();
                while (dr1.Read())
                {
                    txt_name.Text = dr1.GetValue(0).ToString();
                }
                dr1.Close();
                SqlCommand cmd2 = new SqlCommand("insert into Login_Logs(Name,Username,Login_Time) values('"+txt_name.Text+"','" +txt_username.Text+"','"+System.DateTime.Now.ToString()+"')", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd2);
                cmd2.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Main_Dashboard m = new Main_Dashboard();
                    this.Dispose(false);
                    m.Show();
                    dr.Close();
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password", "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                }
            }
            catch(SqlException x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_username.Clear();
            txt_password.Text = "";
            this.Refresh();
        }

        private void link_sign_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            signup s = new signup();
            this.Hide();
            s.Show();
        }

        private void link_forget_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            WindowsForms.forget_Pass f = new forget_Pass();
            this.Hide();
            f.Show();
        }

      

        private void linklbl_instaID_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/ashfaq_naina/");
        }

        private void txt_username_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                txt_password.Focus();
            }
        }

        private void txt_password_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btn_Login.Focus();
            }
        }
    }
}
