﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library
{
    public partial class Main_Dashboard : Form
    {
        SqlConnection con;
        public Main_Dashboard()
        {
            InitializeComponent();
            tm_Time.Start();
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\LibraryData\Library.mdf;Integrated Security=True;Connect Timeout=30");
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            WindowsForms.Login l = new WindowsForms.Login();
            this.Dispose(false);
            l.Show();
        }

        private void btn_StudentDetails_Click(object sender, EventArgs e)
        {
            UC_Student ucs = new UC_Student();
            ucs.Dock = DockStyle.Fill;
            pnl_slide.Top = btn_StudentDetails.Top;
            pnl_slide.Height = btn_StudentDetails.Height;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucs);
        }

        private void btn_BookDetails_Click(object sender, EventArgs e)
        {
            UC_BookDetails ucb = new UC_BookDetails();
            ucb.Dock = DockStyle.Fill;
            pnl_slide.Top = btn_BookDetails.Top;
            pnl_slide.Height = btn_BookDetails.Height;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucb);

        }

        private void btn_reports_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_reports.Height;
            pnl_slide.Top = btn_reports.Top;
            UC_Reports ucr = new UC_Reports();
            ucr.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucr);
        }

        private void tm_Time_Tick(object sender, EventArgs e)
        {
            lbl_time.Text = System.DateTime.Now.ToString("hh:mm:ss tt");
            lbl_day.Text = System.DateTime.Now.ToString("dddd  dd/MMM/yyyy ");
        }

        private void Main_Dashboard_Load(object sender, EventArgs e)
        {
            UC_Home uch = new UC_Home();
            uch.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(uch);

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select Name from Login_Logs", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while(dr.Read())
                {
                    lbl_username.Text = dr.GetValue(0).ToString();
                }
                dr.Close();
                con.Close();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Library Soft", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
        }

        private void btn_BookIssue_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_BookIssue.Height;
            pnl_slide.Top = btn_BookIssue.Top;
            UC_withdraw ucw = new UC_withdraw();
            ucw.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucw);
        }

        private void btn_BookReturn_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_BookReturn.Height;
            pnl_slide.Top = btn_BookReturn.Top;
            UC_return ucr = new UC_return();
            ucr.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucr);
        }
        private void btn_slide_Click(object sender, EventArgs e)
        {
            if (pnl_Left.Width == 64)
            {
                pnl_Left.Visible = false;
                pnl_Left.Width = 282;
                Bunifu_Slide.ShowSync(pnl_Left);
                Bunifu_Logo.ShowSync(pb_logo);
                Bunifu_Sname.ShowSync(lbl_soft);
                bunifu_Ash.ShowSync(lbl_ash);
            }
            else
            {
                Bunifu_Sname.Hide(lbl_soft);
                bunifu_Ash.Hide(lbl_ash);
                Bunifu_Sname.Hide(lbl_soft);
                Bunifu_Logo.Hide(pb_logo);
                pnl_Left.Visible = false;
                pnl_Left.Width = 64;
                Bunifu_Slide.ShowSync(pnl_Left);

            }
        }

        private void btn_max_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_home.Height;
            pnl_slide.Top = btn_home.Top;
            UC_Home uch = new UC_Home();
            uch.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(uch);
        }

        private void btn_mail_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_mail.Height;
            pnl_slide.Top = btn_mail.Top;
            UC_Mail ucm = new UC_Mail();
            ucm.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucm);
        }

        private void btn_min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btn_stock_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_stock.Height;
            pnl_slide.Top = btn_stock.Top;
            UserControls.UC_stock ucs = new UserControls.UC_stock();
            ucs.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucs);
        }

        private void btn_logs_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_logs.Height;
            pnl_slide.Top = btn_logs.Top;
            UserControls.UC_logs ucl = new UserControls.UC_logs();
            ucl.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucl);
        }

        private void pnl_Lefttop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_about_Click(object sender, EventArgs e)
        {
            pnl_slide.Height = btn_about.Height;
            pnl_slide.Top = btn_about.Top;
            UserControls.UC_about uca = new UserControls.UC_about();
            uca.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(uca);
        }

        private void btn_settings_Click(object sender, EventArgs e)
        {
            pnl_slide.Top = btn_settings.Top;
            pnl_slide.Height = btn_settings.Height;
            UserControls.UC_Master ucm = new UserControls.UC_Master();
            ucm.Dock = DockStyle.Fill;
            pnl_main.Controls.Clear();
            pnl_main.Controls.Add(ucm);
        }
    }
}
